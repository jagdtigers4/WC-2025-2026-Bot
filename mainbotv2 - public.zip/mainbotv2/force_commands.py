import discord
from i18n import tr
from utils import load_config
from dispatcher import change_winner

config = load_config()

async def force_change_winner(interaction: discord.Interaction, match_id: str, winner_id: int, reason: str):
    """
    Setzt den Sieger in diesem Channel direkt (Owner/Admin).
    Erwartet, dass channel.topic == "Group|S1|S2" ist.
    """
    if not interaction.channel or not interaction.channel.topic:
        await interaction.response.send_message(tr("Match-Kontext fehlt.", "Match context missing."), ephemeral=True)
        return
    try:
        group, s1, s2 = interaction.channel.topic.split("|")
    except Exception:
        await interaction.response.send_message(tr("Unerwartetes Channel-Topic.", "Unexpected channel topic."), ephemeral=True)
        return
    member = interaction.guild.get_member(winner_id)
    if not member:
        await interaction.response.send_message(tr("Sieger-ID ungültig.", "Invalid winner ID."), ephemeral=True)
        return

    await change_winner(interaction, group, s1, s2, member.name)
    await interaction.response.send_message(tr("Sieger geändert.", "Winner changed.") + " — " + reason, ephemeral=True)

async def force_resetchannel(interaction: discord.Interaction, reason: str):
    """
    Setzt den Match-Channel hart zurück: entfernt Termin-/Ergebnis-Status (nicht Chatverlauf),
    initialisiert Bot-UI neu.
    """
    if not interaction.channel or not interaction.channel.topic:
        await interaction.response.send_message(tr("Match-Kontext fehlt.", "Match context missing."), ephemeral=True)
        return
    try:
        group, s1, s2 = interaction.channel.topic.split("|")
    except Exception:
        await interaction.response.send_message(tr("Unerwartetes Channel-Topic.", "Unexpected channel topic."), ephemeral=True)
        return

    # Buttons/Views neu posten
    from match import MatchView
    await interaction.channel.send(
        tr("Channel zurückgesetzt. UI neu initialisiert.", "Channel reset. UI re-initialized."),
        view=MatchView(group, s1, s2)
    )
    await interaction.response.send_message(tr("Zurückgesetzt.", "Reset." ) + " — " + reason, ephemeral=True)
