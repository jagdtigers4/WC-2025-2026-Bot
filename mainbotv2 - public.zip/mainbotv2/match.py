import discord
import json
import os
import shutil
import re
import asyncio
from modals import HilfeModal, TerminModal
from utils import (
    load_config, resolve_member_by_name, pair_has_unconfirmed, confirmed_count_for_pair, match_closed_persisted, is_admin,
)
from dispatcher import handle_confirmed_win

def _safe_send(interaction: discord.Interaction, *, embed=None, content=None, ephemeral=None, view=None):
    try:
        can_resp = hasattr(interaction, 'response') and not interaction.response.is_done()
        eph = True if ephemeral is None else ephemeral
        kwargs = {}
        if embed is not None: kwargs["embed"] = embed
        if content is not None: kwargs["content"] = content
        if eph is not None: kwargs["ephemeral"] = eph
        if view is not None: kwargs["view"] = view
        if can_resp:
            return interaction.response.send_message(**kwargs)
        return interaction.followup.send(**kwargs)
    except Exception:
        try:
            return interaction.followup.send(**{k:v for k,v in kwargs.items() if not (k=="view" and v is None)})
        except Exception:
            return None
    except Exception:
        return asyncio.create_task(_follow())

def _member_is_player(guild: discord.Guild, user: discord.Member, s1: str, s2: str) -> bool:
    m1 = resolve_member_by_name(guild, s1)
    m2 = resolve_member_by_name(guild, s2)
    uid = getattr(user, "id", -1)
    return (m1 and uid == getattr(m1, "id", -1)) or (m2 and uid == getattr(m2, "id", -1))



config = load_config()
orga_ids = config.get("turnierleitung_ids", [])
_ergebnisse_channel_id = config.get("ergebnisse_channel_id")

# Persistenz-Datei für offene Winner-Bestätigungen
WINNER_PENDING_PATH = "winner_pending.json"

def _load_json(path, default):
    try:
        if not os.path.exists(path): return default
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def _save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def _topic_to_tuple(channel: discord.abc.GuildChannel):
    topic = getattr(channel, "topic", "") or ""
    parts = topic.split("|")
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    return None, None, None

# -------- PERSISTENTE ROOT-VIEW FÜR MATCH-CHANNELS --------
class MatchRootPersistentView(discord.ui.View):
    """Persistente Buttons im Match-Channel. Liest Gruppe/S1/S2 aus dem Channel-Topic (Gruppe|Spieler1|Spieler2)."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="❗ Hilfe / Help", style=discord.ButtonStyle.secondary, custom_id="root_help")
    async def root_help(self, interaction: discord.Interaction, _):
        g, s1, s2 = _topic_to_tuple(interaction.channel)
        if not g:
            await _safe_send(interaction, content="Kein Match-Topic gesetzt.", ephemeral=True); return
        modal = HilfeModal(g, s1, s2, interaction.channel)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="📅 Termin vorschlagen / Propose date", style=discord.ButtonStyle.primary, custom_id="root_propose")
    async def root_propose(self, interaction: discord.Interaction, _):
        g, s1, s2 = _topic_to_tuple(interaction.channel)
        if not g:
            await _safe_send(interaction, content="Kein Match-Topic gesetzt.", ephemeral=True); return
        if pair_has_unconfirmed(g, s1, s2) or confirmed_count_for_pair(g, s1, s2) >= 3:
            await _safe_send(interaction, 
                embed=discord.Embed(
                    description="⚠️ Für dieses Match existiert bereits ein **offener/bestätigter** Termin. Bitte zuerst auflösen/abbrechen.",
                    color=discord.Color.orange()
                ),
                ephemeral=True
            )
            return
        await interaction.response.send_modal(TerminModal(g, s1, s2))

    @discord.ui.button(label="🏆 Sieger melden / Report winner", style=discord.ButtonStyle.success, custom_id="root_report")
    async def root_report(self, interaction: discord.Interaction, _):
        g, s1, s2 = _topic_to_tuple(interaction.channel)
        if not g:
            await _safe_send(interaction, content="Kein Match-Topic gesetzt.", ephemeral=True); return

        if not _member_is_player(interaction.guild, interaction.user, s1, s2) and interaction.user.id not in orga_ids:
            await _safe_send(interaction, embed=discord.Embed(description="Nur Teilnehmer oder Orga! / Players or staff only.", color=discord.Color.red()),
                ephemeral=True
            )
            return

        if match_closed_persisted(g, s1, s2):
            await _safe_send(interaction, embed=discord.Embed(description="Dieses Match ist bereits abgeschlossen. / Already closed.", color=discord.Color.orange()),
                ephemeral=True
            )
            return

        options = [
            discord.SelectOption(label=s1, value=s1, emoji="🏆"),
            discord.SelectOption(label=s2, value=s2, emoji="🏆"),
        ]
        view = WinnerSelectView(g, s1, s2, interaction.user, options)

        opponent = s2 if interaction.user.name == s1 else s1
        mem = resolve_member_by_name(interaction.guild, opponent)
        mention = mem.mention if mem else f"**{opponent}**"

        await _safe_send(interaction, embed=discord.Embed(
                description=f"{mention} bitte Ergebnis **bestätigen/ablehnen**:",
                color=discord.Color.blurple()
            ),
            view=view,
            ephemeral=False
        )

# ------ Winner-Auswahl & Persistente Approve-View ------
class WinnerSelectView(discord.ui.View):
    def __init__(self, group, s1, s2, reporter, options):
        super().__init__(timeout=600)
        self.group = group
        self.s1 = s1
        self.s2 = s2
        self.reporter = reporter
        self.winner = None
        self.add_item(WinnerSelect(self, options))

class WinnerSelect(discord.ui.Select):
    def __init__(self, parent, options):
        super().__init__(placeholder="Sieger auswählen / Select winner", min_values=1, max_values=1, options=options)
        self.parent = parent

    async def callback(self, interaction: discord.Interaction):
        self.parent.winner = self.values[0]
        opponent = self.parent.s2 if interaction.user.name == self.parent.s1 else self.parent.s1
        mem = resolve_member_by_name(interaction.guild, opponent)
        mention = mem.mention if mem else f"**{opponent}**"

        approve_view = WinnerApprovePersistentView()
        await interaction.message.edit(
            embed=discord.Embed(
                description=f"**{interaction.user.name}** hat **{self.parent.winner}** als Sieger gewählt.\n"
                            f"{mention} bitte **bestätigen** oder **ablehnen**.",
                color=discord.Color.blurple()
            ),
            view=approve_view
        )

        try:
            current = await interaction.original_response()
        except Exception:
            current = None

        message_id = (current.id if current else interaction.message.id)
        chan_id = interaction.channel.id

        pend = _load_json(WINNER_PENDING_PATH, [])
        pend = [p for p in pend if not (p.get("message_id")==message_id)]
        pend.append({
            "gruppe": self.parent.group,
            "spieler1": self.parent.s1,
            "spieler2": self.parent.s2,
            "winner": self.parent.winner,
            "message_id": message_id,
            "channel_id": chan_id,
            "asked_by": self.parent.reporter.id
        })
        _save_json(WINNER_PENDING_PATH, pend)

class WinnerApprovePersistentView(discord.ui.View):
    """Persistente View: Sieger-Bestätigung (Bestätigen/Ablehnen) – identifiziert per message_id in winner_pending.json."""
    def __init__(self):
        super().__init__(timeout=None)

    def _load_by_msg(self, message_id: int):
        pend = _load_json(WINNER_PENDING_PATH, [])
        for p in pend:
            if int(p.get("message_id", 0)) == int(message_id):
                return p
        return None

    def _remove_by_msg(self, message_id: int):
        pend = _load_json(WINNER_PENDING_PATH, [])
        pend = [p for p in pend if int(p.get("message_id", 0)) != int(message_id)]
        _save_json(WINNER_PENDING_PATH, pend)

    @discord.ui.button(label="Bestätigen / Confirm", style=discord.ButtonStyle.success, custom_id="winner_confirm")
    async def confirm(self, interaction: discord.Interaction, _):
        # Always acknowledge quickly; only defer once.
        try:
            await interaction.response.defer(ephemeral=True)
        except Exception:
            pass
        # Erst Berechtigungen prüfen, dann handle_confirmed_win (da diese selbst antwortet).
        p = self._load_by_msg(interaction.message.id)
        if not p:
            await _safe_send(interaction, content="Kein offener Winner-Request gefunden.", ephemeral=True); return

        if p.get("processing"):
            await interaction.followup.send("⚠️ Anfrage wird bereits bearbeitet.", ephemeral=True)
            return

        # Double-click / replay protection:
        # We only mark as "processing" right before applying the result, so a failed
        # validation (missing /stati etc.) does not lock the request permanently.
        if p.get("processing"):
            await interaction.followup.send("⚠️ Anfrage wird bereits bearbeitet.", ephemeral=True)
            return

        # Match bereits zu?
        if match_closed_persisted(p["gruppe"], p["spieler1"], p["spieler2"]):
            await _safe_send(interaction, content="Match bereits abgeschlossen.", ephemeral=True); 
            self._remove_by_msg(interaction.message.id)
            try:
                await interaction.message.edit(view=None)
            except Exception:
                pass
            return

        # Nur Gegner oder Orga
        m1 = resolve_member_by_name(interaction.guild, p["spieler1"])
        m2 = resolve_member_by_name(interaction.guild, p["spieler2"])
        uid = interaction.user.id
        asked_by = int(p.get("asked_by", 0))
        is_player = (m1 and uid == getattr(m1, "id", -1)) or (m2 and uid == getattr(m2, "id", -1))
        if not (is_player and uid != asked_by) and not is_admin(interaction.user, (config.get("turnierleitung_ids") or [])):
            await interaction.followup.send("Nur der Gegner oder Orga darf bestätigen.", ephemeral=True); return

        # Require attached statistics before confirming any result.
        # We use the persisted match record field `stati_image` set via /stati.
        # For KO we require stats for the current game number, but we do NOT hard-require
        # the transient flag `ko_game_started` (bot restarts / reconnects can drop it).
        from utils import get_match_record
        rec = get_match_record(p["gruppe"], p["spieler1"], p["spieler2"]) or {}
        stati_url = rec.get("stati_image")
        if not isinstance(stati_url, str) or not stati_url.strip():
            await interaction.followup.send("Bitte vor der Bestätigung /stati mit der Statistik ausführen.", ephemeral=True)
            return
        if str(p["gruppe"]).startswith("KO-"):
            game_no = int(rec.get("ko_game_started_no") or 0)
            stati_game_no = int(rec.get("stati_game_no") or 0)
            # If game_no was not persisted (restart), infer it from current KO wins.
            if game_no <= 0:
                wins0 = rec.get("ko_wins") or {p["spieler1"]: 0, p["spieler2"]: 0}
                try:
                    game_no = int(wins0.get(p["spieler1"], 0) or 0) + int(wins0.get(p["spieler2"], 0) or 0) + 1
                except Exception:
                    game_no = 0
            # Accept a positive stati_game_no as the source of truth if game_no still unknown.
            if game_no <= 0 and stati_game_no > 0:
                game_no = stati_game_no
            if game_no <= 0 or stati_game_no != game_no:
                await interaction.followup.send("Bitte vor der Bestätigung /stati mit der Statistik für das aktuelle Game ausführen.", ephemeral=True)
                return
        else:
            if not rec.get("swiss_match_started"):
                await interaction.followup.send("Bitte vor der Bestätigung /matchstart ausführen.", ephemeral=True)
                return

        # Mark as processing now to prevent double-confirm counting.
        try:
            pend = _load_json(WINNER_PENDING_PATH, [])
            for x in pend:
                if int(x.get("message_id", 0)) == int(interaction.message.id):
                    x["processing"] = True
                    break
            _save_json(WINNER_PENDING_PATH, pend)
            p["processing"] = True
        except Exception:
            pass

        # handle_confirmed_win antwortet selbst via interaction.response.send_message(...)
        await handle_confirmed_win(
            interaction,
            p["gruppe"], p["spieler1"], p["spieler2"],
            p["winner"],
            interaction.user.name,
            _ergebnisse_channel_id
        )
        # Pending wegräumen & View schließen
        self._remove_by_msg(interaction.message.id)
        try:
            await interaction.message.edit(view=None)
        except Exception:
            pass

    @discord.ui.button(label="Ablehnen / Deny", style=discord.ButtonStyle.danger, custom_id="winner_deny")
    async def deny(self, interaction: discord.Interaction, _):
        try:
            await interaction.response.defer(ephemeral=True)
        except Exception:
            pass
        try:
            await interaction.response.defer(ephemeral=True)
        except Exception:
            pass
        p = self._load_by_msg(interaction.message.id)
        if not p:
            await _safe_send(interaction, content="Kein offener Winner-Request gefunden.", ephemeral=True); return

        # Nur Gegner oder Orga
        m1 = resolve_member_by_name(interaction.guild, p["spieler1"])
        m2 = resolve_member_by_name(interaction.guild, p["spieler2"])
        uid = interaction.user.id
        asked_by = int(p.get("asked_by", 0))
        is_player = (m1 and uid == getattr(m1, "id", -1)) or (m2 and uid == getattr(m2, "id", -1))
        if not (is_player and uid != asked_by) and not is_admin(interaction.user, (config.get("turnierleitung_ids") or [])):
            await _safe_send(interaction, content="Nur der Gegner oder Orga darf ablehnen.", ephemeral=True); return

        await interaction.message.edit(
            embed=discord.Embed(
                description="❌ Sieger-Eingabe wurde abgelehnt. Bitte erneut korrekt melden.",
                color=discord.Color.red()
            ),
            view=None
        )
        self._remove_by_msg(interaction.message.id)


# -------- MATCHSTART FLOW: Münzwurf, Moduswahl, Bans --------

from utils import upsert_match_record, get_match_record, load_json, save_json, PLAYED_MAPS_KO_PATH
import random

# --- Map selection helpers (avoid giving mappers their own maps, track played maps) ---
def _norm_name(s: str) -> str:
    s = (s or '').strip().lower()
    s = re.sub(r'[^a-z0-9]+', '', s)
    return s

def _levenshtein(a: str, b: str) -> int:
    # small, simple DP; strings are short (nicknames / folder names)
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            ins = cur[j-1] + 1
            dele = prev[j] + 1
            sub = prev[j-1] + (0 if ca == cb else 1)
            cur.append(min(ins, dele, sub))
        prev = cur
    return prev[-1]

def _similar(a: str, b: str) -> bool:
    a2, b2 = _norm_name(a), _norm_name(b)
    if not a2 or not b2:
        return False
    if a2 == b2:
        return True
    # tolerate 1 typo
    if _levenshtein(a2, b2) <= 1:
        return True
    # tolerate one being contained in the other (common with tags)
    if len(a2) >= 5 and a2 in b2:
        return True
    if len(b2) >= 5 and b2 in a2:
        return True
    return False

def _mapper_folder_for_path(base_dir: str, path: str) -> str:
    rel = os.path.relpath(path, base_dir)
    parts = rel.split(os.sep)
    # If the map is directly inside the base dir, the first part is the filename.
    # In that case we treat it as "no mapper folder".
    if not parts:
        return ''
    first = parts[0]
    if first.lower().endswith('.map'):
        return ''
    return first

def _played_maps_state() -> dict:
    st = load_json(PLAYED_MAPS_KO_PATH, {})
    if not isinstance(st, dict):
        st = {}
    st.setdefault('played', [])
    if not isinstance(st['played'], list):
        st['played'] = []
    return st

def _mark_played(map_filename: str) -> None:
    st = _played_maps_state()
    fn = os.path.basename(map_filename)
    if fn not in st['played']:
        st['played'].append(fn)
    save_json(PLAYED_MAPS_KO_PATH, st)

def _move_to_played_folders(map_path: str, preview_path: str | None = None) -> None:
    # creates folders if missing
    root = os.path.dirname(__file__)
    played_maps_dir = os.path.join(root, 'GespielteMaps')
    played_prev_dir = os.path.join(root, 'GespielteMapPreviews')
    os.makedirs(played_maps_dir, exist_ok=True)
    os.makedirs(played_prev_dir, exist_ok=True)
    # move map
    if os.path.isfile(map_path):
        dst = os.path.join(played_maps_dir, os.path.basename(map_path))
        if not os.path.exists(dst):
            try:
                shutil.move(map_path, dst)
            except Exception:
                # Windows may keep file handles open briefly; fall back to copy+remove.
                shutil.copy2(map_path, dst)
                # robust delete retry (Windows can keep handles briefly)
                for _ in range(6):
                    try:
                        os.remove(map_path)
                        break
                    except Exception:
                        try:
                            import time
                            time.sleep(0.2)
                        except Exception:
                            pass
    # move preview (explicit path preferred)
    cand = preview_path
    if not cand:
        # legacy fallback: same basename in MapPreviews
        base_name = os.path.splitext(os.path.basename(map_path))[0]
        prev_dir = os.path.join(root, 'MapPreviews')
        for ext in ('.png', '.jpg', '.jpeg', '.webp'):
            p = os.path.join(prev_dir, base_name + ext)
            if os.path.isfile(p):
                cand = p
                break
    if cand and os.path.isfile(cand):
        dstp = os.path.join(played_prev_dir, os.path.basename(cand))
        if not os.path.exists(dstp):
            try:
                shutil.move(cand, dstp)
            except Exception:
                shutil.copy2(cand, dstp)
                for _ in range(6):
                    try:
                        os.remove(cand)
                        break
                    except Exception:
                        try:
                            import time
                            time.sleep(0.2)
                        except Exception:
                            pass
import os
import re

# Map pool identifiers shown to users / stored in data.
# KO uses HGHG maps.
MODES = ["metzel", "buddel", "HGHG"]
CIVS = ["Römer", "Wikinger", "Maya", "Trojaner"]

def _players_ids_for(guild, s1, s2):
    a = resolve_member_by_name(guild, s1)
    b = resolve_member_by_name(guild, s2)
    return {getattr(a, "id", -1), getattr(b, "id", -1)}

def _match_tuple_from_interaction(interaction: discord.Interaction, fallback: tuple[str|None, str|None, str|None] = (None, None, None)):
    """Return (group, s1, s2) from channel topic; fallback if topic missing."""
    g, a, b = _topic_to_tuple(interaction.channel)
    if g and a and b:
        return g, a, b
    return fallback

def _player_name_variants_for_exclusion(guild: discord.Guild, s1: str, s2: str) -> list[str]:
    """Build robust player name variants (bracket names + Discord names + players.json names)."""
    variants: set[str] = set()
    for x in (s1, s2):
        if isinstance(x, str) and x.strip():
            variants.add(x.strip())
    for name in (s1, s2):
        try:
            m = resolve_member_by_name(guild, name)
        except Exception:
            m = None
        if not m:
            continue
        for x in (getattr(m, 'display_name', None), getattr(m, 'name', None)):
            if isinstance(x, str) and x.strip():
                variants.add(x.strip())
        try:
            from utils import players_get
            pr = players_get(getattr(m, 'id', 0)) or {}
            for x in (pr.get('ingame'),):
                if isinstance(x, str) and x.strip():
                    variants.add(x.strip())
            for x in (pr.get('aliases') or []):
                if isinstance(x, str) and x.strip():
                    variants.add(x.strip())
            for x in (pr.get('discord_names') or []):
                if isinstance(x, str) and x.strip():
                    variants.add(x.strip())
        except Exception:
            pass
    return list(variants)

def _swiss_choose_hghg_map(guild: discord.Guild, s1: str, s2: str) -> tuple[str | None, str | None]:
    """Pick a .map from ./Maps excluding (a) mapper folders for active players, (b) already-played (if possible)."""
    base = os.path.join(os.path.dirname(__file__), 'Maps')
    try:
        played_state = _played_maps_state()
        played = set([str(x) for x in (played_state.get('played') or [])])
    except Exception:
        played = set()

    variants = _player_name_variants_for_exclusion(guild, s1, s2)

    entries: list[str] = []
    entries_fallback: list[str] = []
    if not os.path.isdir(base):
        return None, None

    for root, _dirs, files in os.walk(base):
        for f in files:
            if not f.lower().endswith('.map'):
                continue
            path = os.path.join(root, f)
            mapper = _mapper_folder_for_path(base, path)
            # Never give a mapper their own maps (tolerate small typos / case)
            if mapper and any(_similar(mapper, v) for v in variants):
                continue
            if os.path.basename(path) in played:
                entries_fallback.append(path)
            else:
                entries.append(path)

    candidates = entries if entries else entries_fallback
    if not candidates:
        return None, None

    path = random.choice(candidates)
    mapper = _mapper_folder_for_path(base, path)
    return path, mapper


class CoinTossView(discord.ui.View):
    """Swiss /matchstart coin toss.

    Persistenz: timeout=None + feste custom_ids. Die Match-Daten werden immer aus dem Channel-Topic gelesen,
    damit Interaktionen auch nach Bot-Restart funktionieren.
    """
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None, caller_id: int | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2
        self.caller_id = int(caller_id) if caller_id is not None else 0

    async def _ensure_caller(self, interaction: discord.Interaction, rec: dict, g: str, s1: str, s2: str) -> bool:
        expected = int(rec.get("coin_caller_id") or self.caller_id or 0)
        if expected and interaction.user.id != expected:
            await interaction.response.send_message(
                "Nur der ausgewählte Spieler darf den Münzwurf bedienen. / Only the chosen player may use the coin toss.",
                ephemeral=True
            )
            return False
        # If no caller was persisted (shouldn't happen), allow any of the two players.
        if not expected:
            allowed = _players_ids_for(interaction.guild, s1, s2)
            if interaction.user.id not in allowed:
                await interaction.response.send_message(
                    "Nur die beiden Spieler dürfen den Münzwurf bedienen. / Only the two players may use the coin toss.",
                    ephemeral=True
                )
                return False
        return True

    @discord.ui.button(label="Kopf / Heads", style=discord.ButtonStyle.primary, custom_id="swiss_coin_head")
    async def head(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        if rec.get("toss_winner"):
            await interaction.response.send_message("Münzwurf ist bereits abgeschlossen. / Coin toss already finished.", ephemeral=True)
            return
        if not await self._ensure_caller(interaction, rec, g, s1, s2):
            return
        await self._toss(interaction, g, s1, s2, "Kopf")

    @discord.ui.button(label="Zahl / Tails", style=discord.ButtonStyle.primary, custom_id="swiss_coin_tail")
    async def tail(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        if rec.get("toss_winner"):
            await interaction.response.send_message("Münzwurf ist bereits abgeschlossen. / Coin toss already finished.", ephemeral=True)
            return
        if not await self._ensure_caller(interaction, rec, g, s1, s2):
            return
        await self._toss(interaction, g, s1, s2, "Zahl")

    async def _toss(self, interaction: discord.Interaction, group: str, s1: str, s2: str, choice: str):
        result = random.choice(["Kopf", "Zahl"])

        s1_member = resolve_member_by_name(interaction.guild, s1)
        s2_member = resolve_member_by_name(interaction.guild, s2)
        uid = interaction.user.id

        if uid == getattr(s1_member, "id", -1):
            winner_name = s1 if choice == result else s2
        elif uid == getattr(s2_member, "id", -1):
            winner_name = s2 if choice == result else s1
        else:
            await interaction.response.send_message("Nur die beiden Spieler dürfen den Münzwurf bedienen.", ephemeral=True)
            return

        rec0 = get_match_record(group, s1, s2) or {}
        upsert_match_record(
            group,
            s1,
            s2,
            toss_result=result,
            toss_choice_user=uid,
            toss_winner=winner_name,
            coin_caller_id=int(rec0.get("coin_caller_id") or self.caller_id or 0) or uid,
        )

        await interaction.response.edit_message(
            embed=discord.Embed(
                description=(
                    f"🪙 Ergebnis / Result: **{result}**\n"
                    f"Gewinner / Winner: **{winner_name}**.\n"
                    "Bitte Option wählen: **Letzter Bann** oder **Positionswahl**. / "
                    "Please choose between **Last ban** and **Position choice**."
                ),
                color=discord.Color.green()
            ),
            view=ModeChoiceView(group, s1, s2)
        )

class ModeChoiceView(discord.ui.View):
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2

    async def _only_toss_winner(self, interaction: discord.Interaction, rec: dict, s1: str, s2: str) -> bool:
        toss_winner = rec.get("toss_winner")
        if not toss_winner:
            await interaction.response.send_message("Münzwurf fehlt noch. / Coin toss not completed yet.", ephemeral=True)
            return False
        winner_member = resolve_member_by_name(interaction.guild, toss_winner)
        if interaction.user.id != getattr(winner_member, "id", -1):
            await interaction.response.send_message(
                "Nur der Münzwurf-Gewinner darf diese Option wählen. / Only the coin toss winner may choose this option.",
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(label="Letzter Bann", style=discord.ButtonStyle.secondary, custom_id="swiss_mode_lastban")
    async def letzter_bann(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        if rec.get("mode"):
            await interaction.response.send_message("Option ist bereits gewählt. / Option already chosen.", ephemeral=True)
            return
        if not await self._only_toss_winner(interaction, rec, s1, s2):
            return
        upsert_match_record(g, s1, s2, mode="letzter_bann")
        await interaction.response.edit_message(
            embed=discord.Embed(
                description=(
                    "Option: **Letzter Bann / Last ban**.\n"
                    "Der **Verlierer** des Münzwurfs bannt **zuerst**. / The **coin toss loser** bans **first**.\n"
                    "(Positionswahl folgt nach dem Völkerpick.)"
                ),
                color=discord.Color.blurple()
            ),
            view=BanFlowView(g, s1, s2)
        )

    @discord.ui.button(label="Positionswahl", style=discord.ButtonStyle.success, custom_id="swiss_mode_posiwahl")
    async def positionswahl(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        if rec.get("mode"):
            await interaction.response.send_message("Option ist bereits gewählt. / Option already chosen.", ephemeral=True)
            return
        if not await self._only_toss_winner(interaction, rec, s1, s2):
            return
        upsert_match_record(g, s1, s2, mode="positionswahl")
        await interaction.response.edit_message(
            embed=discord.Embed(
                description=(
                    "Option: **Positionswahl / Position choice**.\n"
                    "Der **Gewinner** des Münzwurfs bannt **zuerst**. / The **coin toss winner** bans **first**.\n"
                    "(Positionswahl folgt nach dem Völkerpick.)"
                ),
                color=discord.Color.blurple()
            ),
            view=BanFlowView(g, s1, s2)
        )


class BanFlowView(discord.ui.View):
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2

        options = [discord.SelectOption(label=m) for m in MODES]
        self._select = discord.ui.Select(
            placeholder="Modus bannen / Ban mode …",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="swiss_ban_select",
        )
        self._select.callback = self._on_select
        self.add_item(self._select)

    async def _on_select(self, interaction: discord.Interaction):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return

        rec = get_match_record(g, s1, s2) or {}
        if rec.get("final_mode"):
            await interaction.response.send_message("Bans sind bereits abgeschlossen. / Bans already finished.", ephemeral=True)
            return

        mode_choice = rec.get("mode")
        toss_winner = rec.get("toss_winner")
        if not mode_choice or not toss_winner:
            await interaction.response.send_message("Bitte zuerst Münzwurf + Option abschließen. / Finish coin toss + option first.", ephemeral=True)
            return

        values = getattr(self._select, "values", None) or []
        choice = values[0] if values else None
        if not choice or choice not in MODES:
            await interaction.response.send_message("Ungültige Auswahl. / Invalid selection.", ephemeral=True)
            return

        bans = list(rec.get("bans") or [])
        ban_s1 = rec.get("ban_s1")
        ban_s2 = rec.get("ban_s2")
        if choice in bans:
            await interaction.response.send_message("Bereits gebannt. / Already banned.", ephemeral=True)
            return

        # Determine who bans first/second based on chosen option.
        loser = s2 if toss_winner == s1 else s1
        if mode_choice == "positionswahl":
            first_player, second_player = toss_winner, loser
        else:  # letzter_bann
            first_player, second_player = loser, toss_winner

        turn = len(bans)
        if turn not in (0, 1):
            await interaction.response.send_message("Unerwarteter Ban-Status. / Unexpected ban state.", ephemeral=True)
            return
        expected = first_player if turn == 0 else second_player
        expected_member = resolve_member_by_name(interaction.guild, expected)
        if interaction.user.id != getattr(expected_member, "id", -1):
            await interaction.response.send_message("Aktuell ist der andere Spieler am Zug. / It is the other player's turn.", ephemeral=True)
            return

        # Log ban per player.
        s1_member = resolve_member_by_name(interaction.guild, s1)
        s2_member = resolve_member_by_name(interaction.guild, s2)
        uid = interaction.user.id
        if uid == getattr(s1_member, "id", -1):
            ban_s1 = choice
        elif uid == getattr(s2_member, "id", -1):
            ban_s2 = choice

        bans.append(choice)
        remaining = [m for m in MODES if m not in bans]

        if len(bans) < 2:
            upsert_match_record(g, s1, s2, bans=bans, ban_s1=ban_s1, ban_s2=ban_s2)
            await interaction.response.edit_message(
                embed=discord.Embed(
                    description=(
                        f"Gebannt / banned: **{', '.join(bans)}**\n"
                        f"Verbleibend / remaining: **{', '.join(remaining)}**"
                    ),
                    color=discord.Color.orange()
                ),
                view=self
            )
            return

        final_mode = remaining[0] if remaining else None
        upsert_match_record(g, s1, s2, bans=bans, final_mode=final_mode, ban_s1=ban_s1, ban_s2=ban_s2)

        desc = (
            f"Zu spielender Modus / Mode to be played: **{final_mode or '—'}**\n\n"
            "Bitte wählt nun eure Völker. / Please choose your civilizations."
        )
        await interaction.response.edit_message(
            embed=discord.Embed(description=desc, color=discord.Color.green()),
            view=CivPickView(g, s1, s2)
        )


class CivPickView(discord.ui.View):
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2

        # 4 Völker + 5. Option "Zufall"
        options = [discord.SelectOption(label=c) for c in CIVS]
        options.append(discord.SelectOption(label="Zufall"))

        self._select = discord.ui.Select(
            placeholder="Volk wählen / Choose civilization …",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="swiss_civ_select",
        )
        self._select.callback = self._on_select
        self.add_item(self._select)

    async def _on_select(self, interaction: discord.Interaction):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return

        rec = get_match_record(g, s1, s2) or {}
        s1_member = resolve_member_by_name(interaction.guild, s1)
        s2_member = resolve_member_by_name(interaction.guild, s2)

        civ_s1 = rec.get("civ_s1")
        civ_s2 = rec.get("civ_s2")

        uid = interaction.user.id
        if uid == getattr(s1_member, "id", -1) and civ_s1:
            await interaction.response.send_message(
                "Du hast bereits ein Volk gewählt. / You already chose a civilization.",
                ephemeral=True
            )
            return
        if uid == getattr(s2_member, "id", -1) and civ_s2:
            await interaction.response.send_message(
                "Du hast bereits ein Volk gewählt. / You already chose a civilization.",
                ephemeral=True
            )
            return

        values = getattr(self._select, "values", None) or (interaction.data.get("values") if hasattr(interaction, "data") else None) or []
        choice = values[0] if values else None
        if not choice:
            await interaction.response.send_message("Ungültige Auswahl. / Invalid selection.", ephemeral=True)
            return

        # "Zufall" ist eigene Option – wird so gespeichert, kein Random-Mapping
        resolved_choice = choice

        updates = {}
        picker_name = None
        if uid == getattr(s1_member, "id", -1):
            updates["civ_s1"] = resolved_choice
            picker_name = s1
        elif uid == getattr(s2_member, "id", -1):
            updates["civ_s2"] = resolved_choice
            picker_name = s2
        else:
            await interaction.response.send_message(
                "Nur die beiden Spieler dürfen hier ein Volk wählen. / Only the two players may choose a civilization.",
                ephemeral=True
            )
            return

        upsert_match_record(g, s1, s2, **updates)
        rec = get_match_record(g, s1, s2) or {}
        civ_s1 = rec.get("civ_s1")
        civ_s2 = rec.get("civ_s2")

        # Blind Pick: solange nicht beide gewählt haben, werden keine Völker revealed
        lines = []
        if civ_s1:
            lines.append(f"**{s1}** hat sein Volk gewählt.")
        else:
            lines.append(f"**{s1}** hat noch kein Volk gewählt.")
        if civ_s2:
            lines.append(f"**{s2}** hat sein Volk gewählt.")
        else:
            lines.append(f"**{s2}** hat noch kein Volk gewählt.")

        # Wenn beide gewählt haben, Völker anzeigen und Zusammenfassung posten
        if civ_s1 and civ_s2:
            reveal_lines = [
                "Beide Spieler haben ihre Völker gewählt.",
                f"**{s1}** spielt: **{civ_s1}**",
                f"**{s2}** spielt: **{civ_s2}**",
            ]
            await interaction.response.edit_message(
                embed=discord.Embed(
                    description="\n".join(reveal_lines),
                    color=discord.Color.green()
                ),
                view=None
            )

            # Positionswahl kommt nach dem Völkerpick, aber vor Map-Ausgabe.
            await interaction.followup.send(
                embed=_swiss_posi_prompt_embed(interaction.guild, g, s1, s2),
                view=PosiChoiceView(g, s1, s2)
            )
        else:
            await interaction.response.edit_message(
                embed=discord.Embed(
                    description="\n".join(lines),
                    color=discord.Color.blurple()
                ),
                view=self
            )


def _swiss_posi_chooser_name(rec: dict, s1: str, s2: str) -> str | None:
    """Who has the position choice based on the chosen option."""
    toss_winner = rec.get("toss_winner")
    mode_choice = rec.get("mode")
    if not toss_winner or mode_choice not in ("letzter_bann", "positionswahl"):
        return None
    loser = s2 if toss_winner == s1 else s1
    return toss_winner if mode_choice == "positionswahl" else loser

def _swiss_posi_prompt_embed(guild: discord.Guild, group: str, s1: str, s2: str) -> discord.Embed:
    rec = get_match_record(group, s1, s2) or {}
    chooser = _swiss_posi_chooser_name(rec, s1, s2)
    chooser_member = resolve_member_by_name(guild, chooser) if chooser else None
    chooser_mention = getattr(chooser_member, 'mention', None) or f"**{chooser or '—'}**"
    desc = (
        "📍 **Positionswahl / Position choice**\n"
        f"{chooser_mention} wählt jetzt die Position (Pos 1 oder Pos 2).\n"
        "Danach (bei HGHG) wird die Map ausgegeben."
    )
    return discord.Embed(description=desc, color=discord.Color.blurple())

def _swiss_summary_embed(rec: dict, s1: str, s2: str) -> discord.Embed:
    toss_winner = rec.get("toss_winner")
    toss_result = rec.get("toss_result")
    mode_choice = rec.get("mode")
    bans = rec.get("bans") or []
    final_mode = rec.get("final_mode")
    civ_s1 = rec.get("civ_s1")
    civ_s2 = rec.get("civ_s2")
    ban_s1 = rec.get("ban_s1")
    ban_s2 = rec.get("ban_s2")
    pos_s1 = rec.get("pos_s1")
    pos_s2 = rec.get("pos_s2")
    map_file = rec.get("map_file")
    map_mapper = rec.get("map_mapper")

    mode_text = {
        "letzter_bann": "Letzter Bann / Last ban",
        "positionswahl": "Positionswahl / Position choice",
    }.get(mode_choice, str(mode_choice) if mode_choice else "—")

    parts: list[str] = []
    if toss_result:
        parts.append(f"**Münzwurf Ergebnis / Coin toss result:** {toss_result}")
    parts.append(f"**Münzwurf-Gewinner / Coin toss winner:** {toss_winner or '—'}")
    parts.append(f"**Gewählte Option / Chosen option:** {mode_text}")
    if bans:
        parts.append("**Gebannte Modi / Banned modes:**")
        parts.append(f"• Bann {s1}: {ban_s1 or '—'}")
        parts.append(f"• Bann {s2}: {ban_s2 or '—'}")
    if final_mode:
        parts.append(f"**Zu spielender Modus / Mode to be played:** {final_mode}")

    parts.append("")
    parts.append("**Völker / Civilizations:**")
    parts.append(f"• {s1}: {civ_s1 or '—'}")
    parts.append(f"• {s2}: {civ_s2 or '—'}")

    if pos_s1 or pos_s2:
        parts.append("")
        parts.append("**Positionen / Positions:**")
        parts.append(f"• {s1}: {pos_s1 or '—'}")
        parts.append(f"• {s2}: {pos_s2 or '—'}")

    if final_mode and str(final_mode).upper() == "HGHG":
        parts.append("")
        if map_file:
            by = f" (von {map_mapper})" if map_mapper else ""
            parts.append(f"**Map:** {map_file}{by}")
        else:
            parts.append("**Map:** (wird separat gepostet / posted separately)")

    return discord.Embed(
        title="Match-Zusammenfassung / Match summary",
        description="\n".join(parts),
        color=discord.Color.gold()
    )


class PosiChoiceView(discord.ui.View):
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2

    async def _choose(self, interaction: discord.Interaction, want_pos: str):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return

        rec = get_match_record(g, s1, s2) or {}
        if not (rec.get("civ_s1") and rec.get("civ_s2")):
            await interaction.response.send_message("Bitte zuerst den Völkerpick abschließen.", ephemeral=True)
            return
        if rec.get("pos_s1") or rec.get("pos_s2"):
            await interaction.response.send_message("Positionswahl ist bereits abgeschlossen.", ephemeral=True)
            return

        chooser_name = _swiss_posi_chooser_name(rec, s1, s2)
        if not chooser_name:
            await interaction.response.send_message("Positionswahl ist aktuell nicht verfügbar.", ephemeral=True)
            return
        chooser_member = resolve_member_by_name(interaction.guild, chooser_name)
        if interaction.user.id != getattr(chooser_member, 'id', -1):
            await interaction.response.send_message("Nur der Positionswähler darf das auswählen.", ephemeral=True)
            return

        other_name = s2 if chooser_name == s1 else s1
        other_pos = "Pos 2" if want_pos == "Pos 1" else "Pos 1"
        if chooser_name == s1:
            pos_s1, pos_s2 = want_pos, other_pos
        else:
            pos_s1, pos_s2 = other_pos, want_pos

        upsert_match_record(g, s1, s2, pos_s1=pos_s1, pos_s2=pos_s2, pos_choice_by=chooser_name)

        await interaction.response.edit_message(
            embed=discord.Embed(
                description=(
                    "✅ Positionswahl gespeichert.\n"
                    f"• {s1}: **{pos_s1}**\n"
                    f"• {s2}: **{pos_s2}**"
                ),
                color=discord.Color.green()
            ),
            view=None
        )

        # If HGHG: pick + post map AFTER positions.
        rec2 = get_match_record(g, s1, s2) or {}
        final_mode = rec2.get("final_mode")
        if final_mode and str(final_mode).upper() == "HGHG" and not rec2.get("map_sent"):
            path, mapper = _swiss_choose_hghg_map(interaction.guild, s1, s2)
            if not path:
                await interaction.channel.send(
                    embed=discord.Embed(
                        description="⚠️ Keine Map-Datei in `Maps` gefunden (oder nur Mapper-Ordner).",
                        color=discord.Color.orange()
                    )
                )
            else:
                try:
                    with open(path, "rb") as fp:
                        file = discord.File(fp, filename=os.path.basename(path))
                        await interaction.channel.send(
                            content=f"🗺️ Karte von {mapper}. / Map by {mapper}.",
                            file=file
                        )
                    try:
                        _mark_played(path)
                        _move_to_played_folders(path)
                    except Exception:
                        pass
                    upsert_match_record(
                        g, s1, s2,
                        map_sent=True,
                        map_file=os.path.basename(path),
                        map_mapper=mapper,
                    )
                except Exception:
                    await interaction.channel.send(
                        embed=discord.Embed(description="⚠️ Map-Datei konnte nicht gesendet werden.", color=discord.Color.orange())
                    )

        # End protocol (always after positions; after map if HGHG)
        rec3 = get_match_record(g, s1, s2) or {}
        await interaction.channel.send(embed=_swiss_summary_embed(rec3, s1, s2))

    @discord.ui.button(label="Ich nehme Pos 1", style=discord.ButtonStyle.primary, custom_id="swiss_pos1")
    async def pos1(self, interaction: discord.Interaction, _button: discord.ui.Button):
        await self._choose(interaction, "Pos 1")

    @discord.ui.button(label="Ich nehme Pos 2", style=discord.ButtonStyle.secondary, custom_id="swiss_pos2")
    async def pos2(self, interaction: discord.Interaction, _button: discord.ui.Button):
        await self._choose(interaction, "Pos 2")

# ---------------- KO (HGHG only) flow ----------------

def _is_ko_group(group: str) -> bool:
    return str(group or "").startswith("KO-")

def _ko_maps_base() -> str:
    cfg = load_config()
    ko = cfg.get("ko") or {}
    rel = ko.get("maps_dir") or "Maps"
    return os.path.join(os.path.dirname(__file__), rel)

def _ko_previews_base() -> str:
    cfg = load_config()
    ko = cfg.get("ko") or {}
    rel = ko.get("previews_dir") or "MapPreviews"
    return os.path.join(os.path.dirname(__file__), rel)

def _ko_find_maps() -> list[str]:
    base = _ko_maps_base()
    entries: list[str] = []
    for root, _dirs, files in os.walk(base):
        for f in files:
            if not f.lower().endswith(".map"):
                continue
            if "WC2025-HGHG-" not in f:
                continue
            entries.append(os.path.join(root, f))
    return entries

def _ko_choose_map(guild: discord.Guild, s1: str, s2: str) -> str | None:
    """Pick a KO HGHG map, excluding mappers that are currently playing.

    Preference order:
    1) not-yet-played maps
    2) already-played maps (fallback)
    """
    fresh, fallback = _ko_candidate_maps(guild, s1, s2)
    cand = fresh or fallback
    return random.choice(cand) if cand else None

def _ko_candidate_maps(guild: discord.Guild, s1: str, s2: str) -> tuple[list[str], list[str]]:
    """Return (fresh, fallback) KO maps while excluding the current players' own maps."""
    base = _ko_maps_base()
    variants = _player_name_variants_for_exclusion(guild, s1, s2)
    try:
        played = set([str(x) for x in (_played_maps_state().get('played') or [])])
    except Exception:
        played = set()

    fresh: list[str] = []
    fallback: list[str] = []
    for path in _ko_find_maps():
        try:
            mapper = _mapper_folder_for_path(base, path)
        except Exception:
            mapper = ""
        if mapper and any(_similar(mapper, v) for v in variants):
            continue
        fn = os.path.basename(path)
        (fallback if fn in played else fresh).append(path)
    return fresh, fallback

def _ko_extract_map_num_int(path: str) -> int:
    try:
        return int(_ko_extract_map_num(path) or 0)
    except Exception:
        return 0

def _ko_choose_pair_for_final_g34(guild: discord.Guild, s1: str, s2: str) -> tuple[str | None, str | None]:
    """Choose two distinct maps for Grand Final games 3+4.

    The assignment to Game 3 and Game 4 is random.
    """
    fresh, fallback = _ko_candidate_maps(guild, s1, s2)
    all_maps: list[str] = list(fresh)
    all_maps.extend([p for p in fallback if p not in all_maps])
    if len(all_maps) < 2:
        return None, None

    first_pool = fresh or all_maps
    first = random.choice(first_pool)

    remaining_fresh = [p for p in fresh if p != first]
    remaining_all = [p for p in all_maps if p != first]
    second_pool = remaining_fresh or remaining_all
    if not second_pool:
        return None, None
    second = random.choice(second_pool)

    pair = [first, second]
    random.shuffle(pair)
    return pair[0], pair[1]

def _ko_extract_map_num(path: str) -> str | None:
    name = os.path.basename(path)
    m = re.search(r"WC2025-HGHG-(\d+)", name)
    return m.group(1) if m else None

def _ko_find_preview(map_path: str) -> str | None:
    num = _ko_extract_map_num(map_path)
    if not num:
        return None
    candidates = []
    # same folder
    candidates.append(os.path.join(os.path.dirname(map_path), f"{num}.png"))
    # previews base
    candidates.append(os.path.join(_ko_previews_base(), f"{num}.png"))
    # common fallbacks
    candidates.append(os.path.join(_ko_maps_base(), "previews", f"{num}.png"))
    candidates.append(os.path.join(_ko_maps_base(), "preview", f"{num}.png"))
    candidates.append(os.path.join(_ko_maps_base(), f"{num}.png"))
    for p in candidates:
        if os.path.exists(p):
            return p
    return None

async def _ko_post_map_preview(channel: discord.TextChannel, map_path: str, game_no: int | None = None):
    prev = _ko_find_preview(map_path)
    num = _ko_extract_map_num(map_path) or "?"
    mapper = ""
    try:
        mapper = _mapper_folder_for_path(_ko_maps_base(), map_path)
    except Exception:
        mapper = ""
    game_label = f"Game {int(game_no)}" if game_no else "Nächstes Game"
    if prev and os.path.exists(prev):
        try:
            extra = f" — Karte von **{mapper}**" if mapper else ""
            await channel.send(content=f"🗺️ Preview für **{game_label}** / Preview for **{game_label}**: Map **{num}**{extra}", file=discord.File(prev))
        except Exception:
            await channel.send(content=f"🗺️ Preview für **{game_label}** / Preview for **{game_label}**: Map **{num}** (Preview konnte nicht gesendet werden)")
    else:
        await channel.send(embed=discord.Embed(description=f"⚠️ Preview für **{game_label}** nicht gefunden für Map **{num}** (`{num}.png`).", color=discord.Color.orange()))

async def _ko_post_map_file(channel: discord.TextChannel, map_path: str):
    try:
        mapper = ""
        try:
            mapper = _mapper_folder_for_path(_ko_maps_base(), map_path)
        except Exception:
            mapper = ""
        extra = f"Karte von **{mapper}**\n" if mapper else ""
        await channel.send(content=f"🗺️ Map-Datei / Map file:\n{extra}", file=discord.File(map_path))
        # Mark and move only after successful send.
        try:
            _mark_played(map_path)
        except Exception:
            pass
        try:
            _move_to_played_folders(map_path, preview_path=_ko_find_preview(map_path))
        except Exception:
            pass
    except Exception:
        await channel.send(embed=discord.Embed(description="⚠️ Map-Datei konnte nicht gesendet werden.", color=discord.Color.orange()))

def _ko_required_wins(group: str) -> int:
    # BO5 only for Final (KO-F-...)
    return 3 if "-F-" in str(group) else 2

def _ko_is_grand_final(group: str) -> bool:
    """True only for the actual Grand Final match (KO-F-M31)."""
    try:
        g = str(group or "")
        if not g.startswith("KO-"):
            return False
        parts = g.split("-")
        if len(parts) < 3:
            return False
        st = str(parts[1]).upper()
        mid = str(parts[2]).split("|")[0].upper()
        return st == "F" and mid == "M31"
    except Exception:
        return False

class KOCoinTossView(discord.ui.View):
    """KO coin toss.

    Restart/Resume:
    - timeout=None + fixed custom_ids, so clicks still work after a bot restart.
    - group/s1/s2 are read from the channel topic on every interaction.
    """

    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None, caller_id: int | None = None, game_no: int | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2
        self.caller_id = int(caller_id) if caller_id is not None else 0
        self.game_no = int(game_no) if game_no is not None else 0

    async def _ensure_caller(self, interaction: discord.Interaction, rec: dict) -> bool:
        expected = int(rec.get("coin_caller_id") or self.caller_id or 0)
        if expected and interaction.user.id != expected:
            await interaction.response.send_message("Nur der ausgewählte Spieler darf den Münzwurf bedienen.", ephemeral=True)
            return False
        if not expected:
            # fallback: allow only the two players
            g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
            if not (g and s1 and s2):
                await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
                return False
            allowed = _players_ids_for(interaction.guild, s1, s2)
            if interaction.user.id not in allowed:
                await interaction.response.send_message("Nur die beiden Spieler dürfen den Münzwurf bedienen.", ephemeral=True)
                return False
        return True

    @discord.ui.button(label="Kopf / Heads", style=discord.ButtonStyle.primary, custom_id="ko_coin_head")
    async def head(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        if rec.get("ko_toss_winner") and int(rec.get("ko_game_no") or 0) == int(rec.get("ko_active_game_no") or 0 or self.game_no or 0):
            await interaction.response.send_message("Münzwurf ist bereits abgeschlossen.", ephemeral=True)
            return
        if not await self._ensure_caller(interaction, rec):
            return
        await self._toss(interaction, g, s1, s2, "Kopf")

    @discord.ui.button(label="Zahl / Tails", style=discord.ButtonStyle.primary, custom_id="ko_coin_tail")
    async def tail(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        if rec.get("ko_toss_winner") and int(rec.get("ko_game_no") or 0) == int(rec.get("ko_active_game_no") or 0 or self.game_no or 0):
            await interaction.response.send_message("Münzwurf ist bereits abgeschlossen.", ephemeral=True)
            return
        if not await self._ensure_caller(interaction, rec):
            return
        await self._toss(interaction, g, s1, s2, "Zahl")

    async def _toss(self, interaction: discord.Interaction, group: str, s1: str, s2: str, choice: str):
        result = random.choice(["Kopf", "Zahl"])
        s1_member = resolve_member_by_name(interaction.guild, s1)
        guesser = interaction.user
        if guesser.id == getattr(s1_member, "id", -1):
            winner_name = s1 if choice == result else s2
        else:
            winner_name = s2 if choice == result else s1

        # store toss winner for this game
        rec0 = get_match_record(group, s1, s2) or {}
        game_no = int(rec0.get("ko_active_game_no") or rec0.get("ko_game_no") or self.game_no or 0)

        upsert_match_record(group, s1, s2, ko_toss_result=result, ko_toss_winner=winner_name, ko_game_no=game_no)

        if game_no == 1:
            await interaction.response.edit_message(
                embed=discord.Embed(
                        description=(
                            f"🪙 Ergebnis: **{result}** — Gewinner: **{winner_name}**\n\n"
                            "Der Münzwurf-Gewinner wählt nun, in welchem Game er **Counterpick** möchte."
                        ),
                    color=discord.Color.green()
                ),
                view=KOCounterpickChoiceView(group, s1, s2)
            )
        else:
            # Game toss (used for side/position choice in Grand Final games 3/4/5).
            is_final = _ko_is_grand_final(group)
            if is_final and game_no in (3, 4, 5):
                note = "Der Münzwurf-Gewinner darf **Seite/Position (Pos 1/2)** wählen.\nCiv-Picks sind **blind**."
                note_en = "The coin toss winner chooses the **side/position (Pos 1/2)**.\nCiv picks are **blind**."
            else:
                note = "Hinweis: Dieser Münzwurf wirkt sich nur später auf die Seitenwahl aus."
                note_en = "Note: this coin toss only affects the later side choice."
            await interaction.response.edit_message(
                embed=discord.Embed(
                        description=(
                            f"🪙 Ergebnis: **{result}** — Gewinner: **{winner_name}**\n\n"
                            f"{note}\n{note_en}"
                        ),
                    color=discord.Color.green()
                ),
                view=None
            )
            await _ko_start_game(interaction.channel, group, s1, s2)

class KOCounterpickChoiceView(discord.ui.View):
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2

    async def _only_winner(self, interaction: discord.Interaction, toss_winner: str) -> bool:
        m = resolve_member_by_name(interaction.guild, toss_winner)
        if interaction.user.id != getattr(m, "id", -1):
            await interaction.response.send_message("Nur der Münzwurf-Gewinner darf das wählen.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Counterpick in Game 1", style=discord.ButtonStyle.primary, custom_id="ko_cp_g1")
    async def g1(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        toss_winner = rec.get("ko_toss_winner")
        if not toss_winner:
            await interaction.response.send_message("Kein Münzwurf-Winner gespeichert. Bitte /matchstart erneut ausführen.", ephemeral=True)
            return
        if not await self._only_winner(interaction, toss_winner):
            return
        upsert_match_record(g, s1, s2, ko_counterpick_game=1)
        await interaction.response.edit_message(embed=discord.Embed(description="✅ Counterpick: **Game 1**", color=discord.Color.blurple()), view=None)
        await _ko_start_game(interaction.channel, g, s1, s2)

    @discord.ui.button(label="Counterpick in Game 2", style=discord.ButtonStyle.secondary, custom_id="ko_cp_g2")
    async def g2(self, interaction: discord.Interaction, _button: discord.ui.Button):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not g:
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        toss_winner = rec.get("ko_toss_winner")
        if not toss_winner:
            await interaction.response.send_message("Kein Münzwurf-Winner gespeichert. Bitte /matchstart erneut ausführen.", ephemeral=True)
            return
        if not await self._only_winner(interaction, toss_winner):
            return
        upsert_match_record(g, s1, s2, ko_counterpick_game=2)
        await interaction.response.edit_message(embed=discord.Embed(description="✅ Counterpick: **Game 2**", color=discord.Color.blurple()), view=None)
        await _ko_start_game(interaction.channel, g, s1, s2)

def _ko_used_civs(rec: dict, s1: str, s2: str) -> dict:
    d = rec.get("ko_used_civs")
    if not isinstance(d, dict):
        d = {s1: [], s2: []}
    d.setdefault(s1, [])
    d.setdefault(s2, [])
    return d

def _ko_next_game_no(rec: dict) -> int:
    # Prefer wins-based inference (robust across restarts), fall back to stored counter.
    try:
        wins = rec.get("ko_wins")
        if isinstance(wins, dict) and wins:
            # we don't know s1/s2 here, so the caller may override; keep legacy fallback.
            pass
    except Exception:
        pass
    return int(rec.get("ko_next_game", 1) or 1)

async def _ko_start_game(channel: discord.TextChannel, group: str, s1: str, s2: str):
    """Start or resume the current KO game setup.

    Behavior:
    - Always posts the PNG preview early.
    - Civ picks happen next.
    - NEW: Position choice happens *after* civ picks and *before* posting the .map file.
    - If the bot was restarted, re-running /matchstart will resume based on persisted state.
    """
    rec = get_match_record(group, s1, s2) or {}

    # Determine game number from wins (authoritative), fallback to stored counter.
    try:
        wins = rec.get("ko_wins") or {}
        if isinstance(wins, dict):
            game_no = int(wins.get(s1, 0) or 0) + int(wins.get(s2, 0) or 0) + 1
        else:
            game_no = _ko_next_game_no(rec)
    except Exception:
        game_no = _ko_next_game_no(rec)

    is_grand_final = _ko_is_grand_final(group)
    uses_reserved_final_pair = is_grand_final and game_no in (3, 4)
    reserved_map3 = rec.get("ko_final_g34_map3")
    reserved_map4 = rec.get("ko_final_g34_map4")
    pair_previews_posted = bool(rec.get("ko_final_g34_previews_posted"))

    if uses_reserved_final_pair:
        maps_ok = (
            isinstance(reserved_map3, str) and reserved_map3 and os.path.exists(reserved_map3)
            and isinstance(reserved_map4, str) and reserved_map4 and os.path.exists(reserved_map4)
            and reserved_map3 != reserved_map4
        )
        if not maps_ok:
            reserved_map3, reserved_map4 = _ko_choose_pair_for_final_g34(channel.guild, s1, s2)
            if not reserved_map3 or not reserved_map4:
                await channel.send(embed=discord.Embed(description="⚠️ Nicht genug passende HGHG Maps für das Finale (Game 3+4) gefunden.", color=discord.Color.red()))
                return
            upsert_match_record(
                group, s1, s2,
                ko_final_g34_map3=reserved_map3,
                ko_final_g34_map4=reserved_map4,
                ko_final_g34_previews_posted=False,
            )
            rec = get_match_record(group, s1, s2) or {}
            reserved_map3 = rec.get("ko_final_g34_map3")
            reserved_map4 = rec.get("ko_final_g34_map4")
            pair_previews_posted = bool(rec.get("ko_final_g34_previews_posted"))
        desired_map_path = reserved_map3 if game_no == 3 else reserved_map4
    else:
        desired_map_path = None

    # Reuse existing map if already chosen for this active game.
    active_game = int(rec.get("ko_active_game_no") or 0)
    map_path = rec.get("ko_active_map")
    if not (isinstance(map_path, str) and map_path and active_game == game_no and os.path.exists(map_path)):
        # choose a new map (exclude players' own maps)
        map_path = desired_map_path or _ko_choose_map(channel.guild, s1, s2)
        if not map_path:
            await channel.send(embed=discord.Embed(description="⚠️ Keine passenden HGHG Maps gefunden (Muster `WC2025-HGHG-XXXX.map`).", color=discord.Color.red()))
            return
        # reset per-game state
        upsert_match_record(
            group, s1, s2,
            ko_active_game_no=game_no,
            ko_active_map=map_path,
            ko_active_picks={},
            ko_active_pos_s1=None,
            ko_active_pos_s2=None,
            ko_active_map_sent=False,
            ko_current_map=map_path,
            ko_game_no=game_no,
        )
        rec = get_match_record(group, s1, s2) or {}

    await channel.send(embed=discord.Embed(title=f"🎮 Game {game_no}", description="HGHG (KO)", color=discord.Color.blurple()))
    if uses_reserved_final_pair:
        if game_no == 3 and not pair_previews_posted:
            await _ko_post_map_preview(channel, reserved_map3, game_no=3)
            await _ko_post_map_preview(channel, reserved_map4, game_no=4)
            upsert_match_record(group, s1, s2, ko_final_g34_previews_posted=True)
        elif game_no == 4 and not pair_previews_posted:
            await _ko_post_map_preview(channel, map_path, game_no=4)
    else:
        await _ko_post_map_preview(channel, map_path, game_no=game_no)

    # determine pick order and blind/non-blind
    counterpick_game = int(rec.get("ko_counterpick_game", 1) or 1)
    toss_winner = rec.get("ko_toss_winner")
    if game_no in (1, 2) and not toss_winner:
        await channel.send(embed=discord.Embed(description="⚠️ Kein Münzwurf-Winner gespeichert. Bitte /matchstart erneut ausführen.", color=discord.Color.orange()))
        return
    if game_no == 1:
        non_blind = True
        if counterpick_game == 1:
            # loser picks first, winner counterpicks
            first = s2 if toss_winner == s1 else s1
            second = toss_winner
        else:
            # winner picks first, loser counterpicks (since counterpick in game2)
            first = toss_winner
            second = s2 if toss_winner == s1 else s1
    elif game_no == 2:
        non_blind = True
        if counterpick_game == 1:
            # winner picks first in game2
            first = toss_winner
            second = s2 if toss_winner == s1 else s1
        else:
            # loser picks first in game2
            first = s2 if toss_winner == s1 else s1
            second = toss_winner
    else:
        non_blind = False
        first = None
        second = None

    # If picks are already done for this active game, continue with positions / map.
    rec2 = get_match_record(group, s1, s2) or {}
    active_picks = rec2.get("ko_active_picks")
    if not isinstance(active_picks, dict):
        # legacy fallback
        active_picks = rec2.get("ko_picks_partial")
    if not isinstance(active_picks, dict):
        active_picks = {}

    # Picks complete?
    if active_picks.get(s1) and active_picks.get(s2):
        # Positions done?
        if not rec2.get("ko_active_pos_s1") or not rec2.get("ko_active_pos_s2"):
            await channel.send(
                embed=discord.Embed(description="📍 Positionswahl: bitte Pos 1 oder Pos 2 wählen.", color=discord.Color.green()),
                view=KOPosiChoiceView(group, s1, s2)
            )
            return
        # Map already posted?
        if not bool(rec2.get("ko_active_map_sent")):
            await _ko_post_map_file(channel, map_path)
            upsert_match_record(group, s1, s2, ko_active_map_sent=True)
            rec3 = get_match_record(group, s1, s2) or {}
            await channel.send(embed=_ko_summary_embed(rec3, s1, s2, game_no))
        return

    used = _ko_used_civs(rec2, s1, s2)
    allow_repick = bool(_ko_is_grand_final(group) and int(game_no) >= 5)
    view = (
        KONonBlindPickView(group, s1, s2, first, second, used, map_path, game_no, picks=active_picks, allow_repick=allow_repick)
        if non_blind else
        KOBlindPickView(group, s1, s2, used, map_path, game_no, picks=active_picks, allow_repick=allow_repick)
    )
    await channel.send(embed=discord.Embed(description="Bitte Völker wählen. / Please pick civs.", color=discord.Color.green()), view=view)

class KONonBlindPickView(discord.ui.View):
    def __init__(self, group: str, s1: str, s2: str, first: str, second: str, used: dict, map_path: str, game_no: int, picks: dict | None = None, allow_repick: bool = False):
        super().__init__(timeout=900)
        self.group, self.s1, self.s2 = group, s1, s2
        self.first, self.second = first, second
        self.used = used
        self.allow_repick = bool(allow_repick)
        self.map_path = map_path
        self.game_no = int(game_no)
        self.picks: dict[str, str] = dict(picks or {})

        current = self.first if len(self.picks) == 0 else self.second
        placeholder = f"{current} ist dran …" if len(self.picks) else f"{first} pickt zuerst …"
        used_now = [] if self.allow_repick else (used.get(current) or [])
        self.select = discord.ui.Select(
            placeholder=placeholder,
            min_values=1,
            max_values=1,
            options=[discord.SelectOption(label=c) for c in CIVS if c not in used_now]
        )
        self.select.callback = self._on_pick
        self.add_item(self.select)

    async def _on_pick(self, interaction: discord.Interaction):
        current = self.first if len(self.picks) == 0 else self.second
        m = resolve_member_by_name(interaction.guild, current)
        if interaction.user.id != getattr(m, "id", -1):
            await interaction.response.send_message("Du bist gerade nicht dran.", ephemeral=True)
            return
        civ = self.select.values[0]
        self.picks[current] = civ
        # update used
        self.used.setdefault(current, [])
        if civ not in self.used[current]:
            self.used[current].append(civ)

        # next step
        if len(self.picks) == 1:
            # switch options to second picker excluding already used by second and excluding civ chosen by first? (allowed) - keep allowed
            used_second = [] if self.allow_repick else (self.used.get(self.second) or [])
            opts = [discord.SelectOption(label=c) for c in CIVS if c not in used_second]
            self.select.options = opts
            self.select.placeholder = f"{self.second} ist dran …"
            await interaction.response.edit_message(
                embed=discord.Embed(
                    description=f"✅ {current}: **{civ}**\n\nJetzt: **{self.second}**",
                    color=discord.Color.blurple(),
                ),
                view=self,
            )
            # persist partial
            upsert_match_record(self.group, self.s1, self.s2, ko_used_civs=self.used, ko_picks_partial=self.picks, ko_active_picks=self.picks)
            return

        # both done -> post summary and map
        upsert_match_record(
            self.group,
            self.s1,
            self.s2,
            ko_used_civs=self.used,
            ko_picks_last=self.picks,
            ko_active_picks=self.picks,
            ko_next_game=self.game_no + 1,
        )
        await interaction.response.edit_message(
            embed=discord.Embed(
                description=(
                    "✅ Picks:\n"
                    f"- {self.first}: **{self.picks[self.first]}**\n"
                    f"- {self.second}: **{self.picks[self.second]}**"
                ),
                color=discord.Color.green(),
            ),
            view=None,
        )
        await interaction.channel.send(
            embed=discord.Embed(
                description="✅ Picks gelockt. Jetzt Positionswahl (Pos 1 / Pos 2).",
                color=discord.Color.green(),
            ),
            view=KOPosiChoiceView(self.group, self.s1, self.s2)
        )

class KOBlindPickView(discord.ui.View):
    def __init__(self, group: str, s1: str, s2: str, used: dict, map_path: str, game_no: int, picks: dict | None = None, allow_repick: bool = False):
        super().__init__(timeout=900)
        self.group, self.s1, self.s2 = group, s1, s2
        self.used = used
        self.map_path = map_path
        self.game_no = int(game_no)
        self.allow_repick = bool(allow_repick)
        self.picks: dict[str, str] = dict(picks or {})
        # two selects, one per player
        used_s1 = [] if self.allow_repick else (used.get(s1) or [])
        used_s2 = [] if self.allow_repick else (used.get(s2) or [])
        self.sel1 = discord.ui.Select(placeholder=f"{s1} (blind) …", min_values=1, max_values=1,
                                     options=[discord.SelectOption(label=c) for c in CIVS if c not in used_s1])
        self.sel2 = discord.ui.Select(placeholder=f"{s2} (blind) …", min_values=1, max_values=1,
                                     options=[discord.SelectOption(label=c) for c in CIVS if c not in used_s2])
        # If already selected (resume), disable that select.
        if self.picks.get(self.s1):
            self.sel1.disabled = True
        if self.picks.get(self.s2):
            self.sel2.disabled = True
        self.sel1.callback = self._pick_s1
        self.sel2.callback = self._pick_s2
        self.add_item(self.sel1)
        self.add_item(self.sel2)

    async def _pick_s1(self, interaction: discord.Interaction):
        m = resolve_member_by_name(interaction.guild, self.s1)
        if interaction.user.id != getattr(m, "id", -1):
            await interaction.response.send_message("Nur Spieler 1 darf das bedienen.", ephemeral=True); return
        self.picks[self.s1] = self.sel1.values[0]
        upsert_match_record(self.group, self.s1, self.s2, ko_picks_partial=self.picks, ko_active_picks=self.picks)
        await self._maybe_finish(interaction)

    async def _pick_s2(self, interaction: discord.Interaction):
        m = resolve_member_by_name(interaction.guild, self.s2)
        if interaction.user.id != getattr(m, "id", -1):
            await interaction.response.send_message("Nur Spieler 2 darf das bedienen.", ephemeral=True); return
        self.picks[self.s2] = self.sel2.values[0]
        upsert_match_record(self.group, self.s1, self.s2, ko_picks_partial=self.picks, ko_active_picks=self.picks)
        await self._maybe_finish(interaction)

    async def _maybe_finish(self, interaction: discord.Interaction):
        # hide picks until both selected
        if len(self.picks) < 2:
            await interaction.response.edit_message(embed=discord.Embed(description="🔒 Blind Picks gespeichert. Warte auf den anderen Spieler…", color=discord.Color.blurple()), view=self)
            return
        # commit used
        for p,civ in self.picks.items():
            self.used.setdefault(p, [])
            if civ not in self.used[p]:
                self.used[p].append(civ)
        upsert_match_record(self.group, self.s1, self.s2, ko_used_civs=self.used, ko_picks_last=self.picks, ko_active_picks=self.picks, ko_next_game=self.game_no+1)
        await interaction.response.edit_message(
                embed=discord.Embed(
                    description=(
                        "✅ Blind Picks revealed:\n"
                        f"- {self.s1}: **{self.picks[self.s1]}**\n"
                        f"- {self.s2}: **{self.picks[self.s2]}**"
                    ),
                    color=discord.Color.green(),
                ),
                view=None,
            )
        await interaction.channel.send(
            embed=discord.Embed(
                description="✅ Picks gelockt. Jetzt Positionswahl (Pos 1 / Pos 2).",
                color=discord.Color.green(),
            ),
            view=KOPosiChoiceView(self.group, self.s1, self.s2)
        )


def _ko_summary_embed(rec: dict, s1: str, s2: str, game_no: int) -> discord.Embed:
    map_path = rec.get("ko_active_map") or rec.get("ko_current_map") or ""
    num = _ko_extract_map_num(map_path) or "?"
    mapper = ""
    try:
        mapper = _mapper_folder_for_path(_ko_maps_base(), map_path)
    except Exception:
        mapper = ""
    picks = rec.get("ko_active_picks") or rec.get("ko_picks_last") or {}
    if not isinstance(picks, dict):
        picks = {}
    pos_s1 = rec.get("ko_active_pos_s1") or "?"
    pos_s2 = rec.get("ko_active_pos_s2") or "?"
    extra = f" — Map by **{mapper}**" if mapper else ""
    desc = (
        f"**Game:** {game_no}\n"
        f"**Map:** {num}{extra}\n\n"
        f"**Picks:**\n"
        f"- {s1}: **{picks.get(s1, '?')}**\n"
        f"- {s2}: **{picks.get(s2, '?')}**\n\n"
        f"**Positionen:**\n"
        f"- {s1}: **{pos_s1}**\n"
        f"- {s2}: **{pos_s2}**\n\n"
        "Ablauf: Preview → Völkerpick → Positionswahl → Map-Datei"
    )
    return discord.Embed(title="📌 KO Endprotokoll", description=desc, color=discord.Color.green())


class KOPosiChoiceView(discord.ui.View):
    """KO Position choice (Pos 1 / Pos 2).

    Persistent: interactions keep working after a bot restart.
    """
    def __init__(self, group: str | None = None, s1: str | None = None, s2: str | None = None):
        super().__init__(timeout=None)
        self.group, self.s1, self.s2 = group, s1, s2

    async def _choose(self, interaction: discord.Interaction, choice: str):
        g, s1, s2 = _match_tuple_from_interaction(interaction, (self.group, self.s1, self.s2))
        if not (g and s1 and s2):
            await interaction.response.send_message("Kein Match-Topic gesetzt.", ephemeral=True)
            return
        rec = get_match_record(g, s1, s2) or {}
        # ensure picks exist
        picks = rec.get("ko_active_picks")
        if not isinstance(picks, dict):
            picks = rec.get("ko_picks_last")
        if not isinstance(picks, dict) or not picks.get(s1) or not picks.get(s2):
            await interaction.response.send_message("Bitte zuerst Völkerpicks abschließen.", ephemeral=True)
            return
        # ensure only players
        allowed = _players_ids_for(interaction.guild, s1, s2)
        if interaction.user.id not in allowed and interaction.user.id not in (config.get("turnierleitung_ids") or []):
            await interaction.response.send_message("Nur die beiden Spieler (oder Orga) dürfen das bedienen.", ephemeral=True)
            return

        # Grand Final special rules (side/position chooser)
        try:
            game_no = int(rec.get("ko_active_game_no") or 0)
        except Exception:
            game_no = 0
        if _ko_is_grand_final(g) and interaction.user.id not in (config.get("turnierleitung_ids") or []):
            toss_winner = rec.get("ko_toss_winner")
            try:
                cp_game = int(rec.get("ko_counterpick_game") or 0)
            except Exception:
                cp_game = 0

            # Games 1+2: counterpicker chooses the side
            if game_no in (1, 2):
                if not toss_winner or cp_game not in (1, 2):
                    await interaction.response.send_message("Finale: Bitte zuerst /matchstart (Münzwurf + Counterpick-Wahl) abschließen.", ephemeral=True)
                    return
                other = s2 if str(toss_winner).strip() == str(s1).strip() else s1
                counterpicker = toss_winner if cp_game == game_no else other
                m = resolve_member_by_name(interaction.guild, counterpicker)
                if interaction.user.id != getattr(m, "id", -1):
                    await interaction.response.send_message("Finale: Nur der **Counterpicker** darf die Seite/Position wählen.", ephemeral=True)
                    return

            # Games 3/4/5: coin toss winner chooses the side (toss must belong to this game)
            if game_no in (3, 4, 5):
                if not toss_winner or int(rec.get("ko_game_no") or 0) != game_no:
                    await interaction.response.send_message("Finale: Für dieses Game fehlt der Münzwurf. Bitte /matchstart ausführen.", ephemeral=True)
                    return
                m = resolve_member_by_name(interaction.guild, toss_winner)
                if interaction.user.id != getattr(m, "id", -1):
                    await interaction.response.send_message("Finale: Nur der **Münzwurf-Gewinner** darf die Seite/Position wählen.", ephemeral=True)
                    return
        # already chosen?
        if rec.get("ko_active_pos_s1") and rec.get("ko_active_pos_s2"):
            await interaction.response.send_message("Positionswahl ist bereits gesetzt.", ephemeral=True)
            return

        # assign positions: the clicker gets the selected position
        click_is_s1 = interaction.user.id == getattr(resolve_member_by_name(interaction.guild, s1), "id", -1)
        if click_is_s1:
            pos_s1 = choice
            pos_s2 = "Pos 2" if choice == "Pos 1" else "Pos 1"
        else:
            pos_s2 = choice
            pos_s1 = "Pos 2" if choice == "Pos 1" else "Pos 1"

        upsert_match_record(g, s1, s2, ko_active_pos_s1=pos_s1, ko_active_pos_s2=pos_s2, ko_pos_by=int(interaction.user.id))

        await interaction.response.edit_message(
            embed=discord.Embed(
                description=(
                    f"✅ Positionswahl gesetzt:\n"
                    f"- {s1}: **{pos_s1}**\n"
                    f"- {s2}: **{pos_s2}**"
                ),
                color=discord.Color.green(),
            ),
            view=None,
        )

        # now post map file (only once)
        rec2 = get_match_record(g, s1, s2) or {}
        map_path = rec2.get("ko_active_map") or rec2.get("ko_current_map")
        game_no = int(rec2.get("ko_active_game_no") or rec2.get("ko_game_no") or 0)
        if map_path and not bool(rec2.get("ko_active_map_sent")):
            await _ko_post_map_file(interaction.channel, str(map_path))
            upsert_match_record(g, s1, s2, ko_active_map_sent=True)
            rec3 = get_match_record(g, s1, s2) or {}
            await interaction.channel.send(embed=_ko_summary_embed(rec3, s1, s2, game_no))

    @discord.ui.button(label="Ich nehme Pos 1", style=discord.ButtonStyle.primary, custom_id="ko_pos1")
    async def pos1(self, interaction: discord.Interaction, _button: discord.ui.Button):
        await self._choose(interaction, "Pos 1")

    @discord.ui.button(label="Ich nehme Pos 2", style=discord.ButtonStyle.secondary, custom_id="ko_pos2")
    async def pos2(self, interaction: discord.Interaction, _button: discord.ui.Button):
        await self._choose(interaction, "Pos 2")