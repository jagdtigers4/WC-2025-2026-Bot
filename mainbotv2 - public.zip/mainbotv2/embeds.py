import discord
from datetime import datetime

def get_now():
    return datetime.now().strftime("%d.%m.%y %H:%M")



def embed_group_table(group, players, sieges):
    # players are expected to be pre-sorted (desc by wins)
    lines = []
    for i, p in enumerate(players, start=1):
        wins = int(sieges.get(p, 0) or 0)
        lines.append(f"{i}. **{p}** — Siege: {wins}")
    text = "\n".join(lines) if lines else "_(keine Einträge)_"
    return discord.Embed(
        title=f"{group} – Tabelle",
        description=text,
        color=discord.Color.blurple()
    )

def embed_result(group, s1, s2, winner, by=None, date=None, time=None, change_note=None, image_url: str | None = None, mode: str | None = None, score: str | None = None):
    desc = f"**{group}** — {s1} vs {s2}\n\n**Sieger / Winner:** **{winner}**"\
        + (f"\n**Score:** `{score}`" if score else "")
    when = " ".join(x for x in [(date or "").strip(), (time or "").strip()] if x).strip()
    if when:
        desc += f"\n**Match-Termin:** `{when}`"
    if mode:
        # Schön formatieren: "metzel" -> "Metzel", "buddel" -> "Buddel", "HGHG" bleibt groß.
        m = str(mode)
        ml = m.lower()
        if ml == "metzel":
            label = "Metzel"
        elif ml == "buddel":
            label = "Buddel"
        elif m.upper() == "HGHG":
            label = "HGHG"
        else:
            label = m
        desc += f"\nMode: {label}"
    if change_note:
        desc += f"\n\n_Änderung:_ {change_note}"
    em = discord.Embed(title="🏆 Spielergebnis / Result", description=desc, color=discord.Color.gold())
    if image_url:
        try:
            em.set_image(url=image_url)
        except Exception:
            pass
    em.set_footer(text="Bestätigt am " + get_now() + (f" • durch {by}" if by else ""))
    return em


def embed_termin_list(lines: list[str]):
    if not lines:
        desc = "_(Noch keine Termine / No upcoming dates)_"
    else:
        desc = "\n".join(lines)
    return discord.Embed(title="📅 Bestätigte Turnier-Termine / Confirmed dates", description=desc, color=discord.Color.green())

def embed_cancel_request(user, reason, group, s1, s2, channel=None, datum=None, uhrzeit=None, p1m=None, p2m=None):
    """Storno-Anfrage sichtbar im Orga/Cancel-Channel."""
    title = "🛑 Termin-Storno angefragt / Date cancel requested"
    desc = f"Match: **{group}** — {s1} vs {s2}"
    if datum and uhrzeit:
        desc += f"\nTermin: `{datum} {uhrzeit}`"
    if p1m or p2m:
        desc += f"\nSpieler / Players: {(p1m or s1)} vs {(p2m or s2)}"
    if channel:
        desc += f"\nMatch-Channel: {channel.mention}"
    em = discord.Embed(title=title, description=desc, color=discord.Color.red())
    em.add_field(name="Von / From", value=f"<@{user.id}>", inline=True)
    em.add_field(name="Grund / Reason", value=reason or "-", inline=False)
    em.set_footer(text=get_now())
    return em

def embed_hilfe_request(user, reason, group, s1, s2, channel):
    em = discord.Embed(
        title="❗ Hilfe-Anfrage / Help request",
        description=f"Match: {group} {s1} vs {s2}\nSprung / Jump: {channel.mention}",
        color=discord.Color.red())
    em.add_field(name="Von / From", value=f"<@{user.id}>", inline=True)
    em.add_field(name="Beschreibung / Description", value=reason or "-", inline=False)
    em.set_footer(text=get_now())
    return em

def embed_termin_proposed(group, s1, s2, datum, uhrzeit, proposer_mention, p1_mention=None, p2_mention=None):
    em = discord.Embed(
        title="📅 Terminvorschlag / Proposed date",
        description=f"**{group}** — {s1} vs {s2}",
        color=discord.Color.blurple())
    em.add_field(name="Datum / Date", value=datum, inline=True)
    em.add_field(name="Uhrzeit / Time", value=uhrzeit, inline=True)
    if p1_mention or p2_mention:
        em.add_field(name="Spieler / Players", value=f"{p1_mention or s1} vs {p2_mention or s2}", inline=False)
        em.add_field(name="Aktion / Action",
                     value=f"{(p1_mention or s1)} & {(p2_mention or s2)}: **Bestätigen** oder **Ablehnen**.",
                     inline=False)
    em.add_field(name="Vorgeschlagen von / Proposed by", value=proposer_mention, inline=False)
    em.set_footer(text=get_now())
    return em

def embed_termin_confirmed(group, s1, s2, datum, uhrzeit, p1m=None, p2m=None):
    em = discord.Embed(
        title="✅ Termin bestätigt / Date confirmed",
        description=f"**{group}** — {s1} vs {s2}",
        color=discord.Color.green())
    em.add_field(name="Datum / Date", value=datum, inline=True)
    em.add_field(name="Uhrzeit / Time", value=uhrzeit, inline=True)
    if p1m or p2m:
        em.add_field(name="Spieler / Players", value=f"{p1m or s1} vs {p2m or s2}", inline=False)
    em.set_footer(text=get_now())
    return em


def embed_match_overview(lines: list[str]):
    """Embed für Orga-Matchübersicht. / Match overview embed for staff."""
    if not lines:
        desc = "_(Keine Matches gefunden / No matches found)_"
    else:
        desc = "\n".join(lines)
    return discord.Embed(
        title="🗂️ Match-Übersicht / Match overview",
        description=desc,
        color=discord.Color.blurple()
    )

# ---- VOD-Link Button (wird von bot.py importiert) ----


class _VodView(discord.ui.View):
    """View mit einem oder mehreren VOD-Buttons."""
    def __init__(self, urls: list[str]):
        super().__init__(timeout=None)
        if not urls:
            return
        if isinstance(urls, str):
            urls = [urls]
        for i, u in enumerate(urls, start=1):
            label = "▶ Watch / Ansehen" if len(urls) == 1 else f"▶ Watch {i}"
            self.add_item(discord.ui.Button(label=label, style=discord.ButtonStyle.link, url=u))

def vod_view(urls) -> discord.ui.View:
    """Liefert eine View mit Link-Button(s) zum VOD/Stream. / Returns a view with one or more VOD/stream link buttons."""
    if isinstance(urls, str):
        return _VodView([urls])
    try:
        urls = list(urls)
    except Exception:
        urls = [str(urls)]
    return _VodView(urls)