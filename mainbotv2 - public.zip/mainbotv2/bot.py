import os
import io
import csv
import re
import json
import random
import urllib.request
import asyncio
import discord
from discord.ext import commands, tasks
from discord import app_commands
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Optional
import datetime as _dt

# --- UI-Safety helpers (avoid console spam on short disconnects / expired interactions) ---

async def _safe_defer(i: discord.Interaction, *, ephemeral: bool = True):
    """Defer safely; swallow Unknown interaction / already responded errors."""
    try:
        if not i.response.is_done():
            await i.response.defer(ephemeral=ephemeral)
    except (discord.NotFound, discord.HTTPException, discord.InteractionResponded):
        return


async def _safe_send(
    i: discord.Interaction,
    *,
    content: str | None = None,
    embed: discord.Embed | None = None,
    view: discord.ui.View | None = None,
    ephemeral: bool = False,
):
    """Send safely; if interaction already responded, use followup."""
    try:
        # discord.py expects `view` to be either a View object or omitted.
        # Passing `view=None` may raise AttributeError (NoneType has no is_finished).
        kwargs = {"content": content, "embed": embed, "ephemeral": ephemeral}
        if view is not None:
            kwargs["view"] = view

        if i.response.is_done():
            await i.followup.send(**kwargs)
        else:
            await i.response.send_message(**kwargs)
    except (discord.NotFound, discord.HTTPException, discord.InteractionResponded):
        return


async def _safe_edit(
    i: discord.Interaction,
    *,
    content: str | None = None,
    embed: discord.Embed | None = None,
    view: discord.ui.View | None = None,
):
    """Safely acknowledge a component/modal interaction by editing the message.

    Order of preference:
    1) If we haven't responded yet: interaction.response.edit_message(...)
    2) If we already responded and have a message: interaction.message.edit(...)
    3) Fallback: edit_original_response / followup
    """
    payload = {}
    if content is not None:
        payload["content"] = content
    # allow embed=None to clear the embed
    payload["embed"] = embed
    if view is not None:
        payload["view"] = view

    try:
        if not i.response.is_done():
            # Correct for component interactions (selects/buttons) and modals
            await i.response.edit_message(**payload)
            return
    except (discord.NotFound, discord.HTTPException, discord.InteractionResponded):
        pass

    # If response is already done, edit the originating message if possible
    try:
        if getattr(i, "message", None) is not None:
            await i.message.edit(**payload)
            return
    except (discord.NotFound, discord.HTTPException):
        pass

    # Last resort: edit original response or send a followup
    try:
        await i.edit_original_response(**payload)
    except Exception:
        try:
            await i.followup.send(content=content, embed=embed, view=view, ephemeral=True)
        except Exception:
            return


class TippsEntryPersistentView(discord.ui.View):
    """Persistent entry view for the prediction game.
    This MUST be global so it survives bot restarts.
    """
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="✅ Check-In / Check-in", style=discord.ButtonStyle.success, custom_id="tipps_checkin")
    async def _btn(self, i: discord.Interaction, _b):
        from utils import tippspiel_checkin, tippspiel_ensure_user_visible, tippspiel_update_leaderboard_message
        tippspiel_checkin(i.user.id)
        tippspiel_ensure_user_visible(i.user.id)
        try:
            await tippspiel_update_leaderboard_message(i.client, i.guild)
        except Exception:
            pass
            await _safe_send(
                i,
                embed=_embed(
                    "✅ Du bist fürs Tippspiel eingecheckt. / You are checked in for the prediction game.",
                    discord.Color.green(),
                ),
                ephemeral=True,
            )
    @discord.ui.button(label="📝 Tipps / Tips", style=discord.ButtonStyle.primary, custom_id="tipps_open")
    async def _open(self, i: discord.Interaction, _b):
        await _send_tipps_ui(i)
def _extract_sheet_info(s: str) -> tuple[str, str]:
    return "", "0"
from utils import (
    load_config, save_json, is_admin, load_json,
    upsert_match_record, get_match_record,
    streamer_set, players_set, apps_state_get, apps_state_set,
    is_owner, get_role,
    ERGEBNISSE_PATH, TERMINE_PATH, UNCONFIRMED_PATH, MATCHES_PATH,
    APPS_STATE_PATH, STREAMERS_PATH, PLAYERS_PATH, COUNTERS_PATH, CANCEL_REQUESTS_PATH,
    KO_BRACKET_PATH,
    PLAYED_MAPS_KO_PATH,
    resolve_member_by_name,
    match_append_vod, match_set_stati_image, match_checked_in, match_add_checkin
)
from update import update_scoreboard_channel, update_termin_channel, update_stream_schedule_channel
from channels import create_matches, delete_matches
from embeds import vod_view
from dispatcher import change_winner, force_reset_match_state
from modals import TerminModal, HilfeModal
# --- Persistente Views defensiv importieren (optional vorhanden) ---
try:
    from modals import ConfirmedTerminPersistentView, ProposedTerminPersistentView, CancelApprovePersistentView, AppendTerminDecisionPersistentView
except Exception:
    ConfirmedTerminPersistentView = None
    ProposedTerminPersistentView = None
    CancelApprovePersistentView = None
try:
    from match import (
        WinnerApprovePersistentView, MatchRootPersistentView,
        CoinTossView, ModeChoiceView, BanFlowView, CivPickView, PosiChoiceView,
        KOCoinTossView, KOCounterpickChoiceView, KOPosiChoiceView
    )
except Exception:
    WinnerApprovePersistentView = None
    MatchRootPersistentView = None
    CoinTossView = None
    ModeChoiceView = None
    BanFlowView = None
    CivPickView = None
    PosiChoiceView = None
    KOCoinTossView = None
    KOCounterpickChoiceView = None
    KOPosiChoiceView = None
# -------------------------------------------------------------------
config = load_config()
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree
_GUILD = (discord.Object(id=config.get("guild_id")) if config.get("guild_id") else None)
@tree.command(name="test_registration_dm", description="Schickt dir (nur dir) die Registrierungs-DM als Test.", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def test_registration_dm_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung / No permission.", discord.Color.red()), ephemeral=True); return
    # Use your own name or a placeholder
    ing = interaction.user.display_name or interaction.user.name
    try:
        await interaction.user.send(embed=_registration_dm_embed(ing))
        await interaction.response.send_message(embed=_embed("✅ Test-DM gesendet (prüfe deine DMs).", discord.Color.green()), ephemeral=True)
    except discord.Forbidden:
        await interaction.response.send_message(embed=_embed("Kann dir keine DM senden. Bitte DMs erlauben.", discord.Color.orange()), ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(embed=_embed(f"Fehler beim Senden: {e}", discord.Color.red()), ephemeral=True)
@tree.command(name="export_participants_items_en", description="Export participants items (EN) <li>", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_participants_items_en_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Nur Turnierleitung.", discord.Color.red()), ephemeral=True); return
    from exporter import build_participants_snippet_en
    html = build_participants_snippet_en()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Participants items (EN):", file=discord.File(buf, filename="participants_block_en.html"), ephemeral=True)
@tree.command(name="export_participants_items_de", description="Export Teilnehmer-Items (DE) <li>", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_participants_items_de_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Nur Turnierleitung.", discord.Color.red()), ephemeral=True); return
    from exporter import build_participants_snippet_de
    html = build_participants_snippet_de()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Teilnehmer-Items (DE):", file=discord.File(buf, filename="participants_block_de.html"), ephemeral=True)
@tree.command(name="export_termine_items_en", description="Export schedule items (EN) <li>", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_termine_items_en_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Nur Turnierleitung.", discord.Color.red()), ephemeral=True); return
    from exporter import build_termine_block_en
    html = build_termine_block_en()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Schedule items (EN):", file=discord.File(buf, filename="termine_block_en.html"), ephemeral=True)
@tree.command(name="export_termine_items_de", description="Exportiere Termine-Items (DE) <li>", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_termine_items_de_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Nur Turnierleitung.", discord.Color.red()), ephemeral=True); return
    from exporter import build_termine_block_de
    html = build_termine_block_de()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Termine-Items (DE):", file=discord.File(buf, filename="termine_block_de.html"), ephemeral=True)
def _embed(text: str, color: discord.Color = discord.Color.blurple()) -> discord.Embed:
    return discord.Embed(description=text, color=color)
def _topic_tuple_from_channel(channel) -> tuple[str | None, str | None, str | None]:
    topic = getattr(channel, "topic", "") or ""
    parts = topic.split("|")
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    return None, None, None
def _is_player(guild: discord.Guild, user: discord.abc.User, s1: str, s2: str) -> bool:
    """True wenn `user` einer der beiden Spieler ist.

    Wichtig: `resolve_member_by_name()` verlässt sich auf den Guild Member Cache
    (`guild.get_member*`). Wenn der Cache (oder Members Intent) nicht vollständig
    ist, kann ein korrekt gemappter Spieler trotzdem als "nicht Spieler" gelten.

    Daher: erst direkt über players.json (Mapping) prüfen (case/whitespace tolerant),
    danach erst über Member-Resolve als Fallback.
    """

    def _n(x: object) -> str:
        return " ".join(str(x or "").strip().split()).casefold()

    uid = int(getattr(user, "id", 0) or 0)

    # 0) Direktes Mapping (ohne Member-Cache) für den aufrufenden User prüfen
    try:
        from utils import load_json
        pdata = load_json("players.json", {})
        rec = pdata.get(str(uid))
        if isinstance(rec, str):
            rec = {"ingame": rec, "aliases": [], "discord_names": []}
        if isinstance(rec, dict):
            pool = []
            pool.append(rec.get("ingame") or "")
            pool.extend(rec.get("aliases") or [])
            pool.extend(rec.get("discord_names") or [])
            pool_norm = {_n(p) for p in pool if str(p or "").strip()}
            if _n(s1) in pool_norm or _n(s2) in pool_norm:
                return True
    except Exception:
        pass

    # 1) Fallback: Member-Resolve (für Fälle ohne Mapping / direktes Matching)
    m1 = resolve_member_by_name(guild, s1)
    m2 = resolve_member_by_name(guild, s2)
    return (m1 and uid == getattr(m1, "id", 0)) or (m2 and uid == getattr(m2, "id", 0))
def _ch_mention(cid_key: str) -> str:
    cid = config.get(cid_key)
    return f"<#{cid}>" if cid else ""
async def _ensure_role(guild: discord.Guild, name: str, color: discord.Color) -> discord.Role:
    role = discord.utils.get(guild.roles, name=name)
    if role:
        return role
    try:
        return await guild.create_role(name=name, color=color, mentionable=False, reason="S4WC auto-setup")
    except Exception:
        return role or guild.default_role
async def _ensure_roles_and_perms(guild: discord.Guild):
    roles_cfg = (config.get("roles") or {})
    owner_name    = roles_cfg.get("owner")    if isinstance(roles_cfg.get("owner"), str)    else "Owner"
    admin_name    = roles_cfg.get("admin")    if isinstance(roles_cfg.get("admin"), str)    else "Admin"
    streamer_name = roles_cfg.get("streamer") if isinstance(roles_cfg.get("streamer"), str) else "Streamer"
    player_name   = roles_cfg.get("player")   if isinstance(roles_cfg.get("player"), str)   else "Player"
    viewer_name   = roles_cfg.get("viewer")   if isinstance(roles_cfg.get("viewer"), str)   else "Viewer"
    owner    = await _ensure_role(guild, owner_name,    discord.Color.from_str("#e11d48"))
    admin    = await _ensure_role(guild, admin_name,    discord.Color.from_str("#f59e0b"))
    streamer = await _ensure_role(guild, streamer_name, discord.Color.from_str("#8b5cf6"))
    player   = await _ensure_role(guild, player_name,   discord.Color.from_str("#10b981"))
    viewer   = await _ensure_role(guild, viewer_name,   discord.Color.from_str("#6b7280"))
    orga_channel_ids = [config.get("admin_channel_id"), config.get("hilfe_channel_id"), config.get("cancel_channel_id")]
    for cid in [c for c in orga_channel_ids if c]:
        ch = guild.get_channel(cid)
        if not isinstance(ch, (discord.TextChannel, discord.ForumChannel, discord.VoiceChannel)):
            continue
        ow = ch.overwrites
        for r in [owner, admin]:
            if not r: continue
            current = ow.get(r, discord.PermissionOverwrite())
            current.read_messages = True
            current.send_messages = True
            ow[r] = current
        for r in [viewer, player, streamer, guild.default_role]:
            if not r: continue
            current = ow.get(r, discord.PermissionOverwrite())
            current.read_messages = False
            current.send_messages = False
            ow[r] = current
        try:
            await ch.edit(overwrites=ow, reason="S4WC Orga-Channel lock")
        except Exception:
            pass
    async def _sync_viewer():
        return
def _registration_dm_embed(ingame: str) -> discord.Embed:
    rules = _ch_mention("rules_channel_id")
    maps  = _ch_mention("maps_channel_id")
    schedule_public = _ch_mention("termine_public_id")
    desc = (
        f"Willkommen, **{ingame}**! 🎉\n\n"
        f"**Links:**\n"
        f"• Regeln / Rules: {rules or '_n/a_'}\n"
        f"• Maps: {maps or '_n/a_'}\n"
        f"• Termine / Dates: {schedule_public or '_n/a_'}\n\n"
        f"Welcome, **{ingame}**! 🎉"
    )
    em = discord.Embed(title="✅ Registrierung bestätigt / Registration confirmed", description=desc, color=discord.Color.green())
    em.set_footer(text="S4 WC • GL & HF!")
    return em
def _announcement_embed(ingame: str, mention: str) -> discord.Embed:
    return discord.Embed(title="📣 Spieler registriert / Player registered", description=f"{mention} (**{ingame}**) hat sich registriert. / has registered.", color=discord.Color.blurple())
# ---------- DM-Blocking ----------
# Slash-Commands werden mit @app_commands.guild_only() geblockt (siehe unten).
# Prefix-Commands blocken wir global in DMs:
@bot.check
def _guild_only_prefix(ctx: commands.Context) -> bool:
    return ctx.guild is not None
# ---------------------------------
# Persistente Views registrieren (falls Klassen vorhanden)
@tree.command(name="add_player_to_match", description="(Orga) Spieler nachträglich zum aktuellen Match-Channel hinzufügen", guild=_GUILD)
@app_commands.describe(user="Discord-Nutzer, der Zugriff erhalten soll", as_name="Optional: exakter Ingame-Name aus dem Topic")
@app_commands.guild_only()
async def add_player_to_match(interaction: discord.Interaction, user: discord.Member, as_name: str | None = None):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
    ch = interaction.channel
    try:
        await interaction.response.defer(ephemeral=True)
    except Exception:
        pass
    # 1) Channel-Permissions nur für diesen Channel (keine Orga-Rechte!)
    try:
        await ch.set_permissions(user, view_channel=True, send_messages=True)
    except Exception as e:
        await interaction.followup.send(embed=_embed(f"Fehler bei Rechten: {e}", discord.Color.red()), ephemeral=True); return
    # 2) Versuche, den Nutzer einem der Spieler im Topic zuzuordnen
    topic = getattr(ch, "topic", "") or ""
    parts = topic.split("|")
    mapped = None
    if len(parts) == 3:
        group, s1, s2 = parts[0], parts[1], parts[2]
        cand = (as_name or "").strip() or (user.display_name or user.name)
        lc_s1, lc_s2 = s1.strip().lower(), s2.strip().lower()
        lc_cand = cand.strip().lower() if cand else ""
        target = None
        if lc_cand in {lc_s1, lc_s2}:
            target = s1 if lc_cand == lc_s1 else s2
        elif as_name and as_name.strip().lower() in {lc_s1, lc_s2}:
            target = s1 if as_name.strip().lower() == lc_s1 else s2
        else:
            # Auto: mappe auf den Spieler, der noch keinem Member zugeordnet ist
            try:
                from utils import resolve_member_by_name
                if not resolve_member_by_name(interaction.guild, s1):
                    target = s1
                elif not resolve_member_by_name(interaction.guild, s2):
                    target = s2
                else:
                    target = s1
            except Exception:
                target = s1
        if target:
            try:
                from utils import players_set
                players_set(user.id, ingame=target, alias=None, discord_name=(user.display_name or user.name))
                mapped = target
            except Exception:
                pass
    msg_ok = f"✅ {user.mention} hat Zugriff auf {ch.mention}."
    if mapped:
        msg_ok += f" Mapped als **{mapped}**."
    else:
        msg_ok += " Hinweis: Mapping nicht eindeutig. Falls Buttons nicht reagieren, nutze `as_name` exakt wie im Topic."
    await interaction.followup.send(embed=_embed(msg_ok, discord.Color.green()), ephemeral=True)
@tree.command(name="sync_commands", description="(Owner) Slash-Commands neu synchronisieren", guild=_GUILD)
@app_commands.guild_only()
async def sync_commands_cmd(interaction: discord.Interaction):
    if not is_owner(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Owner. / Owner only.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    try:
        synced_global = await tree.sync()
        synced_guild = await tree.sync(guild=discord.Object(id=config["guild_id"])) if config.get("guild_id") else []
        await interaction.followup.send(embed=_embed(f"Neu synchronisiert. Global: {len(synced_global)}, Guild: {len(synced_guild)}", discord.Color.green()), ephemeral=True)
    except Exception as e:
        await interaction.followup.send(embed=_embed(f"Sync-Fehler: {e}", discord.Color.red()), ephemeral=True)
@bot.event
async def setup_hook():
    try:
        if ConfirmedTerminPersistentView:
            bot.add_view(ConfirmedTerminPersistentView())
        if ProposedTerminPersistentView:
            bot.add_view(ProposedTerminPersistentView())
        if CancelApprovePersistentView:
            bot.add_view(CancelApprovePersistentView())
        if WinnerApprovePersistentView:
            bot.add_view(WinnerApprovePersistentView())
        if MatchRootPersistentView:
            bot.add_view(MatchRootPersistentView())
        if AppendTerminDecisionPersistentView:
            bot.add_view(AppendTerminDecisionPersistentView())
        # Swiss /matchstart flow views (restart-proof)
        if CoinTossView:
            bot.add_view(CoinTossView())
        if ModeChoiceView:
            bot.add_view(ModeChoiceView())
        if BanFlowView:
            bot.add_view(BanFlowView())
        if CivPickView:
            bot.add_view(CivPickView())
        if PosiChoiceView:
            bot.add_view(PosiChoiceView())

        # KO /matchstart flow views (restart-proof)
        if KOCoinTossView:
            bot.add_view(KOCoinTossView())
        if KOCounterpickChoiceView:
            bot.add_view(KOCounterpickChoiceView())
        if KOPosiChoiceView:
            bot.add_view(KOPosiChoiceView())
        bot.add_view(TippsEntryPersistentView())
        bot.add_view(BonusPublicOverlayPersistentView())
        bot.add_view(BonusOrgaOverlayPersistentView())
    except Exception:
        pass
# ---- Fallback callbacks for export/post commands (used if decorators didn't register) ----
async def _fb_export_participants_html(interaction: discord.Interaction):
    """Export participants as HTML (fallback)."""
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    from exporter import build_participants_html
    html = build_participants_html()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Teilnehmerliste (HTML):", file=discord.File(buf, filename="participants.html"), ephemeral=True)
async def _fb_export_participants(interaction: discord.Interaction):
    """Export participants as HTML (alias; fallback)."""
    await _fb_export_participants_html(interaction)
def _safe_build_participants_embed():
    try:
        return _build_participants_embed()
    except Exception:
        # Minimal embed builder
        from utils import load_json
        data = load_json("players.json", {})
        pairs = []
        for k, v in (data or {}).items():
            if isinstance(v, str):
                ing, aliases = v, []
            else:
                ing = v.get("ingame") or v.get("ing") or v.get("name") or str(k)
                aliases = list(dict.fromkeys((v.get("aliases") or []) + (v.get("discord_names") or [])))
            pairs.append((ing, aliases))
        pairs.sort(key=lambda x: x[0].lower())
        desc = ""
        for ing, aliases in pairs:
            alias_txt = f" — _aka: {', '.join(aliases)}_" if aliases else ""
            desc += f"• **{ing}**{alias_txt}\n"
        return discord.Embed(title="👥 Teilnehmer / Participants", description=desc[:4000] or "_Keine Einträge_", color=discord.Color.blurple())
async def _fb_post_participants(interaction: discord.Interaction):
    """Post participants list to configured channel (fallback)."""
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    ch_id = config.get("participants_channel_id")
    ch = interaction.guild.get_channel(ch_id) if ch_id else None
    if not isinstance(ch, discord.TextChannel):
        await interaction.response.send_message(embed=_embed("Konfig: participants_channel_id fehlt/ungültig.", discord.Color.orange()), ephemeral=True); return
    try:
        await ch.purge(check=lambda m: m.author.id == bot.user.id)
    except Exception:
        pass
    await ch.send(embed=_safe_build_participants_embed())
    await interaction.response.send_message(embed=_embed("✅ Teilnehmerliste aktualisiert.", discord.Color.green()), ephemeral=True)
async def _fb_export_termine_html(interaction: discord.Interaction):
    """Export Termine as HTML (fallback)."""
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    try:
        from exporter import build_termine_html
        html = build_termine_html()
    except Exception:
        # minimal fallback
        from exporter import build_termine_ul_items
        from utils import load_json
        termine = load_json("termine.json", [])
        ul = build_termine_ul_items(termine)
        html = "<html><body>"+ul+"</body></html>"
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Termine (HTML):", file=discord.File(buf, filename="termine.html"), ephemeral=True)
async def _fb_export_ergebnisse_html(interaction: discord.Interaction):
    """Export Ergebnisse as HTML (fallback)."""
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    try:
        from exporter import build_ergebnisse_html_page
        html = build_ergebnisse_html_page()
    except Exception:
        from exporter import build_ergebnisse_html
        from utils import load_json
        matches = load_json("matches.json", [])
        ul = build_ergebnisse_html(matches)
        html = "<html><body>"+ul+"</body></html>"
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Ergebnisse (HTML):", file=discord.File(buf, filename="ergebnisse.html"), ephemeral=True)
@tree.command(name="post_participants", description="Poste die Teilnehmerliste in den konfigurierten Channel", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def post_participants_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    ch_id = config.get("participants_channel_id")
    ch = interaction.guild.get_channel(ch_id) if ch_id else None
    if not isinstance(ch, discord.TextChannel):
        await interaction.response.send_message(embed=_embed("Konfig: participants_channel_id fehlt/ungültig.", discord.Color.orange()), ephemeral=True); return
    try:
        await ch.purge(check=lambda m: m.author.id == bot.user.id)
    except Exception:
        pass
    try:
        em = _build_participants_embed()
    except Exception:
        from utils import load_json
        data = load_json("players.json", {})
        pairs = []
        for k, v in (data or {}).items():
            if isinstance(v, str):
                ing, aliases = v, []
            else:
                ing = v.get("ingame") or v.get("ing") or v.get("name") or str(k)
                aliases = list(dict.fromkeys((v.get("aliases") or []) + (v.get("discord_names") or [])))
            pairs.append((ing, aliases))
        pairs.sort(key=lambda x: x[0].lower())
        desc = ""
        for ing, aliases in pairs:
            alias_txt = f" — _aka: {', '.join(aliases)}_" if aliases else ""
            desc += f"• **{ing}**{alias_txt}\n"
        em = discord.Embed(title=f"👥 Teilnehmer / Participants ({len(pairs)})", description=desc[:4000] or "_Keine Einträge_", color=discord.Color.blurple())
    await ch.send(embed=em)
    await interaction.response.send_message(embed=_embed("✅ Teilnehmerliste aktualisiert.", discord.Color.green()), ephemeral=True)
@tree.command(name="export_participants_html", description="Exportiere Teilnehmerliste als HTML (Download)", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_participants_html_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    from exporter import build_participants_html
    html = build_participants_html()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Teilnehmerliste (HTML):", file=discord.File(buf, filename="participants.html"), ephemeral=True)
@tree.command(name="export_participants", description="Exportiere Teilnehmerliste als HTML (Alias)", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_participants_cmd(interaction: discord.Interaction):
    await export_participants_html_cmd(interaction)
@tree.command(name="export_termine_html", description="Exportiere anstehende Termine als HTML (Download)", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_termine_html_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    from exporter import build_termine_html
    html = build_termine_html()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Termine (HTML):", file=discord.File(buf, filename="termine.html"), ephemeral=True)
@tree.command(name="export_ergebnisse_html", description="Exportiere Ergebnisse als HTML (Download)", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def export_ergebnisse_html_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Admin/Owner.", discord.Color.red()), ephemeral=True); return
    from exporter import build_ergebnisse_html_page
    html = build_ergebnisse_html_page()
    import io
    buf = io.BytesIO(html.encode("utf-8"))
    await interaction.response.send_message(content="Ergebnisse (HTML):", file=discord.File(buf, filename="ergebnisse.html"), ephemeral=True)
@bot.event
async def on_ready():
    print(f"✅ Bot ist online: {bot.user}")
    guild = bot.get_guild(config["guild_id"])
    # Tippspiel: permanent leaderboard updater (edits one message in the scoreboard channel)
    try:
        if not hasattr(bot, "_tipps_lb_task"):
            import asyncio
            from utils import tippspiel_update_leaderboard_message
            async def _tipps_lb_loop():
                while True:
                    try:
                        g = bot.get_guild(config["guild_id"])
                        if g:
                            await tippspiel_update_leaderboard_message(bot, g)
                    except Exception:
                        pass
                    await asyncio.sleep(300)
            bot._tipps_lb_task = bot.loop.create_task(_tipps_lb_loop())
    except Exception:
        pass
    try:
        # Global sync zuerst – stellt sicher, dass globale Commands erscheinen
        synced_global = await tree.sync()
        print(f"🔁 Global Slash-Commands synchronisiert: {len(synced_global)}")
    except Exception as e:
        print(f"Global Sync-Fehler: {e}")
    try:
        synced_guild = await tree.sync(guild=discord.Object(id=config["guild_id"]))
        print(f"🔁 Guild Slash-Commands synchronisiert: {len(synced_guild)}")
        try:
            cmds = await tree.fetch_commands(guild=discord.Object(id=config["guild_id"]))
            print("📋 Guild Commands:", ", ".join(sorted(c.name for c in cmds)))
        except Exception as e:
            print(f"Fetch-Commands Fehler: {e}")
    except Exception as e:
        print(f"Guild Sync-Fehler: {e}")
    # Rest nicht blockieren, falls irgendwo Fehler fliegen
    try:
        await _ensure_roles_and_perms(guild)
    except Exception as e:
        print(f"Perm-Setup Fehler: {e}")
    try:
        await update_scoreboard_channel(guild, (config.get("gruppen") or {}), config.get("scoreboard_channel_id"))
    except Exception as e:
        print(f"Scoreboard-Update Fehler: {e}")
    try:
        tid = int(((config.get('channels', {}) or {}).get('termine_channel_id', 0)) or (config.get('termine_public_id', 0) or 0))
        if tid:
            await update_termin_channel(guild, tid)
    except Exception as e:
        print(f"Termin-Update Fehler: {e}")
    try:
        await update_stream_schedule_channel(guild, config.get("stream_schedule_channel_id"))
    except Exception as e:
        print(f"Stream-Schedule Fehler: {e}")

    try:
        from utils import civstats_update_message
        await civstats_update_message(bot, guild)
    except Exception as e:
        print(f"Civstats-Update Fehler: {e}")
    try:
        await applications_update_panel(guild)
    except Exception as e:
        print(f"Applications-Panel Fehler: {e}")
    try:
        if not applications_loop.is_running():
            # applications_loop.start() disabled
            pass
        if not reminder_loop.is_running():
            reminder_loop.start()
    except Exception as e:
        print(f"Loop-Start Fehler: {e}")
@bot.event
async def on_member_join(member: discord.Member):
    return
def _build_participants_embed():
    from utils import load_json
    data = load_json("players.json", {}) or {}
    # (ingame, aliases)-Paare sammeln
    pairs = []
    for k, v in (data or {}).items():
        if isinstance(v, str):
            ing = v.strip()
            aliases = []
        else:
            ing = (v.get("ingame") or v.get("ing") or v.get("name") or str(k)).strip()
            aliases = list(dict.fromkeys((v.get("aliases") or []) + (v.get("discord_names") or [])))
        if ing:
            pairs.append((ing, aliases))
    pairs.sort(key=lambda x: x[0].lower())
    if not pairs:
        return discord.Embed(
            title="👥 Teilnehmer / Participants",
            description="_Keine Einträge / No entries_",
            color=discord.Color.blurple()
        )
    # Beschreibung OHNE f-Strings aufbauen
    lines = []
    for ing, aliases in pairs:
        alias_txt = (" — _aka: " + ", ".join(aliases) + "_") if aliases else ""
        lines.append("• **{0}**{1}".format(ing, alias_txt))
    desc = "\n".join(lines)
    return discord.Embed(
        title="👥 Teilnehmer / Participants ({0})".format(len(pairs)),
        description=desc[:4000],
        color=discord.Color.blurple()
    )
# =========================
# CHANNEL / REFRESH COMMANDS
# =========================
@tree.command(name="gen_matches", description="Erstelle alle Match-Kanäle", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def gen_matches_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung! / No permission.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    await create_matches(interaction.guild)
    await interaction.followup.send(embed=_embed("✅ Matches wurden erstellt.", discord.Color.green()), ephemeral=True)
    # periodic tips leaderboard updater (edits a permanent message in the scoreboard channel)
    try:
        if not hasattr(bot, "_tipps_lb_task"):
            async def _tipps_lb_loop():
                import asyncio
                from utils import tippspiel_update_leaderboard_message
                while True:
                    try:
                        g = bot.get_guild(config["guild_id"])
                        if g:
                            await tippspiel_update_leaderboard_message(bot, g)
                    except Exception:
                        pass
                    await asyncio.sleep(300)  # 5 minutes
            bot._tipps_lb_task = bot.loop.create_task(_tipps_lb_loop())
    except Exception:
        pass
@tree.command(name="del_matches", description="Lösche alle Match-Kategorien", guild=_GUILD)
@app_commands.guild_only()
async def del_matches_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung! / No permission.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    # 1) delete channels/categories
    rep = await delete_matches(interaction.guild)
    # 2) reset KO + tips + match data for clean test runs
    try:
        from utils import reset_for_ko_testing
        reset_for_ko_testing(keep_tipps_channels=True)
    except Exception:
        pass
    # 3) clear tipps channels (signup + leaderboard)
    cleared_msgs = 0
    for cid in [TIPPS_ANMELDUNG_CHANNEL_ID, TIPPS_LEADERBOARD_CHANNEL_ID]:
        try:
            ch = interaction.guild.get_channel(int(cid))
            if isinstance(ch, discord.TextChannel):
                # purge as much as possible (bulk delete limit applies). Fallback to individual deletes.
                try:
                    deleted = await ch.purge(limit=2000)
                    cleared_msgs += len(deleted)
                except Exception:
                    async for m in ch.history(limit=200):
                        try:
                            await m.delete()
                            cleared_msgs += 1
                        except Exception:
                            pass
        except Exception:
            pass
    msg = (
        f"🗑️ Gelöscht: **{rep.get('channels_deleted',0)}** Channels, **{rep.get('categories_deleted',0)}** Kategorien.\n"
        f"🔄 Daten zurückgesetzt: Termine, Vorschläge, Ergebnisse, KO-Bracket, Tippspiel. / Data reset (dates, proposals, results, KO bracket, predictions).\n"
        f"🧽 Tippspiel-Channels geleert: **{cleared_msgs}** Nachrichten." 
    )
    if rep.get("errors"):
        # Most common reason: missing permissions (Manage Channels / Manage Roles)
        errs = ", ".join(rep["errors"][:6])
        msg += f"\n⚠️ Fehler (erste): {errs}"
    await interaction.followup.send(embed=_embed(msg, discord.Color.orange()), ephemeral=True)
@tree.command(name="clear_results", description="(Orga) Ergebnisse & Posts aufräumen", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def clear_results(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    save_json("ergebnisse.json", {})
    save_json(MATCHES_PATH, [])
    ch = interaction.guild.get_channel(config["ergebnisse_channel_id"])
    if isinstance(ch, discord.TextChannel):
        try: await ch.purge(check=lambda m: m.author.id == bot.user.id)
        except Exception: pass
    await update_scoreboard_channel(interaction.guild, config["gruppen"], config["scoreboard_channel_id"])
    await interaction.followup.send(embed=_embed("✅ Ergebnisse gelöscht und Channel aufgeräumt.", discord.Color.green()), ephemeral=True)
@tree.command(name="clear_termine", description="(Orga) Alle bestätigten Termine löschen", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def clear_termine(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    save_json("termine.json", [])
    tid = int(((config.get('channels', {}) or {}).get('termine_channel_id', 0)) or (config.get('termine_public_id', 0) or 0))
    if tid:
        await update_termin_channel(interaction.guild, tid)
    await update_stream_schedule_channel(interaction.guild, config.get("stream_schedule_channel_id"))
    await interaction.followup.send(embed=_embed("📅 Alle Termine gelöscht.", discord.Color.orange()), ephemeral=True)
@tree.command(name="clear_all", description="(Orga) Termine, Ergebnisse & Posts zurücksetzen", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def clear_all(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    # --- Datenbanken vollständig leeren ---
    save_json(ERGEBNISSE_PATH, {})
    save_json(TERMINE_PATH, [])
    save_json(UNCONFIRMED_PATH, [])
    save_json(MATCHES_PATH, [])
    # Spieler/Streamer/App-State/Cancels/Counters
    try: save_json(PLAYERS_PATH, {})
    except Exception: pass
    try: save_json(STREAMERS_PATH, {})
    except Exception: pass
    try: save_json(APPS_STATE_PATH, {"pending": []})
    except Exception: pass
    try: save_json(CANCEL_REQUESTS_PATH, [])
    except Exception: pass
    try: save_json(COUNTERS_PATH, {})
    except Exception: pass
    # --- Player-Rolle von allen Mitgliedern entfernen (falls gesetzt) ---
    try:
        roles_cfg = (config.get("roles") or {})
        player_name = roles_cfg.get("player") if isinstance(roles_cfg.get("player"), str) else "Player"
        player_role = discord.utils.get(interaction.guild.roles, name=player_name)
        if player_role:
            removed = 0
            for mem in list(interaction.guild.members):
                if player_role in getattr(mem, "roles", []):
                    try:
                        await mem.remove_roles(player_role, reason="Clear-All Reset")
                        removed += 1
                    except Exception:
                        pass
            print(f"Clear-All: Player-Rolle entfernt bei {removed} Mitgliedern.")
    except Exception as e:
        print(f"Player-Rollen-Reset Fehler: {e}")
    # --- Ergebnis-Channel leeren ---
    ch = interaction.guild.get_channel(config["ergebnisse_channel_id"])
    if isinstance(ch, discord.TextChannel):
        try: await ch.purge(check=lambda m: m.author.id == bot.user.id)
        except Exception: pass
    # --- Öffentliche Panels/Tabellen neu schreiben ---
    gruppen = config.get("gruppen") or []
    scoreboard_id = config.get("scoreboard_channel_id")
    if scoreboard_id:
        await update_scoreboard_channel(interaction.guild, gruppen, scoreboard_id)
    tid = int(((config.get('channels', {}) or {}).get('termine_channel_id', 0)) or (config.get('termine_public_id', 0) or 0))
    if tid:
        await update_termin_channel(interaction.guild, tid)
    stream_sched_id = config.get("stream_schedule_channel_id")
    if stream_sched_id:
        await update_stream_schedule_channel(interaction.guild, stream_sched_id)
    await interaction.followup.send(embed=_embed("🔄 Alles (inkl. Spieler/Streamer/App-State) zurückgesetzt.", discord.Color.orange()), ephemeral=True)
@tree.command(name="link", description="(Orga) VOD/Stream-Link einem Match zuordnen (mehrere möglich)", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(url="VOD-/Stream-Link", group="Gruppe (optional, im Match-Channel leer lassen)", s1="Spieler 1", s2="Spieler 2")
@app_commands.guild_only()
async def link_cmd(interaction: discord.Interaction, url: str, group: str | None = None, s1: str | None = None, s2: str | None = None):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    import re as _re
    if not _re.search(r"https?://", url, _re.IGNORECASE):
        await interaction.followup.send(embed=_embed("Bitte gültigen Link angeben. / Please provide a valid link.", discord.Color.orange()), ephemeral=True)
        return
    if not (group and s1 and s2):
        g, a, b = _topic_tuple_from_channel(interaction.channel)
        if g:
            group, s1, s2 = g, a, b
    if not (group and s1 and s2):
        await interaction.followup.send(embed=_embed("Match nicht eindeutig. Bitte im Match-Channel nutzen.", discord.Color.orange()), ephemeral=True)
        return
    match_append_vod(group, s1, s2, url)
    rec = get_match_record(group, s1, s2) or {}
    msg_id = rec.get("result_message_id")
    ch_id = rec.get("result_channel_id")
    try:
        if msg_id and ch_id:
            ch = interaction.guild.get_channel(ch_id)
            if isinstance(ch, discord.TextChannel):
                msg = await ch.fetch_message(msg_id)
                view = vod_view(rec.get("vod_urls") or rec.get("vod_url") or url)
                await msg.edit(view=view)
    except Exception:
        pass
    await interaction.followup.send(embed=_embed("▶ VOD-Link gespeichert. / VOD link saved.", discord.Color.green()), ephemeral=True)
@tree.command(name="streamer_profile", description="Streamer-Profil setzen (Name + Link)", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(name="Streamername", link="Kanal-Link (Twitch/YouTube/…)")
@app_commands.guild_only()
async def streamer_profile_cmd(interaction: discord.Interaction, name: str, link: str):
    roles_cfg = (config.get("roles") or {})
    names = {roles_cfg.get("streamer") or "Streamer", roles_cfg.get("admin") or "Admin", roles_cfg.get("owner") or "Owner"}
    if not any(getattr(r,'name','') in names for r in getattr(interaction.user,'roles', [])) and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(embed=_embed("Nur Streamer/Admin/Owner.", discord.Color.red()), ephemeral=True); return
    streamer_set(interaction.user.id, name, link)
    await interaction.response.send_message(embed=_embed("✅ Streamer-Profil gespeichert.", discord.Color.green()), ephemeral=True)
    await interaction.followup.send(embed=_embed("Profil gesetzt & Rolle vergeben. / Profile saved & role granted.", discord.Color.green()), ephemeral=True)
@tree.command(name="force_setwinner", description="(Owner) Sieger direkt setzen", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(winner="Siegername / Winner name", grund="Grund / Reason")
@app_commands.guild_only()
async def force_setwinner(interaction: discord.Interaction, winner: str, grund: str):
    if not is_owner(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Owner. / Owner only.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    topic = getattr(interaction.channel, "topic", "") or ""
    parts = topic.split("|")
    if len(parts) != 3:
        await interaction.followup.send(embed=_embed("Kein Match-Topic (Gruppe|Spieler1|Spieler2). / No match topic.", discord.Color.orange()), ephemeral=True); return
    group, s1, s2 = parts[0], parts[1], parts[2]
    if winner not in (s1, s2):
        await interaction.followup.send(embed=_embed("Winner muss Spieler1 oder Spieler2 sein. / Winner must be one of the two players.", discord.Color.orange()), ephemeral=True); return
    from dispatcher import handle_confirmed_win
    await handle_confirmed_win(interaction, group, s1, s2, winner, f"{interaction.user.name} (force: {grund})", config["ergebnisse_channel_id"])
    await interaction.followup.send(embed=_embed("⚠️ Sieger gesetzt (Force). / ⚠️ Winner set (force).", discord.Color.red()), ephemeral=True)
@tree.command(name="force_reset_channel", description="(Owner) Match-Kanal auf 0 zurücksetzen (Termine/UI)", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def force_reset_channel(interaction: discord.Interaction):
    if not is_owner(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Owner. / Owner only.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    topic = getattr(interaction.channel, "topic", "") or ""
    parts = topic.split("|")
    if len(parts) != 3:
        await interaction.followup.send(embed=_embed("Kein Match-Topic (Gruppe|Spieler1|Spieler2). / No match topic.", discord.Color.orange()), ephemeral=True); return
    group, s1, s2 = parts[0], parts[1], parts[2]
    await force_reset_match_state(interaction.guild, group, s1, s2, interaction.channel)
    await interaction.followup.send(embed=_embed("🔄 Kanal zurückgesetzt (Termine/UI). / 🔄 Channel reset (dates/UI).", discord.Color.orange()), ephemeral=True)

@tree.command(name="forcewinner", description="(Orga) **1 Game**-Sieg zuweisen (inkl. Völker) / Force a single game win (with civs)", guild=_GUILD)
@app_commands.describe(
    winner="Sieger (muss einer der beiden Spieler sein)",
    civ_winner="Volk Sieger",
    civ_loser="Volk Verlierer",
    stati="(Optional) Statistikbild für dieses Game (wird an Ergebnispost angehängt)",
    grund="Grund/Note",
)
@app_commands.guild_only()
async def forcewinner_cmd(
    interaction: discord.Interaction,
    winner: str,
    civ_winner: str,
    civ_loser: str,
    stati: discord.Attachment | None = None,
    grund: str = "",
):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    topic = getattr(interaction.channel, "topic", "") or ""
    parts = topic.split("|")
    if len(parts) != 3:
        await interaction.followup.send(embed=_embed("Kein Match-Topic (Gruppe|Spieler1|Spieler2). / No match topic.", discord.Color.orange()), ephemeral=True); return
    group, s1, s2 = parts[0], parts[1], parts[2]
    if not str(group).startswith("KO-"):
        await interaction.followup.send(embed=_embed("/forcewinner ist nur für KO-Matches gedacht. / KO only.", discord.Color.orange()), ephemeral=True); return
    winner = str(winner).strip()
    if winner not in (s1, s2):
        await interaction.followup.send(embed=_embed("Winner muss Spieler1 oder Spieler2 sein. / Winner must be one of the two players.", discord.Color.orange()), ephemeral=True); return
    loser = s2 if winner == s1 else s1
    try:
        from utils import upsert_match_record
        upsert_match_record(group, s1, s2, ko_picks_last={winner: str(civ_winner).strip(), loser: str(civ_loser).strip()})
    except Exception:
        pass

    # Optional: attach stats to the result post (same mechanism as /stati).
    if stati is not None:
        try:
            import os
            import datetime as _dt
            from utils import match_set_stati_image, upsert_match_record, get_match_record

            image_url = str(getattr(stati, "url", "") or "").strip()
            cached_path: str | None = None
            cache_dir = os.path.join(os.path.dirname(__file__), "data", "stati_cache")
            os.makedirs(cache_dir, exist_ok=True)
            # Save attachment to local cache
            fn = f"force_{group}_{int(_dt.datetime.now(_dt.timezone.utc).timestamp())}_{stati.filename or 'stati.png'}"
            cached_path = os.path.join(cache_dir, fn)
            await stati.save(cached_path)

            match_set_stati_image(group, s1, s2, image_url)
            rec0 = get_match_record(group, s1, s2) or {}
            wins0 = rec0.get("ko_wins") or {s1: 0, s2: 0}
            try:
                game_no = int(wins0.get(s1, 0) or 0) + int(wins0.get(s2, 0) or 0) + 1
            except Exception:
                game_no = 0
            upsert_match_record(
                group,
                s1,
                s2,
                stati_ts=_dt.datetime.now(_dt.timezone.utc).isoformat(),
                stati_game_no=game_no,
                stati_source_channel_id=None,
                stati_source_message_id=None,
                stati_local_path=cached_path,
            )
        except Exception:
            pass
    from dispatcher import handle_confirmed_win
    note = f"{interaction.user.name} (FORCE: {grund or 'forcewinner'})"
    await handle_confirmed_win(interaction, group, s1, s2, winner, note, config["ergebnisse_channel_id"])
    await interaction.followup.send(embed=_embed("⚠️ Forcewinner gesetzt (1 Game). / ⚠️ Forced (one game).", discord.Color.orange()), ephemeral=True)
def _player_role(guild: discord.Guild):
    rid = (config.get("roles") or {}).get("player")
    r = None
    if isinstance(rid, int): r = guild.get_role(rid)
    elif isinstance(rid, str): r = discord.utils.get(guild.roles, name=rid)
    if not r: r = discord.utils.get(guild.roles, name="Player")
    return r
def _post_json(url: str, payload: dict) -> bool:
    if not url: return False
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            _ = resp.read()
        return True
    except Exception:
        return False
class _SetIdModal(discord.ui.Modal, title="Discord-ID setzen / Set Discord ID"):
    def __init__(self, entry_idx: int):
        super().__init__()
        self.entry_idx = entry_idx
        self.add_item(discord.ui.TextInput(label="Discord-ID (Zahl)", placeholder="z. B. <DISCORD_USER_ID_EXAMPLE_001>"))
    async def on_submit(self, interaction: discord.Interaction):
        raw = self.children[0].value.strip()
        try:
            did = int(raw)
        except Exception:
            await interaction.response.send_message(embed=_embed("Ungültige ID. / Invalid ID.", discord.Color.red()), ephemeral=True); return
        st = apps_state_get()
        pend = st.get("pending", [])
        if 0 <= self.entry_idx < len(pend):
            pend[self.entry_idx]["discord_id"] = did
            apps_state_set(st)
            await applications_update_panel(interaction.guild)
            await interaction.response.send_message(embed=_embed("ID gesetzt. / ID saved.", discord.Color.green()), ephemeral=True)
        else:
            await interaction.response.send_message(embed=_embed("Eintrag nicht gefunden.", discord.Color.orange()), ephemeral=True)
class _DenyReasonModal(discord.ui.Modal, title="Ablehnen – Grund / Deny – Reason"):
    def __init__(self, entry_idx: int):
        super().__init__()
        self.entry_idx = entry_idx
        self.add_item(discord.ui.TextInput(label="Grund / Reason", placeholder="Optional", required=False))
    async def on_submit(self, interaction: discord.Interaction):
        reason = self.children[0].value.strip()
        await _deny_flow(interaction, self.entry_idx, reason)
class _ManageAppView(discord.ui.View):
    def __init__(self, entry_idx: int):
        super().__init__(timeout=300)
        self.entry_idx = entry_idx
    def _get_entry(self):
        st = apps_state_get()
        pend = st.get("pending", [])
        if 0 <= self.entry_idx < len(pend):
            return pend[self.entry_idx]
        return None
    async def _cleanup_popup(self, interaction: discord.Interaction):
        try:
            if interaction.message:
                await interaction.message.delete()
        except Exception:
            pass
    @discord.ui.button(label="ID setzen / Set ID", style=discord.ButtonStyle.secondary)
    async def setid(self, interaction: discord.Interaction, _):
        if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
            await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
        await interaction.response.send_modal(_SetIdModal(self.entry_idx))
    @discord.ui.button(label="Annehmen / Accept", style=discord.ButtonStyle.success)
    async def accept(self, interaction: discord.Interaction, _):
        if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
            await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
        await interaction.response.defer(ephemeral=True)
        entry = self._get_entry()
        if not entry:
            await interaction.followup.send(embed=_embed("Eintrag verschwunden. / Entry missing.", discord.Color.orange()), ephemeral=True)
            await self._cleanup_popup(interaction); return
        did = entry.get("discord_id")
        ing = entry.get("ingame_name")
        dn  = entry.get("discord_name")
        if not did:
            await interaction.followup.send(embed=_embed("Bitte zuerst die Discord-ID setzen.", discord.Color.orange()), ephemeral=True)
            await self._cleanup_popup(interaction); return
        try:
            member = interaction.guild.get_member(did) or (await interaction.guild.fetch_member(did))
        except Exception:
            member = None
        pr = _player_role(interaction.guild)
        if pr and member:
            try: await member.add_roles(pr, reason="S4WC registration accepted")
            except Exception: pass
        try:
            if member: await member.edit(nick=ing, reason="S4WC registration accepted")
        except Exception: pass
        players_set(did, ing, alias=ing, discord_name=dn)
        ann_id = config.get("announcements_channel_id")
        if ann_id:
            ann = interaction.guild.get_channel(ann_id)
            if isinstance(ann, discord.TextChannel):
                mention = f"<@{did}>"
                await ann.send(content=mention, embed=_announcement_embed(ing, mention))
        try:
            u = member or (await interaction.client.fetch_user(did))
            await u.send(embed=_registration_dm_embed(ing))
        except Exception:
            pass
        st = apps_state_get()
        pend = st.get("pending", [])
        if 0 <= self.entry_idx < len(pend):
            pend.pop(self.entry_idx)
            apps_state_set(st)
        _ = _post_json(config.get("applications_move_webhook", ""), {
            "action": "accept",
            "ingame_name": ing,
            "discord_name": dn,
            "discord_id": did
        })
        await applications_update_panel(interaction.guild)
        await interaction.followup.send(embed=_embed("✅ Angenommen. / Accepted.", discord.Color.green()), ephemeral=True)
        await self._cleanup_popup(interaction)
    
    @discord.ui.button(label="Doppelt / Duplicate", style=discord.ButtonStyle.secondary)
    async def duplicate(self, interaction: discord.Interaction, _):
        if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
            await interaction.response.send_message(embed=_embed("Keine Berechtigung / No permission.", discord.Color.red()), ephemeral=True); return
        await interaction.response.defer(ephemeral=True)
        entry = self._get_entry()
        if not entry:
            await interaction.followup.send(embed=_embed("Eintrag nicht gefunden.", discord.Color.orange()), ephemeral=True); return
        ing = entry.get("ingame_name") or entry.get("ingame") or ""
        dn  = entry.get("discord_name") or ""
        did = entry.get("discord_id")
        # Try to find member (optional)
        try:
            member = interaction.guild.get_member(did) or (await interaction.guild.fetch_member(did)) if did else None
        except Exception:
            member = None
        # Grant role / set nick like in accept, but SKIP any DM and ANNOUNCEMENT
        try:
            pr = _player_role(interaction.guild)
            if pr and member:
                try: await member.add_roles(pr, reason="S4WC registration accepted (duplicate)")
                except Exception: pass
            if member and ing:
                try: await member.edit(nick=ing, reason="S4WC registration accepted (duplicate)")
                except Exception: pass
        except Exception:
            pass
        # Update players.json
        players_set(did, ing, alias=ing, discord_name=dn)
        # Move from pending
        st = apps_state_get()
        pend = st.get("pending", [])
        if 0 <= self.entry_idx < len(pend):
            pend.pop(self.entry_idx)
            apps_state_set(st)
        _ = _post_json(config.get("applications_move_webhook", ""), {
            "action": "accept_duplicate",
            "ingame_name": ing,
            "discord_name": dn,
            "discord_id": did
        })
        await applications_update_panel(interaction.guild)
        await interaction.followup.send(embed=_embed("✅ Als doppelt markiert → akzeptiert (ohne zweite DM).", discord.Color.green()), ephemeral=True)
        await self._cleanup_popup(interaction)
    @discord.ui.button(label="Ablehnen / Deny", style=discord.ButtonStyle.danger)
    async def deny(self, interaction: discord.Interaction, _):
        if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
            await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
        await interaction.response.send_modal(_DenyReasonModal(self.entry_idx))
class _ApplicationsListView(discord.ui.View):
    def __init__(self, options: list[discord.SelectOption]):
        super().__init__(timeout=None)
        self.add_item(_AppsSelect(options))
class _AppsSelect(discord.ui.Select):
    def __init__(self, options: list[discord.SelectOption]):
        super().__init__(placeholder="Bewerbung auswählen / Select application", min_values=1, max_values=1, options=options)
    async def callback(self, interaction: discord.Interaction):
        idx = int(self.values[0])
        st = apps_state_get()
        pend = st.get("pending", [])
        if not (0 <= idx < len(pend)):
            await interaction.response.send_message(embed=_embed("Eintrag nicht gefunden.", discord.Color.orange()), ephemeral=True); return
        e = pend[idx]
        info = []
        info.append(f"Ingame: **{e.get('ingame_name','?')}**")
        if e.get("discord_name"): info.append(f"Discord: `{e['discord_name']}`")
        if e.get("discord_id"): info.append(f"ID: `{e['discord_id']}`")
        else: info.append("ID: _unbekannt / unknown_")
        embed = discord.Embed(title="Bewerbung verwalten / Manage application", description="\n".join(info), color=discord.Color.blurple())
        await interaction.response.send_message(embed=embed, view=_ManageAppView(idx), ephemeral=True)
async def _deny_flow(interaction: discord.Interaction, entry_idx: int, reason: str | None):
    await interaction.response.defer(ephemeral=True)
    st = apps_state_get()
    pend = st.get("pending", [])
    if not (0 <= entry_idx < len(pend)):
        await interaction.followup.send(embed=_embed("Eintrag nicht gefunden.", discord.Color.orange()), ephemeral=True); return
    e = pend[entry_idx]
    ing = e.get("ingame_name") or "?"
    dn  = e.get("discord_name") or "?"
    did = e.get("discord_id")
    _ = _post_json(config.get("applications_move_webhook", ""), {
        "action": "deny",
        "ingame_name": ing,
        "discord_name": dn,
        "discord_id": did,
        "reason": reason or ""
    })
    pend.pop(entry_idx)
    apps_state_set(st)
    try:
        if did:
            u = await interaction.client.fetch_user(did)
            em = discord.Embed(title="❌ Bewerbung abgelehnt / Application denied", description=f"Hallo, {ing}. Deine Bewerbung wurde leider abgelehnt.", color=discord.Color.red())
            if reason:
                em.add_field(name="Begründung / Reason", value=reason, inline=False)
            await u.send(embed=em)
    except Exception:
        pass
    await applications_update_panel(interaction.guild)
    await interaction.followup.send(embed=_embed("❌ Abgelehnt. / Denied.", discord.Color.red()), ephemeral=True)
async def applications_update_panel(guild: discord.Guild):
    st = apps_state_get()
    ch_id = config.get("admin_channel_id")
    if not ch_id: return
    ch = guild.get_channel(ch_id)
    if not ch: return
    pend = st.get("pending", [])
    if not pend:
        embed = discord.Embed(title="Bewerbungen / Applications", description="_Keine offenen Bewerbungen_\n\n_No pending applications_", color=discord.Color.dark_gray())
        view = None
    else:
        lines, options = [], []
        for i, e in enumerate(pend[:25]):
            dn = e.get("discord_name") or "?"
            ing = e.get("ingame_name") or "?"
            did = f" (ID {e['discord_id']})" if e.get("discord_id") else ""
            lines.append(f"{i+1}. **{ing}** — `{dn}`{did}")
            options.append(discord.SelectOption(label=f"{i+1}. {ing}", description=dn[:100], value=str(i)))
        embed = discord.Embed(title="Bewerbungen / Applications", description="\n".join(lines), color=discord.Color.blurple())
        view = _ApplicationsListView(options)
    msg_id = st.get("staff_msg_id")
    msg = None
    if msg_id:
        try: msg = await ch.fetch_message(int(msg_id))
        except Exception: msg = None
    if msg:
        await msg.edit(embed=embed, view=view)
    else:
        m = await ch.send(embed=embed, view=view)
        st["staff_msg_id"] = m.id
        apps_state_set(st)
def _match_discord_user(guild: discord.Guild, discord_name: str):
    dn = (discord_name or "").strip()
    if dn.startswith("<@") and dn.endswith(">"):
        try:
            did = int(re.sub(r"[<@!>]", "", dn))
            mem = guild.get_member(did)
            if mem: return mem
        except Exception:
            pass
    for m in guild.members:
        if m.name == dn or (m.global_name and m.global_name == dn) or m.display_name == dn:
            return m
    return None
@tasks.loop(minutes=60)
async def applications_loop():
    return
@tree.command(name="apps_refresh", description="Applications-Panel manuell aktualisieren", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def apps_refresh(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    await applications_update_panel(interaction.guild)
    await interaction.followup.send(embed=_embed("🔁 Applications-Panel aktualisiert.", discord.Color.blurple()), ephemeral=True)
@tree.command(
    name="matches_overview_refresh",
    description="(Orga) Match-Übersicht aktualisieren / Refresh match overview",
    guild=discord.Object(id=config["guild_id"])
)
@app_commands.guild_only()
async def matches_overview_refresh(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message(
            embed=_embed("Keine Berechtigung. / No permission.", discord.Color.red()),
            ephemeral=True
        )
        return
    overview_channel_id = int(config.get("orga_overview_channel_id", 0) or 0)
    if not overview_channel_id:
        await interaction.response.send_message(
            embed=_embed("Config-Schlüssel 'orga_overview_channel_id' fehlt oder ist 0. / Missing 'orga_overview_channel_id' in config.", discord.Color.orange()),
            ephemeral=True
        )
        return
    await interaction.response.defer(ephemeral=True)
    from update import update_orga_overview_channel
    await update_orga_overview_channel(interaction.guild, overview_channel_id)
    await interaction.followup.send(
        embed=_embed("🗂️ Match-Übersicht aktualisiert. / Match overview updated.", discord.Color.blurple()),
        ephemeral=True
    )
@tree.command(name="roles_setup", description="Rollen & Orga-Channel-Berechtigungen neu einrichten", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def roles_setup(interaction: discord.Interaction):
    if not is_owner(interaction.user, config) and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(embed=_embed("Nur Owner/Administrator.", discord.Color.red()), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    await _ensure_roles_and_perms(interaction.guild)
    await interaction.followup.send(embed=_embed("✅ Rollen & Berechtigungen geprüft/erstellt.", discord.Color.green()), ephemeral=True)
@tasks.loop(seconds=60)
async def reminder_loop():
    guild = bot.get_guild(config["guild_id"])
    # Tippspiel: permanent leaderboard updater (edits one message in the scoreboard channel)
    try:
        if not hasattr(bot, "_tipps_lb_task"):
            import asyncio
            from utils import tippspiel_update_leaderboard_message
            async def _tipps_lb_loop():
                while True:
                    try:
                        g = bot.get_guild(config["guild_id"])
                        if g:
                            await tippspiel_update_leaderboard_message(bot, g)
                    except Exception:
                        pass
                    await asyncio.sleep(300)
            bot._tipps_lb_task = bot.loop.create_task(_tipps_lb_loop())
    except Exception:
        pass
    ch_id = config.get("reminder_channel_id")
    if not guild or not ch_id:
        return
    ch = guild.get_channel(ch_id)
    if not isinstance(ch, discord.TextChannel):
        return
    viewer_name = (config.get("roles") or {}).get("viewer", "Viewer")
    viewer_role = discord.utils.get(guild.roles, name=viewer_name)
    termine = load_json("termine.json", [])
    matches = load_json(MATCHES_PATH, [])
    def _streamer_links(grp, s1, s2):
        rec = next((m for m in matches if m.get("gruppe") == grp and {m.get("spieler1"), m.get("spieler2")} == {s1, s2}), None)
        if not rec:
            return "", []
        ids = list(map(int, rec.get("stream_signups", []))) if rec.get("stream_signups") else []
        if not ids:
            return "", []
        parts = []
        from utils import streamer_get
        max_streamers = int(config.get("max_streamers", 3))
        for sid in ids[:max_streamers]:
            prof = streamer_get(sid) or {}
            nm = prof.get("name") or f"<@{sid}>"
            link = prof.get("link")
            parts.append(f"[{nm}]({link})" if link else nm)
        return " • " + " | ".join(parts), ids
    sent = load_json("reminders.json", {})
    sent_stream = load_json("stream_reminders.json", {})
    now = datetime.now(ZoneInfo("Europe/Berlin"))
    lead = int(config.get("reminder_minutes_before", 10))
    changed = False
    changed_stream = False
    for t in termine:
        try:
            dd, mm, yy = map(int, t["datum"].split("."))
            hh, mi = map(int, t["uhrzeit"].split(":"))
            start_dt = datetime(yy, mm, dd, hh, mi, tzinfo=ZoneInfo("Europe/Berlin"))
        except Exception:
            continue
        delta_min = (start_dt - now).total_seconds() / 60
        # Viewer-Reminder im globalen Reminder-Channel
        if 0 <= delta_min <= lead:
            key = f"{t['gruppe']}|{t['spieler1']}|{t['spieler2']}|{t['datum']} {t['uhrzeit']}"
            if not sent.get(key):
                streams_text, stream_ids = _streamer_links(t["gruppe"], t["spieler1"], t["spieler2"])
                em = discord.Embed(
                    title=f"🔔 In {lead} Min: {t['gruppe']} — {t['spieler1']} vs {t['spieler2']}",
                    description=f"`{t['datum']} {t['uhrzeit']}`{streams_text}",
                    color=discord.Color.gold()
                )
                send_kwargs = {"embed": em}
                # Viewer-Ping nur, wenn ein Streamer eingetragen ist
                if viewer_role and stream_ids:
                    send_kwargs["content"] = viewer_role.mention
                try:
                    await ch.send(**send_kwargs)
                    sent[key] = True
                    changed = True
                except Exception:
                    pass
        # Stream-spezifische Erinnerung direkt im Match-Channel (fix 5 Minuten vorher)
        streams_text, stream_ids = _streamer_links(t["gruppe"], t["spieler1"], t["spieler2"])
        if not stream_ids:
            continue
        if not (0 <= delta_min <= 5):
            continue
        s_key = f"{t['gruppe']}|{t['spieler1']}|{t['spieler2']}|{t['datum']} {t['uhrzeit']}|stream"
        if sent_stream.get(s_key):
            continue
        # Match-Channel anhand Topic "Gruppe|S1|S2" suchen
        match_channel = None
        for tc in guild.text_channels:
            try:
                topic = (tc.topic or "").strip() if isinstance(tc, discord.TextChannel) else ""
            except Exception:
                topic = ""
            if not topic:
                continue
            parts = [p.strip() for p in topic.split("|")]
            if len(parts) < 3:
                continue
            grp, s1, s2 = parts[0], parts[1], parts[2]
            if grp == t["gruppe"] and {s1, s2} == {t["spieler1"], t["spieler2"]}:
                match_channel = tc
                break
        if not isinstance(match_channel, discord.TextChannel):
            continue
        # Embed mit Streamer-Infos in den Match-Channel
        from utils import streamer_get
        streamer_lines = []
        for sid in stream_ids:
            prof = streamer_get(sid) or {}
            nm = prof.get("name") or f"<@{sid}>"
            link = prof.get("link")
            if link:
                streamer_lines.append(f"[{nm}]({link})")
            else:
                streamer_lines.append(f"<@{sid}>")
        if delta_min >= 1:
            title = f"🔴 Stream in {int(delta_min)} Minuten"
        elif delta_min < 0.5:
            title = "🔴 Stream startet jetzt"
        else:
            title = "🔴 Stream in wenigen Minuten"
        desc = (
            f"**{t['spieler1']}** vs **{t['spieler2']}**\n"
            f"`{t['datum']} {t['uhrzeit']}`\n\n"
            f"Streamer: {', '.join(streamer_lines)}"
        )
        em_stream = discord.Embed(title=title, description=desc, color=discord.Color.red())
        try:
            await match_channel.send(embed=em_stream)
            sent_stream[s_key] = True
            changed_stream = True
        except Exception:
            pass
    if changed:
        save_json("reminders.json", sent)
    if changed_stream:
        save_json("stream_reminders.json", sent_stream)
# -------------------- Orga-Commands: Bot-Konto --------------------
@tree.command(name="bot_status", description="Setze den Bot-Status/Presence (nur Orga)", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(status="online | idle | dnd | invisible", activity_type="playing | watching | listening | competing", text="Anzeigetext / activity text")
@app_commands.guild_only()
async def bot_status(interaction: discord.Interaction, status: str, activity_type: str, text: str):
    try:
        cmds = await tree.fetch_commands(guild=discord.Object(id=config["guild_id"]))
        cmd_names = ", ".join(sorted(c.name for c in cmds))
    except Exception:
        cmd_names = "(fetch error)"
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message("Nur Orga/Admin.", ephemeral=True); return
    s_map = {"online": discord.Status.online, "idle": discord.Status.idle, "dnd": discord.Status.dnd, "invisible": discord.Status.invisible}
    a_map = {"playing": discord.ActivityType.playing, "watching": discord.ActivityType.watching, "listening": discord.ActivityType.listening, "competing": discord.ActivityType.competing}
    st = s_map.get(status.lower()); at = a_map.get(activity_type.lower())
    if not st or not at:
        await interaction.response.send_message("Status: online/idle/dnd/invisible • Aktivität: playing/watching/listening/competing", ephemeral=True); return
    try:
        await interaction.client.change_presence(status=st, activity=discord.Activity(type=at, name=text))
        await interaction.response.send_message("✅ Presence aktualisiert.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Fehler: {e}", ephemeral=True)
@tree.command(name="bot_avatar", description="Setzt Bot-Profilbild (nur Orga)", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(image="Bilddatei anhängen")
@app_commands.guild_only()
async def bot_avatar(interaction: discord.Interaction, image: discord.Attachment):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message("Nur Orga/Admin.", ephemeral=True); return
    if not image or not (image.content_type or "").startswith("image/"):
        await interaction.response.send_message("Bitte ein Bild anhängen.", ephemeral=True); return
    try:
        data = await image.read()
        await interaction.client.user.edit(avatar=data)
        await interaction.response.send_message("✅ Avatar aktualisiert (Discord rate-limitiert Avatar-Änderungen).", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Fehler: {e}", ephemeral=True)
@tree.command(name="bot_nick", description="Setzt den Server-Nickname des Bots (nur Orga)", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(nickname="Neuer Anzeigename auf diesem Server")
@app_commands.guild_only()
async def bot_nick(interaction: discord.Interaction, nickname: str):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message("Nur Orga/Admin.", ephemeral=True); return
    try:
        me = interaction.guild.me
        await me.edit(nick=nickname, reason="Orga /bot_nick")
        await interaction.response.send_message(f"✅ Nickname geändert zu **{nickname}**.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Fehler: {e}", ephemeral=True)
@tree.command(name="assign_player_roles", description="Weist allen aus der Teilnehmer-Tabelle erkannten Nutzer die Player‑Rolle zu", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def assign_player_roles_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config.get("turnierleitung_ids", [])):
        await interaction.response.send_message("Nur Orga/Admin.", ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild
    # Ensure roles exist
    try:
        await _ensure_roles_and_perms(guild)
    except Exception:
        pass
    roles_cfg = (config.get("roles") or {})
    player_spec = roles_cfg.get("player") if isinstance(roles_cfg.get("player"), (str, int)) else "Player"
    player_role = get_role(guild, player_spec)
    if not isinstance(player_role, discord.Role):
        await interaction.followup.send("Player‑Rolle nicht gefunden/erstellbar.", ephemeral=True); return
    me = guild.me
    try:
        if me.top_role <= player_role:
            await interaction.followup.send("Bot-Rolle liegt nicht über der Player‑Rolle. Bitte Rolle des Bots höher ziehen.", ephemeral=True); return
    except Exception:
        pass
    data = load_json("players.json", {}) or {}
    assigned = skipped = errors = migrated = 0
    rename_map = {}  # old_key -> str(new_id)
    def find_member_by_names(candidates: list[str]) -> discord.Member | None:
        for n in candidates:
            m = resolve_member_by_name(guild, n)
            if isinstance(m, discord.Member):
                return m
        return None
    for key, rec in list(data.items()):
        # Collect candidates
        ingame = (rec.get("ingame") or "").strip() if isinstance(rec, dict) else ""
        dnlist = (rec.get("discord_names") or []) if isinstance(rec, dict) else []
        aliases = (rec.get("aliases") or []) if isinstance(rec, dict) else []
        candidates = [ingame] + dnlist + aliases
        candidates = [c for c in candidates if isinstance(c, str) and c.strip()]
        did = None
        try:
            did = int(key)
        except Exception:
            # Try resolve by name if key is not numeric
            member = find_member_by_names(candidates)
            if member:
                did = member.id
                # migrate key to numeric string
                new_key = str(did)
                if new_key not in data:
                    data[new_key] = rec.copy()
                # ensure fields
                data[new_key]["ingame"] = ingame or data[new_key].get("ingame") or member.display_name
                data[new_key]["discord_names"] = sorted(list(set((data[new_key].get("discord_names") or []) + [member.display_name])))
                data[new_key].pop("_pending", None)
                rename_map[key] = new_key
                migrated += 1
            else:
                skipped += 1
                continue
        member = guild.get_member(did) if did else None
        if not isinstance(member, discord.Member):
            skipped += 1
            continue
        if player_role in getattr(member, "roles", []):
            skipped += 1
            continue
        try:
            await member.add_roles(player_role, reason="assign_player_roles (players.json)")
            assigned += 1
        except Exception:
            errors += 1
    # Remove old string keys after migration
    for old, new in rename_map.items():
        if old in data and old != new:
            data.pop(old, None)
    if rename_map:
        from utils import save_json
        save_json("players.json", data)
    extra = f" | migriert: {migrated}" if migrated else ""
    await interaction.followup.send(f"Fertig. Zugewiesen: {assigned}, übersprungen: {skipped}, Fehler: {errors}{extra}.", ephemeral=True)
    roles_cfg = (config.get("roles") or {})
    player_spec = roles_cfg.get("player") if isinstance(roles_cfg.get("player"), (str, int)) else "Player"
    player_role = get_role(guild, player_spec)
    if not isinstance(player_role, discord.Role):
        await interaction.followup.send("Player‑Rolle nicht gefunden/erstellbar.", ephemeral=True); return
    players = load_json("players.json", {}) or {}
    ok, skipped, errors = 0, 0, 0
    for key, rec in players.items():
        try:
            did = int(key)
        except Exception:
            skipped += 1
            continue
        member = guild.get_member(did)
        if not isinstance(member, discord.Member):
            skipped += 1
            continue
        if player_role in getattr(member, "roles", []):
            skipped += 1
            continue
        try:
            await member.add_roles(player_role, reason="assign_player_roles")
            ok += 1
        except Exception:
            errors += 1
    await interaction.followup.send(f"Fertig. Zugewiesen: {ok}, übersprungen: {skipped}, Fehler: {errors}.", ephemeral=True)
@tree.command(
    name="stati",
    description="Statistik-Bild an das Ergebnis hängen / Attach stats image to result",
    guild=discord.Object(id=config["guild_id"])
)
@app_commands.describe(
    message_url="Link oder ID der Discord-Nachricht mit Bild / Link or ID of the Discord message with the image",
    group="Gruppe (optional, im Match-Channel leer lassen)",
    s1="Spieler 1",
    s2="Spieler 2"
)
@app_commands.guild_only()
async def stati_cmd(
    interaction: discord.Interaction,
    message_url: str,
    group: str | None = None,
    s1: str | None = None,
    s2: str | None = None
):
    await interaction.response.defer(ephemeral=True)
    # Nachricht / Bild ermitteln: ID, Nachrichten-Link oder direktes Bild-URL
    image_url: str | None = None
    msg: discord.Message | None = None
    src_ch_id: int | None = None
    src_msg_id: int | None = None
    cached_path: str | None = None
    raw = (message_url or "").strip()
    try:
        # Fall 1: direktes Bild-URL (CDN)
        if raw.startswith("http") and ("cdn.discordapp.com" in raw or "media.discordapp.net" in raw):
            image_url = raw
        # Fall 2: reine ID -> zuerst im aktuellen Channel, dann in allen Textchannels suchen
        elif raw.isdigit():
            message_id = int(raw)
            # aktueller Channel
            ch = interaction.channel
            if isinstance(ch, discord.TextChannel):
                try:
                    msg = await ch.fetch_message(message_id)
                except Exception:
                    msg = None
            # notfalls andere Textchannels durchsuchen
            if msg is None:
                for ch in interaction.guild.text_channels:
                    try:
                        msg = await ch.fetch_message(message_id)
                        if msg:
                            break
                    except Exception:
                        continue
        # Fall 3: vollständiger Nachrichten-Link
        else:
            parts = [p for p in raw.split("/") if p.isdigit()]
            if len(parts) >= 2:
                channel_id = int(parts[-2])
                message_id = int(parts[-1])
                ch = interaction.guild.get_channel(channel_id)
                if isinstance(ch, discord.TextChannel):
                    msg = await ch.fetch_message(message_id)
        # Wenn wir eine Nachricht haben, merken wir uns die Quelle (für späteres Attachment-Reupload ohne HTTP).
        if msg:
            try:
                src_ch_id = int(getattr(msg.channel, "id", 0) or 0) or None
                src_msg_id = int(getattr(msg, "id", 0) or 0) or None
            except Exception:
                src_ch_id = None
                src_msg_id = None
        # Wenn wir eine Nachricht haben, versuche Bild aus Attachments/Embed
        if msg and image_url is None:
            for a in msg.attachments or []:
                ctype = getattr(a, "content_type", None) or ""
                fname = (a.filename or "").lower()
                if (ctype.startswith("image") or fname.endswith((".png", ".jpg", ".jpeg", ".webp", ".gif"))):
                    image_url = a.url
                    break
            if image_url is None:
                for e in msg.embeds or []:
                    if getattr(e, "image", None) and getattr(e.image, "url", None):
                        image_url = e.image.url
                        break
        if not image_url:
            await interaction.followup.send(
                embed=_embed("Kein Bild gefunden. / No image found.", discord.Color.orange()),
                ephemeral=True
            )
            return

        # Cache stats locally so we can reliably re-upload as an attachment later (no CDN issues / redirects).
        try:
            import os, datetime as _dt
            root = os.path.dirname(__file__)
            cache_dir = os.path.join(root, "stats_cache")
            os.makedirs(cache_dir, exist_ok=True)
            ts = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            fn = f"stati_{ts}.png"

            # Prefer saving from the original Discord attachment if we have the source message.
            if msg:
                for a in (msg.attachments or []):
                    ctype = getattr(a, "content_type", None) or ""
                    low = (a.filename or "").lower()
                    if ctype.startswith("image") or low.endswith((".png", ".jpg", ".jpeg", ".webp", ".gif")):
                        ext = os.path.splitext(a.filename or "")[1].lower() or ".png"
                        fn = f"stati_{ts}{ext}"
                        cached_path = os.path.join(cache_dir, fn)
                        await a.save(cached_path)
                        break

            # Fallback: download the image url (CDN / embed image)
            if not cached_path and image_url and image_url.startswith("http"):
                import aiohttp
                async with aiohttp.ClientSession() as session:
                    async with session.get(image_url) as resp:
                        if resp.status == 200:
                            data = await resp.read()
                            low = image_url.lower()
                            for ext in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
                                if ext in low:
                                    fn = f"stati_{ts}{ext}"
                                    break
                            cached_path = os.path.join(cache_dir, fn)
                            with open(cached_path, "wb") as f:
                                f.write(data)
        except Exception:
            cached_path = None
    except Exception:
        await interaction.followup.send(
            embed=_embed("Ungültiger Nachrichtenlink oder ID. / Invalid message link or ID.", discord.Color.orange()),
            ephemeral=True
        )
        return
    # Match auflösen (Topic oder Parameter)
    if not (group and s1 and s2):
        g, a, b = _topic_tuple_from_channel(interaction.channel)
        if g:
            group, s1, s2 = g, a, b
    if not (group and s1 and s2):
        await interaction.followup.send(
            embed=_embed("Match nicht eindeutig. Bitte im Match-Channel nutzen. / Match not unique, please use inside the match channel.", discord.Color.orange()),
            ephemeral=True
        )
        return
    # Persistieren & Ergebnisnachricht aktualisieren
    match_set_stati_image(group, s1, s2, image_url)
    # For the "stats required before confirm" gate we also store when (and for KO: for which game number)
    try:
        import datetime as _dt
        rec0 = get_match_record(group, s1, s2) or {}
        game_no = 0
        if str(group).startswith("KO-"):
            game_no = int(rec0.get("ko_game_started_no") or 0)
            # If /matchstart was done before a restart and only the wins persisted,
            # we can still infer the current game number deterministically.
            if game_no <= 0:
                wins0 = rec0.get("ko_wins") or {s1: 0, s2: 0}
                try:
                    game_no = int(wins0.get(s1, 0) or 0) + int(wins0.get(s2, 0) or 0) + 1
                except Exception:
                    game_no = 0
        # Legacy: keep the flag for compatibility, but logic elsewhere keys on *_no.
        ko_started_flag = True if (str(group).startswith("KO-") and game_no > 0) else None
        upsert_match_record(
            group,
            s1,
            s2,
            stati_ts=_dt.datetime.now(_dt.timezone.utc).isoformat(),
            stati_game_no=game_no,
            ko_game_started=ko_started_flag,
            stati_source_channel_id=src_ch_id,
            stati_source_message_id=src_msg_id,
            stati_local_path=cached_path,
        )
    except Exception:
        pass
    rec = get_match_record(group, s1, s2) or {}
    ch_id = rec.get("result_channel_id")
    msg_id = rec.get("result_message_id")
    try:
        if ch_id and msg_id:
            from embeds import embed_result
            ch2 = interaction.guild.get_channel(ch_id)
            if isinstance(ch2, discord.TextChannel):
                msg2 = await ch2.fetch_message(msg_id)
                results = load_json(ERGEBNISSE_PATH, {})
                key = f"{group}|{min(s1,s2)}|{max(s1,s2)}"
                res = results.get(key, {})
                winner = res.get("winner", "?")
                mode = rec.get("final_mode") or rec.get("mode")
                # Discord does not allow editing an existing message to add attachments.
                # Therefore, replace the results message with a new one containing the stats image as attachment.
                file_obj = None
                attach_url = image_url
                # Prefer cached local file
                try:
                    import os
                    if cached_path and os.path.isfile(cached_path):
                        fn = os.path.basename(cached_path)
                        file_obj = discord.File(cached_path, filename=fn)
                        attach_url = f"attachment://{fn}"
                except Exception:
                    file_obj = None
                    attach_url = image_url

                # Fallback: try HTTP download
                if file_obj is None and image_url and str(image_url).startswith("http"):
                    try:
                        import aiohttp, io
                        async with aiohttp.ClientSession() as session:
                            async with session.get(image_url) as resp:
                                if resp.status == 200:
                                    data = await resp.read()
                                    fn = "stati.png"
                                    low = str(image_url).lower()
                                    for ext in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
                                        if ext in low:
                                            fn = "stati" + ext
                                            break
                                    file_obj = discord.File(io.BytesIO(data), filename=fn)
                                    attach_url = f"attachment://{fn}"
                    except Exception:
                        file_obj = None
                        attach_url = image_url

                em = embed_result(group, s1, s2, winner, image_url=attach_url, mode=mode)
                # delete old, post new, store new msg id
                try:
                    await msg2.delete()
                except Exception:
                    pass
                if file_obj:
                    new_msg = await ch2.send(embed=em, file=file_obj)
                else:
                    new_msg = await ch2.send(embed=em)
                upsert_match_record(group, s1, s2, result_channel_id=ch2.id, result_message_id=new_msg.id)
    except Exception:
        pass
    await interaction.followup.send(
        embed=_embed("🖼️ Statistik-Bild gespeichert. / Stats image saved.", discord.Color.green()),
        ephemeral=True
    )
@tree.command(name="checkin", description="Check-In für dieses Match (beide Spieler müssen bestätigen)", guild=discord.Object(id=config["guild_id"]))
@app_commands.describe(ingame_name="Optional: Ingame-Name, wird im Profil gespeichert")
@app_commands.guild_only()
async def checkin_cmd(interaction: discord.Interaction, ingame_name: str | None = None):
    group, s1, s2 = _topic_tuple_from_channel(interaction.channel)
    if not group:
        await interaction.response.send_message(embed=_embed("Kein Match-Channel / Topic nicht gesetzt. / No match channel or topic set.", discord.Color.red()), ephemeral=True)
        return
    if not _is_player(interaction.guild, interaction.user, s1, s2):
        await interaction.response.send_message(embed=_embed("Nur die beiden Spieler können /checkin nutzen. / Only the two players may use /checkin.", discord.Color.red()), ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    if ingame_name and ingame_name.strip():
        try:
            players_set(interaction.user.id, ingame_name.strip(), discord_name=getattr(interaction.user, "name", None))
        except Exception:
            pass
    match_add_checkin(group, s1, s2, interaction.user.id)
    ids = set(match_checked_in(group, s1, s2))
    m1 = resolve_member_by_name(interaction.guild, s1)
    m2 = resolve_member_by_name(interaction.guild, s2)
    both = {getattr(m1, "id", 0), getattr(m2, "id", 0)}.issubset(ids)
    if both:
        upsert_match_record(group, s1, s2, locked=True)
    msg = "✅ Check-In erfasst. / Check-in recorded."
    if both:
        msg += " Beide Spieler eingeloggt – Match ist gelockt. / Both players checked in – match is locked."
    await interaction.followup.send(embed=_embed(msg, discord.Color.green()), ephemeral=True)
@tree.command(name="ko_import", description="(Orga) KO-Start: Round of 32 Matchups importieren", guild=_GUILD)
@app_commands.describe(matchups="16 Zeilen, z.B. 'SpielerA vs SpielerB'")
@app_commands.guild_only()
async def ko_import_cmd(interaction: discord.Interaction, matchups: str):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga.", discord.Color.red()), ephemeral=True)
        return
    def _extract_pairs(text: str) -> list[list[str]]:
        """Accepts either:
        - 16 lines (one matchup per line)
        - 1 line with separators between matchups (| or ;)
        - 1 long line with repeated 'A vs B' patterns
        """
        out: list[list[str]] = []
        text = (text or "").strip()
        if not text:
            return out
        text = text.replace("—", "-").replace("–", "-")
        # If the user uses separators (| or ;) treat them as newlines.
        if "\n" not in text and ("|" in text or ";" in text):
            text = re.sub(r"\s*(?:\|\||\||;)\s*", "\n", text)
        # First pass: line-by-line parsing.
        for raw in text.splitlines():
            raw = raw.strip()
            if not raw:
                continue
            # If a line contains multiple pairs (e.g. user pasted everything in one line),
            # extract all 'A vs B' occurrences.
            if len(re.findall(r"\bvs\b", raw, flags=re.I)) >= 2 and " vs " in raw.lower():
                for m in re.finditer(r"(.+?)\s+vs\s+(.+?)(?=(?:\s+[^\n]+?\s+vs\s+)|$)", raw, flags=re.I):
                    a, b = m.group(1).strip(), m.group(2).strip()
                    if a and b:
                        out.append([a, b])
                continue
            if " vs " in raw.lower():
                parts = re.split(r"\s+vs\s+", raw, flags=re.I)
            elif "," in raw:
                parts = [p.strip() for p in raw.split(",", 1)]
            elif "-" in raw:
                parts = [p.strip() for p in raw.split("-", 1)]
            else:
                continue
            if len(parts) != 2:
                continue
            a, b = parts[0].strip(), parts[1].strip()
            if a and b:
                out.append([a, b])
        return out
    lines = _extract_pairs(matchups)
    if len(lines) < 16:
        await interaction.response.send_message(
            embed=_embed(f"Es wurden nur **{len(lines)}** Matchups erkannt (benötigt: 16).", discord.Color.orange()),
            ephemeral=True
        )
        return
    from utils import ko_import_round_of_32
    ko_import_round_of_32(lines[:16])
    await interaction.response.send_message(embed=_embed("✅ KO-Bracket (R32) importiert. Nutze jetzt /gen_kostage.", discord.Color.green()), ephemeral=True)
@tree.command(name="gen_kostage", description="(Orga) Erstellt KO-Matchchannels für die aktuelle Runde", guild=_GUILD)
@app_commands.guild_only()
async def gen_kostage_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga.", discord.Color.red()), ephemeral=True)
        return
    # can take long (channel/category creation) -> defer early to avoid "Unknown interaction"
    try:
        await interaction.response.defer(ephemeral=True, thinking=True)
    except Exception:
        pass
    from utils import ko_current_stage, ko_players_for_stage
    from channels import match_channel_overwrites
    stage = ko_current_stage()
    items = ko_players_for_stage(stage)
    # Final stage also generates the 3rd-place match channel.
    try:
        if str(stage).upper() == "F":
            items = list(items or []) + list(ko_players_for_stage("3P") or [])
    except Exception:
        pass
    orga_ids = config.get("turnierleitung_ids") or []
    # create category
    cat_name = f"KO {stage}"
    cat = discord.utils.get(interaction.guild.categories, name=cat_name)
    if not cat:
        cat = await interaction.guild.create_category(cat_name, reason="S4WC: KO stage category")
    created = 0
    for m in items:
        mid = m["id"]
        st = str(m.get("stage") or stage).upper()
        p1, p2 = m.get("p1"), m.get("p2")
        if not p1 or not p2:
            continue
        cname = f"ko-{mid.lower()}-{p1}-vs-{p2}"
        cname = cname.lower().replace(" ", "-")
        existing = discord.utils.get(cat.text_channels, topic=f"KO-{st}-{mid}|{p1}|{p2}")
        ch = None
        if existing:
            ch = existing
        else:
            overwrites = match_channel_overwrites(interaction.guild, p1, p2, orga_ids)
            ch = await cat.create_text_channel(cname[:96], overwrites=overwrites, reason="S4WC: KO match channel")
            try:
                await ch.edit(topic=f"KO-{st}-{mid}|{p1}|{p2}")
            except Exception:
                pass
            created += 1
            try:
                # ping both players if possible
                try:
                    from utils import resolve_member_by_name
                    m1 = resolve_member_by_name(interaction.guild, p1)
                    m2 = resolve_member_by_name(interaction.guild, p2)
                    ping = f"{m1.mention if m1 else p1} {m2.mention if m2 else p2}"
                except Exception:
                    ping = f"{p1} {p2}"
                # Special wording for Grand Final (Bo5) and 3rd place.
                title = f"KO {st} — {mid}"
                if st == "F" and str(mid).upper() == "M31":
                    title = "🏆 Finale / Grand Final — Bo5"
                if st == "3P" and str(mid).upper() == "M32":
                    title = "🥉 Spiel um Platz 3 / 3rd Place — Bo3"

                if st == "F" and str(mid).upper() == "M31":
                    desc = (
                        f"**{p1}** vs **{p2}**\n\n"
                        "**DE — Finale Ablauf (Bo5)**\n"
                        "1) Beide: **/checkin**\n"
                        "2) **Game 1**: **/matchstart** → Münzwurf → Gewinner wählt **Counterpick in Game 1 oder 2**\n"
                        "   - In **Game 1 + 2**: Der **Counterpicker** darf **Seite/Position (Pos 1/2)** wählen.\n"
                        "3) **Game 3 + 4**: Vor jedem Game **/matchstart** → Münzwurf → Gewinner wählt **Seite/Position (Pos 1/2)**\n"
                        "   - **Völkerwahl ist blind**.\n"
                        "4) **Völkerregel**: Bis einschließlich **Game 4** darf jedes Volk pro Spieler nur **einmal** gespielt werden.\n"
                        "5) **Game 5** (falls nötig): **/matchstart** → Münzwurf → Gewinner wählt Seite/Position; **Völkerwahl blind**\n"
                        "   - In Game 5 sind wieder **alle Völker erlaubt** (Repicks möglich).\n\n"
                        "**EN — Grand Final flow (Bo5)**\n"
                        "1) Both: **/checkin**\n"
                        "2) **Game 1**: **/matchstart** → coin toss → winner chooses **counterpick in Game 1 or 2**\n"
                        "   - In **Games 1 + 2**: the **counterpicker** chooses the **side/position (Pos 1/2)**.\n"
                        "3) **Games 3 + 4**: before each game run **/matchstart** → coin toss → winner chooses **side/position (Pos 1/2)**\n"
                        "   - **Civ picks are blind**.\n"
                        "4) **Civ rule**: Up to and including **Game 4**, each civ may be used **only once** per player.\n"
                        "5) **Game 5** (if needed): **/matchstart** → coin toss → winner chooses side/position; **blind civ picks**\n"
                        "   - In Game 5, **all civs are allowed again** (repicks allowed)."
                    )
                else:
                    desc = (
                        f"**{p1}** vs **{p2}**\n\n"
                        "**DE — Ablauf**\n"
                        "1) Beide: **/checkin**\n"
                        "2) Start: **/matchstart**\n"
                        "   - Bot postet zuerst die **Map-Vorschau** (PNG)\n"
                        "   - Danach folgt die **Völkerwahl** (je nach Game blind/non-blind)\n"
                        "   - Erst danach postet der Bot die **Map-Datei (.map)**\n"
                        "3) Nach jedem Game: **🏆 Sieger melden** → Gegner **bestätigt/ablehnt**\n"
                        "   - Channel wird **erst** geschlossen, wenn die Serie entschieden ist (Bo3/Bo5).\n\n"
                        "**EN — Flow**\n"
                        "1) Both players: **/checkin**\n"
                        "2) Start: **/matchstart**\n"
                        "   - Bot posts the **map preview** (PNG) first\n"
                        "   - Then **civilization picks** (blind/non-blind depending on the game)\n"
                        "   - Only after picks, the bot posts the **.map file**\n"
                        "3) After each game: **🏆 Report winner** → opponent **confirms/denies**\n"
                        "   - Channel closes **only** when the series is decided (Bo3/Bo5)."
                    )

                await ch.send(
                    content=ping,
                    embed=discord.Embed(title=title, description=desc, color=discord.Color.blurple()),
                    view=MatchRootPersistentView(),
                )
            except Exception:
                pass
    try:
        await interaction.followup.send(embed=_embed(f"✅ KO {stage}: {created} Channels erstellt/aktualisiert.", discord.Color.green()), ephemeral=True)
    except Exception:
        pass
@tree.command(name="ko_testfill", description="(Orga) Assign random winners/scores for all matches in current KO stage (testing)", guild=_GUILD)
@app_commands.describe(stage="Stage override (R32/R16/QF/SF). Default: current", overwrite="Overwrite existing winners/results")
@app_commands.guild_only()
async def ko_testfill_cmd(interaction: discord.Interaction, stage: Optional[str] = None, overwrite: Optional[bool] = False):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    import random
    from utils import (
        ko_current_stage, ko_players_for_stage, ko_update_bracket_result,
        ERGEBNISSE_PATH, TERMINE_PATH, UNCONFIRMED_PATH, load_json, save_json, upsert_match_record,
        tippspiel_apply_match_result, tippspiel_update_leaderboard_message
    )
    st = str(stage or ko_current_stage()).upper()
    items = ko_players_for_stage(st)
    updated = 0
    results_lines: list[str] = []
    for it in items:
        mid = it.get("id")
        p1 = it.get("p1")
        p2 = it.get("p2")
        if not mid or not p1 or not p2:
            continue
        if (it.get("winner") or it.get("score")) and not overwrite:
            continue
        winner = random.choice([p1, p2])
        score = random.choice(["2:0", "2:1"])  # BO3 only (Final excluded for now)
        group = f"KO-{st}-{mid}"
        ko_update_bracket_result(group, winner, score)
        # store result (so exports + result channel logic can see it)
        data = load_json(ERGEBNISSE_PATH, {}) or {}
        a, b = sorted([p1, p2], key=lambda x: x.lower())
        key = f"{group}|{a}|{b}"
        data[key] = {"winner": winner, "by": "ko_testfill", "score": score}
        save_json(ERGEBNISSE_PATH, data)
        # close match record (so channels behave consistently)
        upsert_match_record(group, p1, p2, closed=True, ko_score=score, ko_series_winner=winner)
        # clear date proposals/confirmed dates for this match (test mode)
        try:
            term = load_json(TERMINE_PATH, []) or []
            term = [t for t in term if not (t.get("gruppe") == group and {t.get("spieler1"), t.get("spieler2")} == {p1, p2})]
            save_json(TERMINE_PATH, term)
        except Exception:
            pass
        try:
            unconf = load_json(UNCONFIRMED_PATH, []) or []
            unconf = [u for u in unconf if not (u.get("gruppe") == group and {u.get("spieler1"), u.get("spieler2")} == {p1, p2})]
            save_json(UNCONFIRMED_PATH, unconf)
        except Exception:
            pass
        # tippspiel: score immediately per match
        try:
            tippspiel_apply_match_result(mid, winner, score)
        except Exception:
            pass
        updated += 1
        results_lines.append(f"{st} {mid}: {p1} vs {p2} -> {winner} ({score})")
    # update permanent leaderboard message once at the end
    try:
        await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
    except Exception:
        pass
    summary = "\n".join(results_lines) if results_lines else "(no matches)"
    if len(summary) > 1800:
        summary = summary[:1800] + "\n…"
    await interaction.followup.send(
        embed=_embed(f"✅ Testfill done / Testlauf fertig: **{updated}** Matches ({st}).", discord.Color.green()),
        ephemeral=True
    )
    await interaction.followup.send(content=f"```\n{summary}\n```", ephemeral=True)
@tree.command(name="gen_next", description="(Orga) Nächste KO-Runde generieren (wenn aktuelle komplett ist)", guild=_GUILD)
@app_commands.guild_only()
async def gen_next_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga.", discord.Color.red()), ephemeral=True)
        return
    from utils import ko_current_stage, ko_stage_complete, ko_next_stage, ko_set_current_stage
    stage = ko_current_stage()
    if not ko_stage_complete(stage):
        await interaction.response.send_message(embed=_embed(f"⚠️ Runde **{stage}** ist noch nicht vollständig abgeschlossen.", discord.Color.orange()), ephemeral=True)
        return
    nxt = ko_next_stage(stage)
    if not nxt:
        await interaction.response.send_message(embed=_embed("Finale ist bereits abgeschlossen oder keine nächste Runde.", discord.Color.orange()), ephemeral=True)
        return
    ko_set_current_stage(nxt)
    await interaction.response.send_message(embed=_embed(f"✅ Aktive Runde ist jetzt **{nxt}**. Nutze /gen_kostage.", discord.Color.green()), ephemeral=True)
# ---- Tippspiel: feste Channel-IDs (wie von der Orga vorgegeben) ----
TIPPS_LEADERBOARD_CHANNEL_ID = "<DISCORD_TIPPS_LEADERBOARD_CHANNEL_ID>"
TIPPS_ANMELDUNG_CHANNEL_ID = "<DISCORD_TIPPS_SIGNUP_CHANNEL_ID>"
# ---- Bonusfragen / Tendenzen / Völkerstats Channel-IDs (Orga vorgegeben) ----
BONUS_CHANNEL_ID = "<DISCORD_BONUS_CHANNEL_ID>"
TENDENZEN_CHANNEL_ID = "<DISCORD_TENDENCIES_CHANNEL_ID>"
VOELKERSTATS_CHANNEL_ID = "<DISCORD_CIVSTATS_CHANNEL_ID>"
def _tipps_deadline_info(stage: str, mid: str, p1: str, p2: str):
    """(closed, text). Closed if match already finished OR now >= (earliest_confirmed - 5min)."""
    stage_u = str(stage).upper()
    mid_u = str(mid).upper()
    try:
        from utils import ko_load_bracket, tippspiel_load, next_confirmed_for_pair, _parse_dt, load_json, ERGEBNISSE_PATH  # type: ignore
        from datetime import timedelta, datetime
        # if stage already scored -> closed
        td = tippspiel_load()
        if stage_u in (td.get("scored_stages") or []):
            return True, "Locked: round already scored / Runde bereits ausgewertet"
        # if KO match was locked once (after first intermediate result), keep it closed
        try:
            locks = td.get("ko_locked_after_first_result") or {}
            _a = str(p1).strip().lower()
            _b = str(p2).strip().lower()
            if _a > _b:
                _a, _b = _b, _a
            if locks.get(f"{stage_u}::{_a}::{_b}"):
                return True, "Locked: first intermediate result locked / Erstes Zwischenergebnis gelockt"
        except Exception:
            pass

        # IMPORTANT: independent of dates.
        # If ANY intermediate KO result already exists (i.e., at least one game was locked),
        # tips must remain closed forever.
        # We detect this via the persisted match record: ko_wins contains per-player win counts.
        try:
            from utils import get_match_record  # type: ignore
            group = f"KO-{stage_u}-{mid_u}"
            rec = get_match_record(group, p1, p2) or {}
            wins = rec.get("ko_wins") or {}
            if isinstance(wins, dict):
                total = 0
                for v in wins.values():
                    try:
                        total += int(v or 0)
                    except Exception:
                        pass
                if total > 0:
                    return True, "Locked: intermediate result exists / Zwischenergebnis vorhanden"
        except Exception:
            pass
        # if match finished -> closed
        br = ko_load_bracket()
        m = (br.get("matches") or {}).get(mid_u) or {}
        if m.get("winner") and m.get("score"):
            return True, "Locked: match finished / Match abgeschlossen"
        # if at least one (intermediate) result already logged -> keep closed forever (no reopening)
        try:
            results = load_json(ERGEBNISSE_PATH, {}) or {}
            a, b = sorted([p1, p2], key=lambda x: str(x).lower())
            key = f"KO-{stage_u}-{mid_u}|{a}|{b}"
            res = results.get(key) or {}
            if (res.get("winner") or res.get("score") or res.get("games") or res.get("results")):
                return True, "Locked: result already logged / Ergebnis bereits geloggt"
        except Exception:
            pass
        group = f"KO-{stage_u}-{mid_u}"
        nxt = next_confirmed_for_pair(group, p1, p2)
        if not nxt:
            return False, "No confirmed date yet / Noch kein bestätigter Termin"
        dt = _parse_dt(nxt.get("datum", ""), nxt.get("uhrzeit", ""))
        if not dt:
            return False, "Invalid date format / Terminformat ungültig"
        deadline = dt - timedelta(minutes=5)
        now = datetime.now()
        closed = now >= deadline
        return closed, f"Deadline: {deadline.strftime('%d.%m.%Y %H:%M')} (local)"
    except Exception:
        return False, "Deadline not determinable / Deadline nicht bestimmbar"
async def _send_tipps_ui(interaction: discord.Interaction):
    """Ephemeral UI for setting/updating match tips.
    Uses safe interaction helpers to avoid console spam on expired interactions (disconnects).
    """
    from utils import (
        tippspiel_is_checked_in, tippspiel_load, tippspiel_save,
        ko_current_stage, ko_players_for_stage,
    )

    if not tippspiel_is_checked_in(interaction.user.id):
        await _safe_send(
            interaction,
            embed=_embed(
                "⚠️ Nicht eingecheckt / Not checked in\n\n"
                "DE: Klicke im Tippspiel-Anmeldechannel auf **Check-In**.\n"
                "EN: Click **Check-in** in the tippspiel signup channel.",
                discord.Color.orange(),
            ),
            ephemeral=True,
        )
        return

    stage = str(ko_current_stage() or "").upper()
    matches = ko_players_for_stage(stage) or []
    # In the last stage (Final), also allow tipping for the 3rd-place match (M32, stage 3P).
    try:
        if str(stage).upper() == "F":
            matches = list(matches or []) + list(ko_players_for_stage("3P") or [])
    except Exception:
        pass
    # Only show matches that have both players assigned.
    matches = [m for m in (matches or []) if (m.get("p1") and m.get("p2"))]

    # Load user tips
    uid = str(int(interaction.user.id))
    data = tippspiel_load()
    user_tips = (((data.get("tips") or {}).get(stage) or {}).get(uid) or {})

    def _get_tip(mid: str) -> str:
        cur = (user_tips or {}).get(mid)
        if isinstance(cur, dict):
            return str(cur.get("score") or "—")
        return str(cur or "—")

    def build_embed(selected_mid: str | None):
        e = _embed(f"📝 Tipps / Tips — {stage}", discord.Color.blurple())
        if not matches:
            e.description = "Keine Matches gefunden. / No matches found."
            return e
        lines = []
        for mm in matches:
            mid = str(mm.get("id") or "").upper()
            p1 = str(mm.get("p1") or "?")
            p2 = str(mm.get("p2") or "?")
            mst = str(mm.get("stage") or stage).upper()
            closed, _ = _tipps_deadline_info(mst, mid, p1, p2)
            lock = "🔒 " if closed else ""
            st_label = f" ({mst})" if str(mst).upper() != str(stage).upper() else ""
            lines.append(f"{lock}**{mid}**{st_label} {p1} vs {p2} — Tipp: **{_get_tip(mid)}**")
        e.description = "\n".join(lines)
        if selected_mid:
            e.set_footer(text=f"Ausgewählt: {selected_mid}")
        return e

    async def _store_tip(mid: str, score: str):
        d = tippspiel_load()
        tips_all = d.get("tips") or {}
        st = tips_all.get(stage) or {}
        ut = st.get(uid) or {}
        ut[mid] = {
            "score": score,
            "ts": _dt.datetime.now(_dt.timezone.utc).isoformat(),
        }
        st[uid] = ut
        tips_all[stage] = st
        d["tips"] = tips_all
        d["last_updated"] = _dt.datetime.now(_dt.timezone.utc).isoformat()
        tippspiel_save(d)
    class _TippsBaseView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=600)
            self.selected_mid: str | None = None

            opts = []
            for mm in matches:
                mid = str(mm.get("id") or "").upper()
                label = f"{mid}: {mm.get('p1')} vs {mm.get('p2')}"
                opts.append(discord.SelectOption(label=label[:100], value=mid))

            self.select = discord.ui.Select(
                placeholder="Match auswählen…",
                options=opts,
                min_values=1,
                max_values=1,
            )
            self.select.callback = self._on_select  # type: ignore
            self.add_item(self.select)

        def _update_select_defaults(self):
            # Keep the selected match visible in the dropdown after interaction updates
            if not getattr(self, "select", None):
                return
            for opt in self.select.options:
                opt.default = (str(opt.value).upper() == str(self.selected_mid).upper()) if self.selected_mid else False

        async def _on_select(self, i: discord.Interaction):
            self.selected_mid = str(self.select.values[0]).upper()
            self._update_select_defaults()
            await _safe_edit(i, embed=build_embed(self.selected_mid), view=self)

        async def _set_tip(self, i: discord.Interaction, score: str):
            if not self.selected_mid:
                await _safe_send(i, embed=_embed("Erst ein Match auswählen.", discord.Color.orange()), ephemeral=True)
                return

            mm = next((x for x in matches if str(x.get("id") or "").upper() == self.selected_mid), None)
            if not mm:
                await _safe_send(i, embed=_embed("Match nicht gefunden.", discord.Color.red()), ephemeral=True)
                return

            p1 = str(mm.get("p1") or "")
            p2 = str(mm.get("p2") or "")
            mst = str(mm.get("stage") or stage).upper()
            closed, _dl = _tipps_deadline_info(mst, self.selected_mid, p1, p2)
            if closed:
                await _safe_send(i, embed=_embed("🔒 Tipps sind für dieses Match geschlossen.", discord.Color.orange()), ephemeral=True)
                return

            # Validate allowed results (Bo3 normally, Bo5 in Final M31)
            try:
                a, b = str(score).replace("-", ":").split(":", 1)
                ai, bi = int(a), int(b)
            except Exception:
                await _safe_send(i, embed=_embed("Ungültiges Format. / Invalid format.", discord.Color.red()), ephemeral=True)
                return

            is_final_bo5 = (str(stage).upper() == "F" and str(self.selected_mid).upper() == "M31")
            if is_final_bo5:
                ok = (ai == 3 and 0 <= bi <= 2) or (bi == 3 and 0 <= ai <= 2)
            else:
                ok = (ai == 2 and 0 <= bi <= 1) or (bi == 2 and 0 <= ai <= 1)

            if not ok:
                await _safe_send(i, embed=_embed("Dieses Ergebnis ist für dieses Match nicht erlaubt.", discord.Color.orange()), ephemeral=True)
                return

            await _store_tip(self.selected_mid, score)

            # refresh local view-cache for immediate display
            nonlocal user_tips
            user_tips = (tippspiel_load().get("tips") or {}).get(stage, {}).get(uid, {}) or {}
            self._update_select_defaults()
            await _safe_edit(i, embed=build_embed(self.selected_mid), view=self)

    class TippsBo3View(_TippsBaseView):
        @discord.ui.button(label="P1 2:0", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_20(self, i: discord.Interaction, _b):
            await self._set_tip(i, "2:0")

        @discord.ui.button(label="P1 2:1", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_21(self, i: discord.Interaction, _b):
            await self._set_tip(i, "2:1")

        @discord.ui.button(label="P2 2:0", style=discord.ButtonStyle.secondary, row=1)
        async def b_p2_20(self, i: discord.Interaction, _b):
            await self._set_tip(i, "0:2")

        @discord.ui.button(label="P2 2:1", style=discord.ButtonStyle.secondary, row=1)
        async def b_p2_21(self, i: discord.Interaction, _b):
            await self._set_tip(i, "1:2")

        @discord.ui.button(label="❌ Schließen", style=discord.ButtonStyle.danger, row=2)
        async def b_close(self, i: discord.Interaction, _b):
            await _safe_edit(i, content="✅", embed=None, view=None)

    class TippsBo5FinalView(_TippsBaseView):
        @discord.ui.button(label="P1 3:0", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_30(self, i: discord.Interaction, _b):
            await self._set_tip(i, "3:0")

        @discord.ui.button(label="P1 3:1", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_31(self, i: discord.Interaction, _b):
            await self._set_tip(i, "3:1")

        @discord.ui.button(label="P1 3:2", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_32(self, i: discord.Interaction, _b):
            await self._set_tip(i, "3:2")

        @discord.ui.button(label="P2 3:0", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_30(self, i: discord.Interaction, _b):
            await self._set_tip(i, "0:3")

        @discord.ui.button(label="P2 3:1", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_31(self, i: discord.Interaction, _b):
            await self._set_tip(i, "1:3")

        @discord.ui.button(label="P2 3:2", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_32(self, i: discord.Interaction, _b):
            await self._set_tip(i, "2:3")

        @discord.ui.button(label="❌ Schließen", style=discord.ButtonStyle.danger, row=3)
        async def b_close(self, i: discord.Interaction, _b):
            await _safe_edit(i, content="✅", embed=None, view=None)


    class TippsFinalMixedView(_TippsBaseView):
        # Bo3 buttons (used for 3rd-place match M32) + Bo5 buttons (used for Final M31).
        # Validation in _set_tip ensures only allowed results are stored for the selected match.

        @discord.ui.button(label="P1 2:0", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_20(self, i: discord.Interaction, _b):
            await self._set_tip(i, "2:0")

        @discord.ui.button(label="P1 2:1", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_21(self, i: discord.Interaction, _b):
            await self._set_tip(i, "2:1")

        @discord.ui.button(label="P1 3:0", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_30(self, i: discord.Interaction, _b):
            await self._set_tip(i, "3:0")

        @discord.ui.button(label="P1 3:1", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_31(self, i: discord.Interaction, _b):
            await self._set_tip(i, "3:1")

        @discord.ui.button(label="P1 3:2", style=discord.ButtonStyle.secondary, row=1)
        async def b_p1_32(self, i: discord.Interaction, _b):
            await self._set_tip(i, "3:2")

        @discord.ui.button(label="P2 2:0", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_20(self, i: discord.Interaction, _b):
            await self._set_tip(i, "0:2")

        @discord.ui.button(label="P2 2:1", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_21(self, i: discord.Interaction, _b):
            await self._set_tip(i, "1:2")

        @discord.ui.button(label="P2 3:0", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_30(self, i: discord.Interaction, _b):
            await self._set_tip(i, "0:3")

        @discord.ui.button(label="P2 3:1", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_31(self, i: discord.Interaction, _b):
            await self._set_tip(i, "1:3")

        @discord.ui.button(label="P2 3:2", style=discord.ButtonStyle.secondary, row=2)
        async def b_p2_32(self, i: discord.Interaction, _b):
            await self._set_tip(i, "2:3")

        @discord.ui.button(label="❌ Schließen", style=discord.ButtonStyle.danger, row=3)
        async def b_close(self, i: discord.Interaction, _b):
            await _safe_edit(i, content="✅", embed=None, view=None)


    view = TippsFinalMixedView() if str(stage).upper() == "F" else TippsBo3View()
    await _safe_send(interaction, embed=build_embed(None), view=view, ephemeral=True)

@tree.command(name="tipps_setup", description="(Orga) Tippspiel initialisieren (postet Buttons in den Anmelde-Channel)", guild=_GUILD)
@app_commands.guild_only()
async def tipps_setup_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga.", discord.Color.red()), ephemeral=True)
        return
    from utils import tippspiel_load, tippspiel_save
    data = tippspiel_load()
    # leaderboard channel is used for automatic posts
    data["channel_id"] = int(TIPPS_LEADERBOARD_CHANNEL_ID)
    data["scoreboard_channel_id"] = int(TIPPS_LEADERBOARD_CHANNEL_ID)
    data["anmeldung_channel_id"] = int(TIPPS_ANMELDUNG_CHANNEL_ID)
    tippspiel_save(data)
    channel = interaction.guild.get_channel(int(TIPPS_ANMELDUNG_CHANNEL_ID))
    if not channel or not hasattr(channel, "send"):
        await interaction.response.send_message(embed=_embed("❌ Tippspiel-Anmeldechannel nicht gefunden.", discord.Color.red()), ephemeral=True)
        return
    await channel.send(embed=discord.Embed(
        title="🧩 Tippspiel / Prediction Game",
        description=(
            "1) **Check-In** klicken\n"
            "2) **Tipps öffnen** → Bo3: 2:0 oder 2:1 tippen (für einen Spieler). Finale (M31, Bo5): 3:0 / 3:1 / 3:2\n\n"
            "Deadlines: pro Match spätestens **5 Minuten vor dem ersten bestätigten Termin** dieses Matches."
        ),
        color=discord.Color.blurple()
    ), view=TippsEntryPersistentView())
    # ensure permanent leaderboard message exists/updated
    try:
        from utils import tippspiel_update_leaderboard_message
        await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
    except Exception:
        pass
    await interaction.response.send_message(embed=_embed("✅ Tippspiel-Buttons gepostet.", discord.Color.green()), ephemeral=True)
@tree.command(name="tipps", description="Tipps abgeben/ändern (ephemeral UI)", guild=_GUILD)
@app_commands.guild_only()
async def tipps_cmd(interaction: discord.Interaction):
    await _send_tipps_ui(interaction)
@tree.command(name="tipps_leaderboard", description="Tippspiel Leaderboard anzeigen", guild=_GUILD)
@app_commands.guild_only()
async def tipps_leaderboard_cmd(interaction: discord.Interaction):
    from utils import tippspiel_render_leaderboard_embed, tippspiel_update_leaderboard_message
    # Update permanent leaderboard message and show ephemeral preview
    try:
        await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
    except Exception:
        pass
    await interaction.response.send_message(embed=tippspiel_render_leaderboard_embed(), ephemeral=True)
@tree.command(name="tipps_view", description="Tipps eines Spielers anzeigen / View a player's tips", guild=_GUILD)
@app_commands.guild_only()
@app_commands.describe(user="Spieler / Player")
async def tipps_view_cmd(interaction: discord.Interaction, user: discord.Member):
    # Orga-only: do not allow players to view other players' tips.
    if not is_admin(interaction.user, (config.get("turnierleitung_ids") or [])):
        await interaction.response.send_message(
            embed=_embed("Nur Orga darf /tipps_view nutzen. / Only staff can use /tipps_view.", discord.Color.orange()),
            ephemeral=True,
        )
        return
    from utils import tippspiel_load, bonus_load, ko_load_bracket
    from zoneinfo import ZoneInfo
    import datetime as _dt

    data = tippspiel_load()
    uid = str(int(user.id))
    br = ko_load_bracket()
    matches = (br.get("matches") or {})

    def fmt_ts(ts: str) -> str:
        try:
            d = _dt.datetime.fromisoformat(str(ts))
            if d.tzinfo is None:
                d = d.replace(tzinfo=_dt.timezone.utc)
            d = d.astimezone(ZoneInfo("Europe/Berlin"))
            return d.strftime("%d.%m.%Y %H:%M")
        except Exception:
            return str(ts)

    lines = [f"**Tipps von {user.mention}**"]

    # Match tips are stored as: data["tips"][STAGE][UID][MATCH_ID] = "2:1" OR {"score":"2:1","ts":"..."}
    tips_all = data.get("tips") or {}
    rows = []  # (stage, mid, p1, p2, score, ts)
    for stage, stage_tips in tips_all.items():
        if not isinstance(stage_tips, dict):
            continue
        user_tips = stage_tips.get(uid) or {}
        if not isinstance(user_tips, dict):
            continue
        for mid, pred in user_tips.items():
            mid_u = str(mid).upper()
            m = matches.get(mid_u) or {}
            p1 = str(m.get("p1") or "?")
            p2 = str(m.get("p2") or "?")
            st = str(m.get("stage") or stage or "?")
            score = "-"
            ts = "-"
            if isinstance(pred, dict):
                score = str(pred.get("score") or "-")
                ts = fmt_ts(pred.get("ts") or "") if pred.get("ts") else "-"
            else:
                score = str(pred)
            rows.append((st, mid_u, p1, p2, score, ts))

    for st, mid_u, p1, p2, score, ts in sorted(rows, key=lambda r: (r[0], r[1])):
        lines.append(f"**{st}** {p1} vs {p2} — **{score}**; {ts}")

    # Bonus tips
    b = bonus_load()
    btips_all = b.get("tips") or {}
    bu = str(int(user.id))
    b_lines = []
    for qid, q in (b.get("questions") or {}).items():
        rec = (btips_all.get(qid) or {}).get(bu) or {}
        ans = (rec.get("answer") or "").strip()
        if not ans:
            continue
        ts = fmt_ts(rec.get("ts") or "")
        b_lines.append(f"Bonus {qid}: {q.get('text_de','')} — **{ans}**; {ts}")
    if b_lines:
        lines.append("")
        lines.append("**Bonustipps**")
        lines.extend(b_lines)

    if len(lines) == 1:
        lines.append("_(keine Tipps gefunden / no tips found)_")

    em = discord.Embed(title="📌 Tipps", description="\n".join(lines), color=discord.Color.blurple())
    await interaction.response.send_message(embed=em, ephemeral=True)



@tree.command(name="tipps_selfcheck", description="Eigene Tipps prüfen / Check your own tips", guild=_GUILD)
@app_commands.guild_only()
async def tipps_selfcheck_cmd(interaction: discord.Interaction):
    from utils import tippspiel_is_checked_in, tippspiel_load, bonus_load, ko_load_bracket
    from zoneinfo import ZoneInfo
    import datetime as _dt

    checked = tippspiel_is_checked_in(int(interaction.user.id))
    status = "✅ registriert / registered" if checked else "❌ NICHT registriert / NOT registered"

    data = tippspiel_load()
    uid = str(int(interaction.user.id))
    br = ko_load_bracket()
    matches = (br.get("matches") or {})

    def fmt_ts(ts: str) -> str:
        try:
            d = _dt.datetime.fromisoformat(str(ts))
            if d.tzinfo is None:
                d = d.replace(tzinfo=_dt.timezone.utc)
            d = d.astimezone(ZoneInfo("Europe/Berlin"))
            return d.strftime("%d.%m.%Y %H:%M")
        except Exception:
            return str(ts)

    lines = [f"**Selfcheck: {interaction.user.mention}**", status, ""]

    tips_all = data.get("tips") or {}
    rows = []
    for stage, stage_tips in tips_all.items():
        if not isinstance(stage_tips, dict):
            continue
        user_tips = stage_tips.get(uid) or {}
        if not isinstance(user_tips, dict):
            continue
        for mid, pred in user_tips.items():
            mid_u = str(mid).upper()
            m = matches.get(mid_u) or {}
            p1 = str(m.get("p1") or "?")
            p2 = str(m.get("p2") or "?")
            st = str(m.get("stage") or stage or "?")
            score = "-"
            ts = "-"
            if isinstance(pred, dict):
                score = str(pred.get("score") or "-")
                ts = fmt_ts(pred.get("ts") or "") if pred.get("ts") else "-"
            else:
                score = str(pred)
            rows.append((st, mid_u, p1, p2, score, ts))

    if rows:
        for st, mid_u, p1, p2, score, ts in sorted(rows, key=lambda r: (r[0], r[1])):
            lines.append(f"**{st}** {p1} vs {p2} — **{score}**; {ts}")
    else:
        lines.append("_(keine Match-Tipps gespeichert)_")

    b = bonus_load()
    btips_all = b.get("tips") or {}
    bu = str(int(interaction.user.id))
    b_lines=[]
    for qid, q in (b.get("questions") or {}).items():
        rec = (btips_all.get(qid) or {}).get(bu) or {}
        ans=(rec.get("answer") or "").strip()
        if not ans:
            continue
        b_lines.append(f"Bonus {qid}: **{ans}**; {fmt_ts(rec.get('ts') or '')}")
    lines.append("")
    lines.append("**Bonustipps**")
    lines.extend(b_lines if b_lines else ["_(keine Bonus-Tipps gespeichert)_"])

    em = discord.Embed(title="🧾 Tipps Selfcheck", description="\n".join(lines), color=discord.Color.blurple())
    await interaction.response.send_message(embed=em, ephemeral=True)


@tree.command(name="tipps_ban", description="(Orga) User vom Tippspiel bannen / Ban user from prediction game", guild=_GUILD)
@app_commands.guild_only()
async def tipps_ban_cmd(interaction: discord.Interaction, user: discord.Member, reason: str = ""):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    from utils import tippspiel_load, tippspiel_save, tippspiel_update_leaderboard_message
    data = tippspiel_load()
    banned = set(int(x) for x in (data.get("banned") or []))
    banned.add(int(user.id))
    data["banned"] = list(sorted(banned))
    tippspiel_save(data)
    try:
        await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
    except Exception:
        pass
    await interaction.response.send_message(embed=_embed(f"✅ Gebannt / Banned: {user.mention}\nGrund/Reason: {reason or '-'}", discord.Color.orange()), ephemeral=True)
@tree.command(name="tipps_unban", description="(Orga) User entbannen / Unban user from prediction game", guild=_GUILD)
@app_commands.guild_only()
async def tipps_unban_cmd(interaction: discord.Interaction, user: discord.Member):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    from utils import tippspiel_load, tippspiel_save, tippspiel_update_leaderboard_message
    data = tippspiel_load()
    banned = set(int(x) for x in (data.get("banned") or []))
    banned.discard(int(user.id))
    data["banned"] = list(sorted(banned))
    tippspiel_save(data)
    try:
        await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
    except Exception:
        pass
    await interaction.response.send_message(embed=_embed(f"✅ Entbannt / Unbanned: {user.mention}", discord.Color.green()), ephemeral=True)
@tree.command(name="tipps_points", description="(Orga) Punkte hinzufügen/abziehen (transparent) / Add or remove points", guild=_GUILD)
@app_commands.guild_only()
@app_commands.describe(delta="Positive oder negative Punkte (z.B. 3 oder -2)", reason="Optionaler Grund")
async def tipps_points_cmd(interaction: discord.Interaction, user: discord.Member, delta: int, reason: str = ""):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    from utils import tippspiel_apply_adjustment, tippspiel_update_leaderboard_message
    tippspiel_apply_adjustment(int(user.id), int(delta), reason=reason or "manual adjustment")
    try:
        await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
    except Exception:
        pass
    await interaction.response.send_message(embed=_embed(f"✅ Anpassung / Adjustment: {user.mention} {delta:+d}\nGrund/Reason: {reason or '-'}", discord.Color.blurple()), ephemeral=True)
# ---- Bonusfragen ----
@tree.command(name="bonus_setup", description="(Orga) Bonusfragen-Overlay posten/aktualisieren / Post or update bonus overlay", guild=_GUILD)
@app_commands.guild_only()
async def bonus_setup_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    from utils import bonus_load, bonus_save, bonus_render_overlay_embed, bonus_render_public_overlay_embed
    b = bonus_load()
    # Ensure channels are stored (support legacy constants but allow json overrides)
    b["channel_id"] = int(BONUS_CHANNEL_ID)
    b["tendencies_channel_id"] = int(TENDENZEN_CHANNEL_ID)
    # Orga channel is fixed as requested (can be overridden in json later)
    b.setdefault("orga_channel_id", "<DISCORD_BONUS_ORGA_CHANNEL_ID>")
    bonus_save(b)
    # --- Public overlay (players) ---
    pub_ch = interaction.guild.get_channel(int(b["channel_id"])) or await interaction.guild.fetch_channel(int(b["channel_id"]))
    pub_embed = bonus_render_public_overlay_embed()
    pub_mid = b.get("overlay_message_id")
    try:
        if pub_mid:
            msg = await pub_ch.fetch_message(int(pub_mid))
            await msg.edit(embed=pub_embed, view=BonusPublicOverlayPersistentView())
        else:
            msg = await pub_ch.send(embed=pub_embed, view=BonusPublicOverlayPersistentView())
            b["overlay_message_id"] = int(msg.id)
            bonus_save(b)
    except Exception:
        # best effort create new
        msg = await pub_ch.send(embed=pub_embed, view=BonusPublicOverlayPersistentView())
        b["overlay_message_id"] = int(msg.id)
        bonus_save(b)
    # --- Orga overlay (management) ---
    orga_ch_id = int(b.get("orga_channel_id", 0) or 0)
    if orga_ch_id:
        orga_ch = interaction.guild.get_channel(orga_ch_id) or await interaction.guild.fetch_channel(orga_ch_id)
        orga_embed = bonus_render_overlay_embed()
        orga_mid = b.get("orga_overlay_message_id")
        try:
            if orga_mid:
                omsg = await orga_ch.fetch_message(int(orga_mid))
                await omsg.edit(embed=orga_embed, view=BonusOrgaOverlayPersistentView())
            else:
                omsg = await orga_ch.send(embed=orga_embed, view=BonusOrgaOverlayPersistentView())
                b["orga_overlay_message_id"] = int(omsg.id)
                bonus_save(b)
        except Exception:
            omsg = await orga_ch.send(embed=orga_embed, view=BonusOrgaOverlayPersistentView())
            b["orga_overlay_message_id"] = int(omsg.id)
            bonus_save(b)
    await interaction.response.send_message(embed=_embed("✅ Bonus-Overlays aktualisiert (Public + Orga).", discord.Color.green()), ephemeral=True)
@tree.command(name="bonus_tip", description="Bonusfrage beantworten / Answer bonus question", guild=_GUILD)
@app_commands.guild_only()
@app_commands.describe(qid="Q1..Q4", answer="Deine Antwort / Your answer")
async def bonus_tip_cmd(interaction: discord.Interaction, qid: str, answer: str):
    from utils import bonus_submit_tip, bonus_deadline_passed
    if bonus_deadline_passed():
        await interaction.response.send_message(embed=_embed("⏱️ Deadline vorbei. / Deadline passed.", discord.Color.red()), ephemeral=True); return
    ok = bonus_submit_tip(str(qid).upper(), int(interaction.user.id), answer)
    if not ok:
        await interaction.response.send_message(embed=_embed("⚠️ Nicht gespeichert (Deadline vorbei).", discord.Color.orange()), ephemeral=True); return
    await interaction.response.send_message(embed=_embed(f"✅ Gespeichert für {str(qid).upper()}.", discord.Color.green()), ephemeral=True)

@tree.command(name="bonus_reset", description="(Orga) Bonus-Tipps zurücksetzen / Reset bonus tips", guild=_GUILD)
@app_commands.guild_only()
async def bonus_reset_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    from utils import bonus_reset, bonus_render_overlay_embed, bonus_render_public_overlay_embed, bonus_load
    bonus_reset(all_data=True)
    # best-effort refresh overlays
    try:
        b = bonus_load()
        if b.get("overlay_message_id") and b.get("channel_id"):
            ch = interaction.guild.get_channel(int(b["channel_id"])) or await interaction.guild.fetch_channel(int(b["channel_id"]))
            msg = await ch.fetch_message(int(b["overlay_message_id"]))
            await msg.edit(embed=bonus_render_public_overlay_embed(), view=BonusPublicOverlayPersistentView())
        if b.get("orga_overlay_message_id") and b.get("orga_channel_id"):
            ch = interaction.guild.get_channel(int(b["orga_channel_id"])) or await interaction.guild.fetch_channel(int(b["orga_channel_id"]))
            msg = await ch.fetch_message(int(b["orga_overlay_message_id"]))
            await msg.edit(embed=bonus_render_overlay_embed(), view=BonusOrgaOverlayPersistentView())
    except Exception:
        pass
    await interaction.response.send_message(embed=_embed("✅ Bonus-Tipps zurückgesetzt (inkl. Correct/Awarded).", discord.Color.orange()), ephemeral=True)
@tree.command(name="bonus_publish", description="(Orga) Bonus-Tendenzen öffentlich posten / Publish bonus tendencies", guild=_GUILD)
@app_commands.guild_only()
async def bonus_publish_cmd(interaction: discord.Interaction):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    # Can take a few seconds if there are multiple questions; defer to avoid the 3s interaction timeout.
    try:
        await interaction.response.defer(ephemeral=True, thinking=True)
    except Exception:
        # If the interaction was already acknowledged, continue.
        pass
    from utils import bonus_render_public_tendencies
    # BUGFIX: previously, posting only happened when get_channel() returned None
    # (because the send-loop was indented inside the if-block). In practice the
    # channel object usually exists, resulting in no messages being posted.
    ch = interaction.guild.get_channel(int(TENDENZEN_CHANNEL_ID))
    if ch is None:
        ch = await interaction.guild.fetch_channel(int(TENDENZEN_CHANNEL_ID))

    from utils import bonus_load
    b = bonus_load()
    qs = b.get("questions") or {}
    for qid in sorted(qs.keys()):
        txt = bonus_render_public_tendencies(qid)
        title = f"📊 {qid} Bonusfrage Tendenzen / Bonus tendencies"
        await ch.send(embed=discord.Embed(title=title, description=txt, color=discord.Color.blurple()))
    try:
        await interaction.followup.send(embed=_embed("✅ Gepostet. / Posted.", discord.Color.green()), ephemeral=True)
    except Exception:
        # Fallback if defer failed for some reason.
        await interaction.response.send_message(embed=_embed("✅ Gepostet. / Posted.", discord.Color.green()), ephemeral=True)
@tree.command(name="tipps_tendenzen", description="(Orga) KO-Tipps Tendenzen posten / Publish KO tip tendencies", guild=_GUILD)
@app_commands.guild_only()
@app_commands.describe(stage="z.B. R32, R16, QF, SF")
async def tipps_tendenzen_cmd(interaction: discord.Interaction, stage: str):
    if not is_admin(interaction.user, config):
        await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
    from utils import tippspiel_load
    from utils import ko_load_bracket
    stage = str(stage).upper()
    data = tippspiel_load()
    tips = ((data.get("tips") or {}).get(stage) or {})
    br = ko_load_bracket()
    ko_matches = (br.get("matches") or {}) if isinstance(br, dict) else {}
    # aggregate per match
    agg = {}
    for uid, ut in tips.items():
        if not isinstance(ut, dict):
            continue
        for mid, pred in ut.items():
            agg.setdefault(mid, {})
            # Tips can be stored as either "2:1" or {"score": "2:1", "ts": ...}
            p = pred
            if isinstance(pred, dict):
                p = pred.get('score', '')
            elif isinstance(pred, str):
                import re
                m = re.search(r"(\d+)\s*:\s*(\d+)", pred)
                if m:
                    p = f"{m.group(1)}:{m.group(2)}"
            agg[mid][str(p)] = agg[mid].get(str(p), 0) + 1
    # post summary
    ch = interaction.guild.get_channel(int(TENDENZEN_CHANNEL_ID))
    if ch is None:
        ch = await interaction.guild.fetch_channel(int(TENDENZEN_CHANNEL_ID))
    mids_sorted = sorted(agg.keys())
    blocks=[]
    for mid in mids_sorted:
        total=sum(agg[mid].values())
        parts=sorted(agg[mid].items(), key=lambda kv:(-kv[1], kv[0]))
        m = ko_matches.get(mid) or {}
        p1 = (m.get("p1") or "?")
        p2 = (m.get("p2") or "?")
        line=[f"**{mid}** — {p1} vs {p2} — {total} Tipps / tips"]
        for p,c in parts:
            pct=(c/total*100.0) if total else 0.0
            line.append(f"- {p}: {c} ({pct:.1f}%)")
        blocks.append("\n".join(line))
    desc="\n\n".join(blocks) if blocks else "_(keine Tipps / no tips)_"
    await ch.send(embed=discord.Embed(title=f"📊 KO Tipps Tendenzen {stage} / KO tip tendencies {stage}", description=desc, color=discord.Color.gold()))
    await interaction.followup.send(embed=_embed("✅ Gepostet. / Posted.", discord.Color.green()), ephemeral=True)
class BonusPublicOverlayPersistentView(discord.ui.View):
    """Public bonus overlay: only allows answering questions (no orga buttons)."""
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="📝 Antworten / Answer", style=discord.ButtonStyle.secondary, custom_id="bonus_open_public")
    async def open_bonus_ui(self, interaction: discord.Interaction, button: discord.ui.Button):
        from utils import bonus_deadline_passed
        if bonus_deadline_passed():
            await interaction.response.send_message(embed=_embed("⏱️ Deadline vorbei. / Deadline passed.", discord.Color.red()), ephemeral=True)
            return
        # Ask for which question
        await interaction.response.send_message(embed=render_bonus_user_embed(int(interaction.user.id)), view=BonusSelectQuestionView(int(interaction.user.id)), ephemeral=True)
class BonusOrgaOverlayPersistentView(discord.ui.View):
    """Orga management overlay: set correct answers and apply points."""
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="✅ Correct setzen / Set correct", style=discord.ButtonStyle.success, custom_id="bonus_set_correct_org")
    async def set_correct(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_admin(interaction.user, config):
            await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
        await interaction.response.send_modal(BonusSetCorrectModal())
    @discord.ui.button(label="🏁 Punkte anwenden / Apply points", style=discord.ButtonStyle.primary, custom_id="bonus_apply_points_org")
    async def apply_points(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_admin(interaction.user, config):
            await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
        from utils import bonus_apply_points_to_correct, bonus_render_overlay_embed, tippspiel_update_leaderboard_message
        rep = bonus_apply_points_to_correct()
        try:
            await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
        except Exception:
            pass
        try:
            await interaction.message.edit(embed=bonus_render_overlay_embed(), view=BonusOrgaOverlayPersistentView())
        except Exception:
            pass
        msg_lines = ["✅ Punkte angewendet. / Points applied."]
        try:
            qrep = (rep or {}).get("questions") or {}
            for qid in sorted(qrep.keys()):
                qd = qrep[qid] or {}
                pts = qd.get("points")
                winners = qd.get("winners") or []
                reason = qd.get("reason") or ""
                if winners:
                    who = ", ".join([f"<@{u}>" for u in winners[:20]])
                    more = f" (+{len(winners)-20} more)" if len(winners) > 20 else ""
                    msg_lines.append(f"**{qid}**: +{pts} → {who}{more} — {reason}")
                else:
                    msg_lines.append(f"**{qid}**: niemand / no one — {reason}")
        except Exception:
            pass
        await interaction.response.send_message(
            embed=_embed("\n\n".join(msg_lines), discord.Color.green()),
            ephemeral=True
        )
class BonusSetCorrectModal(discord.ui.Modal, title="✅ Correct Answer setzen"):
    qid = discord.ui.TextInput(label="Question ID (Q1..Q4)", placeholder="Q1", required=True, max_length=4)
    answer = discord.ui.TextInput(label="Correct Answer", placeholder="z.B. Spielername", required=True, max_length=100)
    async def on_submit(self, interaction: discord.Interaction):
        from utils import bonus_set_correct, bonus_render_overlay_embed
        if not is_admin(interaction.user, config):
            await interaction.response.send_message(embed=_embed("Nur Orga. / Orga only.", discord.Color.red()), ephemeral=True); return
        qid = str(self.qid.value).strip().upper()
        bonus_set_correct(qid, str(self.answer.value).strip())
        try:
            await interaction.message.edit(embed=bonus_render_overlay_embed(), view=BonusOrgaOverlayPersistentView())
        except Exception:
            pass
        await interaction.response.send_message(embed=_embed(f"✅ Correct gesetzt für {qid}.", discord.Color.green()), ephemeral=True)
class BonusSelectQuestionView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=300)
        self.user_id = int(user_id)
        from utils import bonus_load
        b = bonus_load()
        qs = b.get("questions") or {}
        opts = []
        for qid, q in qs.items():
            label = f"{qid}"
            desc = (q.get("text_de") or "")[:90]
            opts.append(discord.SelectOption(label=label, description=desc, value=qid))
        self.add_item(_BonusQuestionSelect(opts, self.user_id))
class _BonusQuestionSelect(discord.ui.Select):
    def __init__(self, options, user_id: int):
        super().__init__(placeholder="Welche Bonusfrage? / Which question?", min_values=1, max_values=1, options=options, custom_id=f"bonus_select_q_{user_id}")
        self.user_id = int(user_id)
    async def callback(self, interaction: discord.Interaction):
        if int(interaction.user.id) != self.user_id:
            await interaction.response.send_message(embed=_embed("Nur für den ursprünglichen Nutzer.", discord.Color.red()), ephemeral=True); return
        qid = str(self.values[0])
        await interaction.response.send_modal(BonusAnswerModal(qid))
class BonusAnswerModal(discord.ui.Modal, title="📝 Bonus Answer"):
    def __init__(self, qid: str):
        super().__init__()
        self.qid = str(qid).upper()
        from utils import bonus_load
        b = bonus_load()
        q = (b.get("questions") or {}).get(self.qid) or {}
        # Discord constraint: TextInput.label must be 1..45 chars.
        prompt = (q.get("text_de") or q.get("text_en") or self.qid)
        self.answer = discord.ui.TextInput(
            label=f"Antwort ({self.qid})",
            placeholder=str(prompt)[:100],
            required=True,
            max_length=200,
        )
        self.add_item(self.answer)
    async def on_submit(self, interaction: discord.Interaction):
        from utils import bonus_submit_tip, bonus_deadline_passed
        if bonus_deadline_passed():
            await interaction.response.send_message(embed=_embed("⏱️ Deadline vorbei. / Deadline passed.", discord.Color.red()), ephemeral=True); return
        bonus_submit_tip(self.qid, int(interaction.user.id), str(self.answer.value))
        await interaction.response.send_message(embed=_embed(f"✅ Gespeichert für {self.qid}. / Saved.", discord.Color.green()), ephemeral=True)
def render_bonus_user_embed(user_id: int) -> discord.Embed:
    from utils import bonus_load
    b = bonus_load()
    qs = b.get("questions") or {}
    tips_all = b.get("tips") or {}
    uid = str(int(user_id))
    lines = []
    for qid, q in qs.items():
        rec = (tips_all.get(qid) or {}).get(uid) or {}
        ans = (rec.get("answer") or "").strip()
        ts = (rec.get("ts") or "").strip()
        if ans:
            lines.append(f"**{qid}** — **{ans}**\n`{ts}`")
        else:
            lines.append(f"**{qid}** — _(keine Antwort / no answer yet)_")
    desc = "\n\n".join(lines) if lines else "_(no questions)_"
    e = discord.Embed(title="🎯 Deine Bonusfragen / Your bonus answers", description=desc, color=discord.Color.blurple())
    try:
        e.set_footer(text=f"Deadline (UTC): {b.get('deadline_iso','')}")
    except Exception:
        pass
    return e
@tree.command(name="matchstart", description="Münzwurf und Moduswahl für dieses Match starten", guild=discord.Object(id=config["guild_id"]))
@app_commands.guild_only()
async def matchstart_cmd(interaction: discord.Interaction):
    group, s1, s2 = _topic_tuple_from_channel(interaction.channel)
    if not group:
        await interaction.response.send_message(
            embed=_embed("Nur im Match-Channel nutzbar. / Only usable inside a match channel.", discord.Color.red()),
            ephemeral=True
        )
        return
    ids = set(match_checked_in(group, s1, s2))
    m1 = resolve_member_by_name(interaction.guild, s1)
    m2 = resolve_member_by_name(interaction.guild, s2)
    need = {getattr(m1, "id", 0), getattr(m2, "id", 0)}
    if not need.issubset(ids):
        await interaction.response.send_message(
            embed=_embed("Beide Spieler müssen zuerst /checkin ausführen. / Both players must run /checkin first.", discord.Color.orange()),
            ephemeral=True
        )
        return
    # KO flow (HGHG only)
    if str(group).startswith("KO-"):
        from match import KOCoinTossView, KOCounterpickChoiceView, _ko_start_game
        from utils import get_match_record, ko_get_required_wins
        rec = get_match_record(group, s1, s2) or {}
        wins = rec.get("ko_wins") or {s1: 0, s2: 0}
        w1 = int(wins.get(s1, 0) or 0)
        w2 = int(wins.get(s2, 0) or 0)
        need_wins = ko_get_required_wins(group)
        # determine current game number
        # if series already complete -> block
        if w1 >= need_wins or w2 >= need_wins or rec.get("closed"):
            await interaction.response.send_message(
                embed=_embed("Match ist bereits abgeschlossen. / Already closed.", discord.Color.orange()),
                ephemeral=True
            )
            return
        # Determine current game number from recorded wins (authoritative)
        game_no = w1 + w2 + 1

        # Resume instead of blocking if this game was already started earlier (e.g. bot restart).
        already_started = False
        try:
            already_started = int(rec.get("ko_game_started_no") or 0) == game_no
        except Exception:
            already_started = False

        # Gate result locking to this /matchstart (idempotent).
        upsert_match_record(
            group, s1, s2,
            ko_game_started=True,
            ko_game_started_no=game_no,
            ko_active_game_no=game_no,
            ko_matchstart_invoker_id=int(interaction.user.id),
            ko_matchstart_invoker_game_no=int(game_no),
        )
        rec = get_match_record(group, s1, s2) or {}

        # Coin toss requirements:
        # - Standard KO: games 1/3/5
        # - Grand Final (Bo5): games 1/3/4/5 (extra toss for game 4)
        try:
            from utils import ko_stage_from_group, ko_match_id_from_group
            is_grand_final = (str(ko_stage_from_group(group) or '').upper() == 'F' and str(ko_match_id_from_group(group) or '').upper() == 'M31')
        except Exception:
            is_grand_final = False
        coin_games = (1, 3, 4, 5) if is_grand_final else (1, 3, 5)
        if game_no in coin_games:
            # ensure the toss belongs to this game (ko_game_no is set by the toss view)
            if (not rec.get("ko_toss_winner")) or int(rec.get("ko_game_no") or 0) != game_no:
                import random as _random
                candidates = [m for m in (m1, m2) if m is not None]
                caller = _random.choice(candidates)
                caller_id = caller.id
                upsert_match_record(group, s1, s2, coin_caller_id=caller_id)
                desc = (
                    f"{s1} vs {s2}\n"
                    f"Coin call: {caller.mention}.\n"
                    "Nur dieser Spieler darf Kopf/Zahl wählen."
                )
                await interaction.response.send_message(
                    embed=discord.Embed(
                        title=f"🪙 Münzwurf / Coin toss (Game {game_no})",
                        description=desc,
                        color=discord.Color.blurple()
                    ),
                    view=KOCoinTossView(group, s1, s2, caller_id, game_no=game_no)
                )
                return

            # Game 1: toss winner chooses counterpick game.
            if game_no == 1 and not rec.get("ko_counterpick_game"):
                await interaction.response.send_message(
                    embed=discord.Embed(
                        title="🎯 Counterpick Wahl",
                        description="Der Münzwurf-Gewinner wählt, in welchem Game er Counterpick möchte.",
                        color=discord.Color.blurple()
                    ),
                    view=KOCounterpickChoiceView(group, s1, s2)
                )
                return

        # Otherwise: start or resume the per-game setup (map preview → picks → positions → map file)
        await interaction.response.send_message(
            embed=discord.Embed(
                title=f"🎮 Game {game_no}",
                description=("Setup wird fortgesetzt." if already_started else "Setup startet jetzt."),
                color=discord.Color.blurple()
            )
        )
        await _ko_start_game(interaction.channel, group, s1, s2)
        return
    # Swiss flow (resumable + restart-proof)
    from match import CoinTossView, ModeChoiceView, BanFlowView, CivPickView, PosiChoiceView
    import random as _random

    rec = get_match_record(group, s1, s2) or {}

    # If not started yet, start fresh and reset the setup state.
    if not rec.get("swiss_match_started"):
        candidates = [m for m in (m1, m2) if m is not None]
        caller = _random.choice(candidates)
        caller_id = int(getattr(caller, "id", 0))
        upsert_match_record(
            group, s1, s2,
            swiss_match_started=True,
            swiss_matchstart_invoker_id=int(interaction.user.id),
            coin_caller_id=caller_id,
            toss_result=None,
            toss_choice_user=None,
            toss_winner=None,
            mode=None,
            bans=[],
            ban_s1=None,
            ban_s2=None,
            final_mode=None,
            civ_s1=None,
            civ_s2=None,
            pos_s1=None,
            pos_s2=None,
            pos_choice_by=None,
            map_sent=False,
            map_file=None,
            map_mapper=None,
        )
        desc = (
            f"{s1} vs {s2}\n"
            f"Coin call: {caller.mention}.\n"
            "Nur dieser Spieler darf Kopf/Zahl wählen. / Only this player may choose heads/tails.\n\n"
            "Ablauf: Münzwurf → Option → 2 Modi bannen → Völkerpick → Positionswahl → (HGHG) Map."
        )
        await interaction.response.send_message(
            embed=discord.Embed(title="🪙 Münzwurf / Coin toss", description=desc, color=discord.Color.blurple()),
            view=CoinTossView(group, s1, s2, caller_id)
        )
        return

    # Already started: allow resuming after a bot restart (send a new step-message).
    # Determine current step purely from the persisted match record.
    toss_winner = rec.get("toss_winner")
    mode_choice = rec.get("mode")
    final_mode = rec.get("final_mode")
    civ_s1 = rec.get("civ_s1")
    civ_s2 = rec.get("civ_s2")
    pos_s1 = rec.get("pos_s1")
    pos_s2 = rec.get("pos_s2")

    if not toss_winner:
        # Ensure a caller exists; if missing (older state), re-pick.
        caller_id = int(rec.get("coin_caller_id") or 0)
        if not caller_id:
            candidates = [m for m in (m1, m2) if m is not None]
            caller = _random.choice(candidates)
            caller_id = int(getattr(caller, "id", 0))
            upsert_match_record(group, s1, s2, coin_caller_id=caller_id)
        mention = f"<@{caller_id}>" if caller_id else "(unbekannt)"
        desc = (
            f"{s1} vs {s2}\n"
            f"Coin call: {mention}.\n"
            "Nur dieser Spieler darf Kopf/Zahl wählen. / Only this player may choose heads/tails."
        )
        await interaction.response.send_message(
            embed=discord.Embed(title="🪙 Münzwurf / Coin toss (Resume)", description=desc, color=discord.Color.blurple()),
            view=CoinTossView(group, s1, s2, caller_id)
        )
        return

    if not mode_choice:
        await interaction.response.send_message(
            embed=discord.Embed(
                title="⚙️ Option wählen / Choose option (Resume)",
                description=(
                    f"Münzwurf gewonnen: **{toss_winner}**\n"
                    "Wähle nun, ob du den letzten Bann bekommst oder die Positionswahl."
                ),
                color=discord.Color.blurple()
            ),
            view=ModeChoiceView(group, s1, s2, toss_winner)
        )
        return

    if not final_mode:
        bans = rec.get("bans") or []
        await interaction.response.send_message(
            embed=discord.Embed(
                title="⛔ Modi bannen / Ban modes (Resume)",
                description=(
                    f"Bereits gebannt: {', '.join(bans) if bans else '—'}\n"
                    "Bitte wähle den nächsten Bann (insgesamt 2)."
                ),
                color=discord.Color.blurple()
            ),
            view=BanFlowView(group, s1, s2)
        )
        return

    if not (civ_s1 and civ_s2):
        await interaction.response.send_message(
            embed=discord.Embed(
                title="🏛️ Völkerpick / Civilization pick (Resume)",
                description="Beide Spieler wählen jetzt ihr Volk (Blind Pick).",
                color=discord.Color.blurple()
            ),
            view=CivPickView(group, s1, s2)
        )
        return

    if not (pos_s1 and pos_s2):
        await interaction.response.send_message(
            embed=discord.Embed(
                title="📍 Positionswahl / Position choice (Resume)",
                description="Positionswahl steht an. Wähle Pos 1 oder Pos 2.",
                color=discord.Color.blurple()
            ),
            view=PosiChoiceView(group, s1, s2)
        )
        return

    # Setup is already completed.
    await interaction.response.send_message(
        embed=discord.Embed(
            title="✅ Setup abgeschlossen",
            description="Völker und Positionen sind bereits gesetzt. Map/Summary sollten bereits im Channel stehen.",
            color=discord.Color.green()
        ),
        ephemeral=True
    )


# --- Auto-archive posted maps/previews so maps are not repeated ---
@bot.event
async def on_message(message: discord.Message):
    try:
        if getattr(message.author, 'bot', False):
            return
        if not getattr(message, 'attachments', None):
            return
        root = os.path.dirname(__file__)
        played_maps_dir = os.path.join(root, 'GespielteMaps')
        played_prev_dir = os.path.join(root, 'GespielteMapPreviews')
        os.makedirs(played_maps_dir, exist_ok=True)
        os.makedirs(played_prev_dir, exist_ok=True)
        # Load played list (KO) so selection won't repeat
        try:
            st = load_json(PLAYED_MAPS_KO_PATH, {})
            if not isinstance(st, dict):
                st = {}
            st.setdefault('played', [])
            if not isinstance(st['played'], list):
                st['played'] = []
        except Exception:
            st = {'played': []}

        updated = False
        for att in message.attachments:
            fn = (att.filename or '')
            if not fn:
                continue
            low = fn.lower()
            if low.endswith('.map'):
                dst = os.path.join(played_maps_dir, os.path.basename(fn))
                if not os.path.exists(dst):
                    await att.save(dst)
                bfn = os.path.basename(fn)
                if bfn not in st['played']:
                    st['played'].append(bfn)
                    updated = True
            elif low.endswith(('.png', '.jpg', '.jpeg', '.webp')):
                dst = os.path.join(played_prev_dir, os.path.basename(fn))
                if not os.path.exists(dst):
                    await att.save(dst)

        if updated:
            try:
                save_json(PLAYED_MAPS_KO_PATH, st)
            except Exception:
                pass
    finally:
        # keep processing commands
        await bot.process_commands(message)

# -------------------------------------------------------------------

@tree.command(name="tipps_recalc", description="Recalc: berechnet alle Tippspiel-Punkte neu.", guild=_GUILD)
@app_commands.checks.has_permissions(administrator=True)
async def tipps_recalc(interaction: discord.Interaction):
    from utils import tippspiel_recalc_all, tippspiel_update_leaderboard_message
    await _safe_send(interaction, content="🔁 Recalc läuft...", ephemeral=True)
    try:
        tippspiel_recalc_all()
        try:
            await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
        except Exception:
            pass
        await _safe_send(interaction, content="✅ Recalc abgeschlossen.", ephemeral=True)
    except Exception as e:
        await _safe_send(interaction, content=f"❌ Recalc fehlgeschlagen: {e}", ephemeral=True)

bot.run(config["bot_token"])
