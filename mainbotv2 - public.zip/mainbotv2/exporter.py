import datetime as dt
import re
from typing import Tuple, Optional
from utils import load_json, MATCHES_PATH, PLAYERS_PATH, TERMINE_PATH

import csv, urllib.parse, urllib.request, io

def _fetch_csv_from_gsheet(url: str) -> list[dict]:
    """Download Google Sheet (edit URL) as CSV rows."""
    if not url: return []
    url = url.strip()
    if "docs.google.com/spreadsheets" in url and "/export" not in url:
        try:
            parts = url.split("/d/")
            sheet_id = parts[1].split("/")[0] if len(parts)>1 else None
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query or "")
            gid = (q.get("gid",[None])[0]) or "0"
            if sheet_id:
                url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"
        except Exception:
            pass
    try:
        with urllib.request.urlopen(url) as resp:
            data = resp.read().decode("utf-8", errors="ignore")
        return list(csv.DictReader(io.StringIO(data)))
    except Exception:
        return []

def _load_accepted_rows() -> list[dict]:
    """Load only ACCEPTED registrations from applications source (Google Sheets or Excel)."""
    from utils import load_config
    cfg = {}
    try:
        cfg = load_config()
    except Exception:
        cfg = {}
    src = (cfg.get("applications", {}) or {}).get("source") or {}
    typ = (src.get("type") or "").lower()
    path = src.get("path_or_id") or src.get("url") or src.get("path")

    def norm(s): return str(s or "").strip()
    def is_accepted(val: str) -> bool:
        v = (val or "").strip().lower()
        return v in ("accepted","akzeptiert","ok","yes","ja","true","1","✔","✅")

    rows = []
    # Google Sheets route
    if isinstance(path, str) and "docs.google.com/spreadsheets" in path or typ in ("google_sheets","google-sheet","gsheets","gsheet","sheet","sheets"):
        raw = _fetch_csv_from_gsheet(path)
        for r in raw:
            # find a 'status'ish column if any
            status_val = ""
            for k, v in r.items():
                if "status" in (k or "").lower():
                    status_val = v; break
            if status_val and not is_accepted(status_val):
                continue
            # if no status column at all, skip (be strict)
            if status_val == "":
                continue
            ing = norm(r.get("Ingame") or r.get("IngameName") or r.get("ingame") or r.get("Spielername") or r.get("Player") or r.get("Name"))
            if not ing: 
                continue
            rows.append({"ingame_name": ing})
        return rows

    # Excel route
    try:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        headers = {str(cell.value or "").strip().lower(): idx+1 for idx, cell in enumerate(ws[1])}
        def col_like(*names):
            # exact
            for n in names:
                key = str(n).strip().lower()
                if key in headers: return headers[key]
            # contains
            for k, idx in headers.items():
                if any(str(n).strip().lower() in k for n in names): return idx
            return None
        c_ing = col_like("ingame","ingame name","spielername","player","name")
        c_stat= col_like("status")
        for r in ws.iter_rows(min_row=2, values_only=True):
            ing = norm(r[(c_ing or 1)-1]) if c_ing else ""
            status = norm(r[(c_stat or 1)-1]) if c_stat else ""
            if not ing: 
                continue
            if c_stat and not is_accepted(status):
                continue
            if c_stat is None:
                continue  # be strict if no status column
            rows.append({"ingame_name": ing})
        return rows
    except Exception:
        return rows



TERMINE_PATH = "termine.json"

_DE_MONTHS = {
    "01": "Jan", "02": "Feb", "03": "Mär", "04": "Apr", "05": "Mai", "06": "Jun",
    "07": "Jul", "08": "Aug", "09": "Sep", "10": "Okt", "11": "Nov", "12": "Dez"
}

def _fmt_date_d_mon(datum: str) -> str:
    parts = datum.strip().split(".")
    if len(parts) >= 2:
        tt = parts[0].zfill(2)
        mm = parts[1].zfill(2)
        mon = _DE_MONTHS.get(mm, mm)
        return f"{tt}. {mon}"
    return datum

def _fmt_time_uhh(uhr: str) -> str:
    u = uhr.strip().replace(" Uhr", "")
    return f"{u} Uhr"

def build_termine_ul_items(termine: list[dict]) -> str:
    if not termine:
        return ''
    lines = []
    def _parse(t):
        try:
            d = t.get('datum',''); u = t.get('uhrzeit','')
            dd,mm,yy = map(int, d.split('.'))
            hh,mi = map(int, u.split(':'))
            return dt.datetime(yy,mm,dd,hh,mi)
        except Exception:
            return dt.datetime.max
    for t in sorted(termine, key=_parse):
        d = _fmt_date_d_mon(t["datum"])
        u = _fmt_time_uhh(t["uhrzeit"])
        s1, s2 = t["spieler1"], t["spieler2"]
        lines.append(f'<li class="termin-entry">{d} – <strong>{s1} vs {s2}</strong> – {u}</li>')
    return "\n".join(lines)

def build_ergebnisse_html(matches: list[dict]) -> str:
    if not matches:
        return '<ul class="s4wc-ergebnisse-list"><li><em>Noch keine Ergebnisse</em></li></ul>'
    matches_sorted = sorted(matches, key=lambda m: m.get("confirmed_at",""), reverse=True)
    lis = []
    for m in matches_sorted:
        grp, s1, s2 = m.get("gruppe"), m.get("spieler1"), m.get("spieler2")
        winner = m.get("winner","?")
        when = " ".join(x for x in [m.get("date"), m.get("time")] if x)
        when_html = f' — <code>{when}</code>' if when else ""
        vod = m.get("vod_url")
        vod_html = f' — <a href="{vod}" target="_blank" rel="noopener">VOD</a>' if vod else ""
        lis.append(f'<li><strong>{grp}</strong>: {s1} vs {s2} — Sieger: <b>{winner}</b>{when_html}{vod_html}</li>')
    return "<ul class=\"s4wc-ergebnisse-list\">\n" + "\n".join(lis) + "\n</ul>"

def generate_snippets() -> Tuple[str, str]:
    termine = load_json(TERMINE_PATH, [])
    matches = load_json(MATCHES_PATH, [])
    return build_termine_ul_items(termine), build_ergebnisse_html(matches)

def replace_termine_ul_after_header(html: str, header_text: str, new_li_html: str) -> Tuple[str, bool]:
    h2 = re.search(rf'<h2[^>]*>\s*{re.escape(header_text)}\s*</h2>', html, flags=re.IGNORECASE)
    if not h2:
        return html, False
    pos = h2.end()
    ul_open = re.search(r'<ul[^>]*class="[^"]*\bscrollable-list\b[^"]*"[^>]*>', html[pos:], flags=re.IGNORECASE)
    if not ul_open:
        return html, False
    ul_open_abs_start = pos + ul_open.start()
    ul_open_abs_end = pos + ul_open.end()
    ul_close = re.search(r'</ul\s*>', html[ul_open_abs_end:], flags=re.IGNORECASE)
    if not ul_close:
        return html, False
    ul_close_abs_start = ul_open_abs_end + ul_close.start()
    ul_close_abs_end = ul_open_abs_end + ul_close.end()
    updated = html[:ul_open_abs_end] + "\n" + new_li_html + "\n" + html[ul_close_abs_start:ul_close_abs_end] + html[ul_close_abs_end:]
    return updated, True


def build_participants_html() -> str:
    """Generate a themed HTML snippet listing all participants from players.json."""
    players = load_json("players.json", {})
    def norm(v):
        if isinstance(v, str):
            return {"ingame": v, "aliases": [], "discord_names": []}
        return {
            "ingame": v.get("ingame") or v.get("ing") or v.get("name"),
            "aliases": v.get("aliases") or [],
            "discord_names": v.get("discord_names") or [],
        }
    items = []
    for _, v in (players or {}).items():
        rec = norm(v)
        ing = rec.get("ingame") or "—"
        aliases = list(dict.fromkeys((rec.get("aliases") or []) + (rec.get("discord_names") or [])))
        items.append((ing, aliases))
    items.sort(key=lambda x: x[0].lower())

    css = """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    :root{ --bg:#4B627C; --panel:#38495C; --text:#f5f5f5; }
    body{ margin:0; font-family:'Inter',sans-serif; background:var(--bg); color:var(--text); }
    .wrap{ max-width:900px; margin:24px auto; padding:16px; }
    .card{ background:var(--panel); border-radius:16px; padding:20px; box-shadow:0 8px 24px rgba(0,0,0,.25); }
    h1{ margin:0 0 12px; font-size:28px; font-weight:700; letter-spacing:.2px; }
    p.muted{ opacity:.85; margin-top:0; }
    ul{ list-style:none; padding:0; margin:0; columns:2; column-gap:24px; }
    li{ padding:8px 10px; border-radius:10px; margin:2px 0; background:rgba(255,255,255,.04); }
    code{ background:rgba(255,255,255,.08); padding:.1em .4em; border-radius:6px; }
    @media (max-width:640px){ ul{ columns:1; } }
    </style>
    """
    lis = []
    for ing, aliases in items:
        alias_txt = f" <code>aka {', '.join(aliases)}</code>" if aliases else ""
        lis.append(f"<li><strong>{ing}</strong>{alias_txt}</li>")
    html = f"""<!doctype html><html lang='de'><meta charset='utf-8'><title>S4WC – Teilnehmer</title>
    {css}
    <div class='wrap'>
      <div class='card'>
        <h1>👥 Teilnehmer / Participants</h1>
        <p class='muted'>Automatisch exportiert – Stand: {dt.datetime.now().strftime('%d.%m.%Y %H:%M')}</p>
        <ul>{''.join(lis)}</ul>
      </div>
    </div>
    """
    return html


def build_termine_html() -> str:
    # Build themed Termine page from termine.json
    termine = load_json(TERMINE_PATH, [])
    # sort chronologically
    def _parse(t):
        try:
            d = t.get('datum',''); u = t.get('uhrzeit','')
            dd,mm,yy = map(int, d.split('.')); hh,mi = map(int, u.split(':'))
            return dt.datetime(yy,mm,dd,hh,mi)
        except Exception:
            return dt.datetime.max
    termine = sorted(termine, key=_parse)
    ul_items = build_termine_ul_items(termine)
    css = """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    :root{ --bg:#4B627C; --panel:#38495C; --text:#f5f5f5; }
    body{ margin:0; font-family:'Inter',sans-serif; background:var(--bg); color:var(--text); }
    .wrap{ max-width:900px; margin:24px auto; padding:16px; }
    .card{ background:var(--panel); border-radius:16px; padding:20px; box-shadow:0 8px 24px rgba(0,0,0,.25); }
    h1{ margin:0 0 12px; font-size:28px; font-weight:700; letter-spacing:.2px; }
    p.muted{ opacity:.85; margin-top:0; }
    ul.s4wc-termine-list{ list-style:none; padding:0; margin:0; }
    ul.s4wc-termine-list li{ padding:8px 10px; border-radius:10px; margin:2px 0; background:rgba(255,255,255,.04); }
    code{ background:rgba(255,255,255,.08); padding:.1em .4em; border-radius:6px; }
    </style>
    """
    html = f"""<!doctype html><html lang='de'><meta charset='utf-8'><title>S4WC – Termine</title>
    {css}
    <div class='wrap'>
      <div class='card'>
        <h1>📅 Termine / Dates</h1>
        <p class='muted'>Automatisch exportiert – Stand: {dt.datetime.now().strftime('%d.%m.%Y %H:%M')}</p>
        {ul_items}
      </div>
    </div>
    """
    return html


def build_ergebnisse_html_page() -> str:
    # Build themed Ergebnisse page from matches.json
    matches = load_json(MATCHES_PATH, [])
    # sort chronologically; items without date/time last
    def _parse(m):
        d, u = (m.get('date') or ''), (m.get('time') or '')
        try:
            dd,mm,yy = map(int, d.split('.')); hh,mi = map(int, u.split(':'))
            return dt.datetime(yy,mm,dd,hh,mi)
        except Exception:
            return dt.datetime.max
    matches = sorted(matches, key=_parse)
    ul_html = build_ergebnisse_html(matches)
    css = """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    :root{ --bg:#4B627C; --panel:#38495C; --text:#f5f5f5; }
    body{ margin:0; font-family:'Inter',sans-serif; background:var(--bg); color:var(--text); }
    .wrap{ max-width:900px; margin:24px auto; padding:16px; }
    .card{ background:var(--panel); border-radius:16px; padding:20px; box-shadow:0 8px 24px rgba(0,0,0,.25); }
    h1{ margin:0 0 12px; font-size:28px; font-weight:700; letter-spacing:.2px; }
    p.muted{ opacity:.85; margin-top:0; }
    ul.s4wc-ergebnisse-list{ list-style:none; padding:0; margin:0; }
    ul.s4wc-ergebnisse-list li{ padding:8px 10px; border-radius:10px; margin:2px 0; background:rgba(255,255,255,.04); }
    code{ background:rgba(255,255,255,.08); padding:.1em .4em; border-radius:6px; }
    </style>
    """
    html = f"""<!doctype html><html lang='de'><meta charset='utf-8'><title>S4WC – Ergebnisse</title>
    {css}
    <div class='wrap'>
      <div class='card'>
        <h1>📊 Ergebnisse / Results</h1>
        <p class='muted'>Automatisch exportiert – Stand: {dt.datetime.now().strftime('%d.%m.%Y %H:%M')}</p>
        {ul_html}
      </div>
    </div>
    """
    return html



def _participants_pairs():
    # Use same source as channel: config.participations.source (Google Sheet) else players.json
    try:
        from utils import load_config
        cfg = load_config()
    except Exception:
        cfg = {}
    src = (cfg.get("participations") or {}).get("source") or {}
    typ = (src.get("type") or "").lower()
    url = (src.get("url") or src.get("path_or_id") or src.get("path") or "").strip()
    pairs = []
    try:
        if typ in {"gsheet","google_sheets","google-sheet","google sheets","sheet","sheets"} and url:
            rows = _fetch_csv_from_gsheet(url)
            headers = list(rows[0].keys()) if rows else []
            def _norm(s):
                import re as _re
                return _re.sub(r"[\s_\-]+","", (s or "").lower())
            H = {_norm(h): h for h in headers}
            def pick(*cands):
                for c in cands:
                    if _norm(c) in H: return H[_norm(c)]
                return None
            col_ingame = pick("ingame-name","ingamename","ingame","spieler","name")
            col_status = pick("status","accepted")
            # Only filter by status if any non-empty values exist
            filterable = False
            if col_status:
                for _r in rows:
                    if str((_r.get(col_status) or '')).strip():
                        filterable = True
                        break
            accepted_vals = {"accepted","akzeptiert","ok","okay","yes","ja","true","1","✔","✅","✓"}
            for r in rows:
                ing = (r.get(col_ingame) or '').strip() if col_ingame else ''
                if not ing:
                    continue
                if filterable and col_status:
                    v = str(r.get(col_status) or '').strip().lower()
                    if v and v not in accepted_vals:
                        continue
                pairs.append((ing, []))
            pairs.sort(key=lambda x: x[0].lower())
            return pairs
    except Exception:
        pass
    # Fallback: players.json
    data = load_json(PLAYERS_PATH, {})
    for k, v in (data or {}).items():
        if isinstance(v, str):
            ing = v; aliases = []
        else:
            ing = v.get("ingame") or v.get("ing") or v.get("name") or str(k)
            aliases = list(dict.fromkeys((v.get("aliases") or []) + (v.get("discord_names") or [])))
        if ing: pairs.append((ing, aliases))
    pairs.sort(key=lambda x: x[0].lower())
    return pairs


def build_participants_html_de():
    pairs = _participants_pairs()
    lis = []
    for ing, aliases in pairs:
        aka = f" — aka: {', '.join(aliases)}" if aliases else ""
        lis.append(f"<li class='participant'>{ing}{aka}</li>")
    ul = "<ul class='scrollable-list'>\n" + ("\n".join(lis) if lis else "<li>Keine Teilnehmer</li>") + "\n</ul>"
    return ul

def build_participants_html_en():
    pairs = _participants_pairs()
    lis = []
    for ing, aliases in pairs:
        aka = f" — aka: {', '.join(aliases)}" if aliases else ""
        lis.append(f"<li class='participant'>{ing}{aka}</li>")
    ul = "<ul class='scrollable-list'>\n" + ("\n".join(lis) if lis else "<li>No participants</li>") + "\n</ul>"
    return ul


def _parse_dt(d: str, t: str):
    try:
        dd, mm, yy = map(int, d.split("."))
        hh, mi = map(int, t.split(":"))
        return (yy, mm, dd, hh, mi)
    except Exception:
        return (9999, 12, 31, 23, 59)

_MONTH_DE = {"01":"Jan","02":"Feb","03":"Mär","04":"Apr","05":"Mai","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Okt","11":"Nov","12":"Dez"}
_MONTH_EN = {"01":"Jan","02":"Feb","03":"Mar","04":"Apr","05":"May","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Oct","11":"Nov","12":"Dec"}

def _fmt_date_de(d: str) -> str:
    try:
        dd, mm, yy = d.split(".")
        return f"{dd.zfill(2)}. {_MONTH_DE.get(mm.zfill(2), mm)}"
    except Exception:
        return d

def _fmt_date_en(d: str) -> str:
    try:
        dd, mm, yy = d.split(".")
        return f"{dd.zfill(2)} {_MONTH_EN.get(mm.zfill(2), mm)}"
    except Exception:
        return d

def build_termine_ul_items_de():
    termine = load_json(TERMINE_PATH, [])
    termine = sorted(termine, key=lambda x: _parse_dt(str(x.get("datum","")), str(x.get("uhrzeit",""))))
    items = []
    for t in termine:
        d = _fmt_date_de(t.get("datum",""))
        u = t.get("uhrzeit","")
        p1 = t.get("spieler1") or ""
        p2 = t.get("spieler2") or ""
        title = t.get("titel") or ""
        mid = f"<strong>{p1} vs {p2}</strong>" if (p1 and p2) else (f"<strong>{title}</strong>" if title else "")
        segs = [seg for seg in [d, mid, (u + " Uhr" if u else "")] if seg]
        items.append(f"<li class='termin-entry'>{' – '.join(segs)}</li>")
    return "\n".join(items)

def build_termine_ul_items_en():
    termine = load_json(TERMINE_PATH, [])
    termine = sorted(termine, key=lambda x: _parse_dt(str(x.get("datum","")), str(x.get("uhrzeit",""))))
    items = []
    for t in termine:
        d = _fmt_date_en(t.get("datum",""))
        u = t.get("uhrzeit","")
        p1 = t.get("spieler1") or ""
        p2 = t.get("spieler2") or ""
        title = t.get("titel_en") or t.get("titel") or ""
        mid = f"<strong>{p1} vs {p2}</strong>" if (p1 and p2) else (f"<strong>{title}</strong>" if title else "")
        segs = [seg for seg in [d, mid, (u + " CET" if u else "")] if seg]
        items.append(f"<li class='termin-entry'>{' – '.join(segs)}</li>")
    return "\n".join(items)


_MONTH_DE = {"01":"Jan","02":"Feb","03":"Mär","04":"Apr","05":"Mai","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Okt","11":"Nov","12":"Dez"}
_MONTH_EN = {"01":"Jan","02":"Feb","03":"Mar","04":"Apr","05":"May","06":"Jun","07":"Jul","08":"Aug","09":"Sep","10":"Oct","11":"Nov","12":"Dec"}

def _parse_dt(d: str, t: str):
    try:
        dd, mm, yy = map(int, d.split("."))
        hh, mi = map(int, t.split(":"))
        return (yy, mm, dd, hh, mi)
    except Exception:
        return (9999, 12, 31, 23, 59)

def _fmt_date_de(d: str) -> str:
    try:
        dd, mm, yy = d.split(".")
        return f"{dd.zfill(2)}. {_MONTH_DE.get(mm.zfill(2), mm)}"
    except Exception:
        return d

def _fmt_date_en(d: str) -> str:
    try:
        dd, mm, yy = d.split(".")
        return f"{dd.zfill(2)} {_MONTH_EN.get(mm.zfill(2), mm)}"
    except Exception:
        return d

def build_termine_items_de():
    termine = load_json(TERMINE_PATH, [])
    termine = sorted(termine, key=lambda x: _parse_dt(str(x.get("datum","")), str(x.get("uhrzeit",""))))
    items = []
    for t in termine:
        d = _fmt_date_de(t.get("datum",""))
        u = t.get("uhrzeit","")
        p1 = (t.get("spieler1") or "").strip()
        p2 = (t.get("spieler2") or "").strip()
        title = (t.get("titel") or "").strip()
        if p1 and p2:
            mid = f"<strong>{p1} vs {p2}</strong>"
        else:
            mid = f"<strong>{title}</strong>" if title else ""
        segs = [seg for seg in [d, mid, (u + " Uhr" if u else "")] if seg]
        items.append(f"<li class='termin-entry'>{' – '.join(segs)}</li>")
    return "\n".join(items)

def build_termine_items_en():
    termine = load_json(TERMINE_PATH, [])
    termine = sorted(termine, key=lambda x: _parse_dt(str(x.get("datum","")), str(x.get("uhrzeit",""))))
    items = []
    for t in termine:
        d = _fmt_date_en(t.get("datum",""))
        u = t.get("uhrzeit","")
        p1 = (t.get("spieler1") or "").strip()
        p2 = (t.get("spieler2") or "").strip()
        title = (t.get("titel_en") or t.get("titel") or "").strip()
        if p1 and p2:
            mid = f"<strong>{p1} vs {p2}</strong>"
        else:
            mid = f"<strong>{title}</strong>" if title else ""
        segs = [seg for seg in [d, mid, (u + " CET" if u else "")] if seg]
        items.append(f"<li class='termin-entry'>{' – '.join(segs)}</li>")
    return "\n".join(items)


def _participants_pairs():
    data = load_json(PLAYERS_PATH, {})
    pairs = []
    for k, v in (data or {}).items():
        if isinstance(v, str):
            ing = v.strip()
            aliases = []
        else:
            ing = (v.get("ingame") or v.get("ing") or v.get("name") or str(k)).strip()
            aliases = list(dict.fromkeys([(a or "").strip() for a in (v.get("aliases") or []) + (v.get("discord_names") or []) if a]))
        if ing:
            pairs.append((ing, aliases))
    pairs.sort(key=lambda x: x[0].lower())
    return pairs

def build_participants_items_de():
    pairs = _participants_pairs()
    items = []
    for ing, aliases in pairs:
        aka = f" — aka: {', '.join(aliases)}" if aliases else ""
        items.append(f"<li class='participant'>{ing}{aka}</li>")
    return "\n".join(items) if items else ""

def build_participants_items_en():
    pairs = _participants_pairs()
    items = []
    for ing, aliases in pairs:
        aka = f" — aka: {', '.join(aliases)}" if aliases else ""
        items.append(f"<li class='participant'>{ing}{aka}</li>")
    return "\n".join(items) if items else ""

# === Wrapper: Hostinger-Blöcke für Termine (DE/EN) ===

def _wrap_termine_block_de(li_html: str) -> str:
    html_before = """<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

<div style="display:flex;flex-wrap:wrap;gap:30px;justify-content:center;margin-top:50px;max-width:1200px;margin-left:auto;margin-right:auto;font-family:'Inter',sans-serif;">

  <!-- Termine -->
  <div style="flex:1 1 400px;background-color:#38495C;padding:30px;border-radius:16px;color:white;min-width:340px;max-height:500px;display:flex;flex-direction:column;">
    <h2 style="text-align:center;font-size:1.8em;margin-bottom:25px;">Kommende Termine</h2>
    <ul class="scrollable-list" id="termine-list-de">
"""
    html_after = """    </ul>
  </div>

  <!-- Ankündigungen -->
  <div style="flex:1 1 400px;background-color:#38495C;padding:30px;border-radius:16px;color:white;min-width:340px;max-height:500px;display:flex;flex-direction:column;">
    <h2 style="text-align:center;font-size:1.8em;margin-bottom:25px;">Ankündigungen</h2>
    <ul class="scrollable-list" id="announcement-list-de">
      <li class="announcement-entry" data-content="Die Anmeldephase hat begonnen. Meldet euch jetzt an und sichert euch euren Startplatz!">
        <strong>[22. Sep]</strong> Anmeldestart – es geht los!
      </li>

      <li class="announcement-entry" data-content="💡 **Wichtiger Hinweis zu den Anmeldungen**<br><br>🟡 Die Zahl der Anmeldungen ist auf <strong>80 Plätze</strong> begrenzt.<br><em>(Eine leichte Anpassung bleibt vorbehalten, um keine ungerade Teilnehmerzahl zu erhalten.)</em><br><br>⚔️ <strong>Änderungen am Regelwerk</strong><br>• Metzel & Buddel: Peacetime für Saboteure, Kriegsmaschinen und Reintowern auf <strong>Minute 40</strong> gesetzt.<br>• Kampfkraft-Regelung:<br>– Metzel & Buddel: <strong>4 vs 4</strong><br>– HGMG: <strong>1 vs 1</strong><br><br>🧭 <strong>Neues Gruppenphasen-Format</strong><br>Die Gruppenphase wird durch ein <strong>Schweizer System</strong> ersetzt.<br>❌ Nach 3 Niederlagen ausgeschieden<br>✅ Nach 3 Siegen qualifiziert<br><br>Weitere Infos folgen in Kürze.">
        <strong>[20. Okt]</strong> Regel- & Formatänderungen
      </li>
    </ul>
  </div>
</div>

<!-- Popup -->
<div id="backdrop-de" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(3px);z-index:9998;"></div>
<div id="popup-de" style="display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) scale(0.96);background:linear-gradient(180deg,#3f5166 0%,#364759 100%);color:white;padding:26px 28px 24px 28px;border-radius:16px;border:1px solid rgba(255,255,255,0.08);box-shadow:0 8px 40px rgba(0,0,0,0.55);z-index:9999;max-width:min(720px,92vw);max-height:80vh;overflow-y:auto;opacity:0;transition:transform .18s ease,opacity .18s ease;">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:10px;">
    <h3 id="popup-title-de" style="margin:0;font-size:1.2em;font-weight:600;"></h3>
    <button id="closePopup-de" style="background:#4B627C;color:#fff;border:none;padding:6px 10px;border-radius:8px;cursor:pointer;font-size:14px;">✕</button>
  </div>
  <div id="popup-content-de" style="font-size:1.02em;line-height:1.6;"></div>
</div>

<style>
.scrollable-list{list-style:none;padding:0 12px 0 0;margin:0;overflow-y:auto;flex-grow:1}
.scrollable-list::-webkit-scrollbar{width:10px}
.scrollable-list::-webkit-scrollbar-thumb{background:#5A7FA6;border-radius:10px}
.termin-entry,.announcement-entry{background-color:#4B627C;padding:14px 18px;margin-bottom:12px;border-radius:10px;font-size:1.05em;transition:.2s;display:flex;align-items:center;gap:10px;animation:fadeInUp .6s both}
.announcement-entry{cursor:pointer;box-shadow:0 4px 6px rgba(0,0,0,.15)}
.announcement-entry:hover{background-color:#5A7FA6;transform:translateY(-2px) scale(1.01)}
.termin-entry:hover{background-color:#5A7FA6;transform:translateY(-2px) scale(1.01)}
@keyframes fadeInUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
</style>

<script>
(function(){
  const items=document.querySelectorAll('#announcement-list-de .announcement-entry');
  const popup=document.getElementById('popup-de');
  const title=document.getElementById('popup-title-de');
  const content=document.getElementById('popup-content-de');
  const closeBtn=document.getElementById('closePopup-de');
  const backdrop=document.getElementById('backdrop-de');

  items.forEach(item=>{
    item.addEventListener('click',()=>{
      title.textContent=item.textContent.trim();
      content.innerHTML=item.getAttribute('data-content')||'';
      backdrop.style.display='block';
      popup.style.display='block';
      requestAnimationFrame(()=>{popup.style.opacity='1';popup.style.transform='translate(-50%,-50%) scale(1)';});
    });
  });
  function hide(){popup.style.opacity='0';popup.style.transform='translate(-50%,-50%) scale(0.96)';setTimeout(()=>{popup.style.display='none';backdrop.style.display='none';},180);}
  closeBtn.addEventListener('click',hide);
  backdrop.addEventListener('click',hide);
})();
</script>
"""
    return html_before + (li_html or "") + "\n" + html_after


def _wrap_termine_block_en(li_html: str) -> str:
    html_before = """<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

<div style="display:flex;flex-wrap:wrap;gap:30px;justify-content:center;margin-top:50px;max-width:1200px;margin-left:auto;margin-right:auto;font-family:'Inter',sans-serif;">

  <!-- Upcoming -->
  <div style="flex:1 1 400px;background-color:#38495C;padding:30px;border-radius:16px;color:white;min-width:340px;max-height:500px;display:flex;flex-direction:column;">
    <h2 style="text-align:center;font-size:1.8em;margin-bottom:25px;">Upcoming Matches</h2>
    <ul class="scrollable-list" id="upcoming-list-en">
"""
    html_after = """    </ul>
  </div>

  <!-- Announcements -->
  <div style="flex:1 1 400px;background-color:#38495C;padding:30px;border-radius:16px;color:white;min-width:340px;max-height:500px;display:flex;flex-direction:column%;">
    <h2 style="text-align:center;font-size:1.8em;margin-bottom:25px;">Announcements</h2>
    <ul class="scrollable-list" id="announcement-list">
      <li class="announcement-entry" data-content="Registration has started. Secure your spot now and join the championship!">
        <strong>[Sep 22]</strong> Registration is open!
      </li>

      <li class="announcement-entry" data-content="💡 <strong>Important Notice on Registrations</strong><br><br>🟡 The number of registrations is limited to <strong>80 players</strong>.<br><em>(Minor adjustments may be made to avoid uneven numbers.)</em><br><br>⚔️ <strong>Rule Adjustments</strong><br>• Metzel & Buddel: Peacetime for saboteurs, war machines, and towering reduced to <strong>minute 40</strong>.<br>• Combat strength:<br>– Metzel & Buddel: <strong>4 vs 4</strong><br>– HGMG: <strong>1 vs 1</strong><br><br>🧭 <strong>New Group Stage Format</strong><br>The group stage will be replaced by a <strong>Swiss System</strong>.<br>❌ Eliminated after 3 losses<br>✅ Advance after 3 wins<br><br>Further details will follow soon.">
        <strong>[Oct 20]</strong> Rule & Format Changes 
      </li>
    </ul>
  </div>
</div>

<!-- Popup -->
<div id="backdrop" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(3px);z-index:9998;"></div>
<div id="popup" style="display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) scale(0.96);background:linear-gradient(180deg,#3f5166 0%,#364759 100%);color:white;padding:26px 28px 24px 28px;border-radius:16px;border:1px solid rgba(255,255,255,0.08);box-shadow:0 8px 40px rgba(0,0,0,0.55);z-index:9999;max-width:min(720px,92vw);max-height:80vh;overflow-y:auto;opacity:0;transition:transform .18s ease,opacity .18s ease;">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:10px;">
    <h3 id="popup-title" style="margin:0;font-size:1.2em;font-weight:600;"></h3>
    <button id="closePopup" style="background:#4B627C;color:#fff;border:none;padding:6px 10px;border-radius:8px;cursor:pointer;font-size:14px;">✕</button>
  </div>
  <div id="popup-content" style="font-size:1.02em;line-height:1.6;"></div>
</div>

<style>
.scrollable-list{list-style:none;padding:0 12px 0 0;margin:0;overflow-y:auto;flex-grow:1}
.scrollable-list::-webkit-scrollbar{width:10px}
.scrollable-list::-webkit-scrollbar-thumb{background:#5A7FA6;border-radius:10px}
.termin-entry,.announcement-entry{background-color:#4B627C;padding:14px 18px;margin-bottom:12px;border-radius:10px;font-size:1.05em;transition:.2s;display:flex;align-items:center;gap:10px;animation:fadeInUp .6s both}
.announcement-entry{cursor:pointer;box-shadow:0 4px 6px rgba(0,0,0,.15)}
.announcement-entry:hover{background-color:#5A7FA6;transform:translateY(-2px) scale(1.01)}
.termin-entry:hover{background-color:#5A7FA6;transform:translateY(-2px) scale(1.01)}
@keyframes fadeInUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
</style>

<script>
(function(){
  const items=document.querySelectorAll('#announcement-list .announcement-entry');
  const popup=document.getElementById('popup');
  const title=document.getElementById('popup-title');
  const content=document.getElementById('popup-content');
  const closeBtn=document.getElementById('closePopup');
  const backdrop=document.getElementById('backdrop');

  items.forEach(item=>{
    item.addEventListener('click',()=>{
      title.textContent=item.textContent.trim();
      content.innerHTML=item.getAttribute('data-content')||'';
      backdrop.style.display='block';
      popup.style.display='block';
      requestAnimationFrame(()=>{popup.style.opacity='1';popup.style.transform='translate(-50%,-50%) scale(1)';});
    });
  });
  function hide(){popup.style.opacity='0';popup.style.transform='translate(-50%,-50%) scale(0.96)';setTimeout(()=>{popup.style.display='none';backdrop.style.display='none';},180);}
  closeBtn.addEventListener('click',hide);
  backdrop.addEventListener('click',hide);
})();
</script>
"""
    return html_before + (li_html or "") + "\n" + html_after


def build_termine_block_de() -> str:
    items = build_termine_items_de()
    li_html = ("\n" + items + "\n") if items else ""
    return _wrap_termine_block_de(li_html)

def build_termine_block_en() -> str:
    items = build_termine_items_en()
    li_html = ("\n" + items + "\n") if items else ""
    return _wrap_termine_block_en(li_html)


def build_participants_snippet_de() -> str:
    return """<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap\" rel=\"stylesheet\">

<div style=\"max-width: 900px; margin: 40px auto; font-family:'Inter',sans-serif;\">
  <div style=\"background:#38495C; color:#fff; border-radius:16px; padding:24px; min-height:420px; display:flex; flex-direction:column;\">
    <h2 style=\"margin:0 0 16px; text-align:center; font-size:1.8em;\">Teilnehmer</h2>
    <ul id=\"participants-list-de\" class=\"scrollable-list\" style=\"flex:1;\">
      <!-- Injector (Bot):
        <li class=\"p-item\">
          <span class=\"p-name\">Spielername</span>
          <span class=\"p-country\">Land</span>
          <span class=\"p-contact\">Discord</span>
          <span class=\"p-team\">Team</span>
          <span class=\"p-mode\">Modus</span>
        </li>
      -->
    </ul>
  </div>
</div>

<style>
  .scrollable-list{list-style:none;padding:0 12px 0 0;margin:0;overflow-y:auto;scroll-behavior:smooth;scrollbar-gutter:stable both-edges;max-height:520px}
  .scrollable-list::-webkit-scrollbar{width:10px}
  .scrollable-list::-webkit-scrollbar-thumb{background:#5A7FA6;border-radius:10px}
  .p-item{background:#4B627C;display:grid;grid-template-columns:1.2fr .6fr .8fr .6fr .6fr;gap:10px;align-items:center;padding:12px 14px;border-radius:10px;margin-bottom:10px}
  .p-name{font-weight:600}
  .p-country,.p-contact,.p-team,.p-mode{opacity:.95}
  @media (max-width:900px){
    .p-item{grid-template-columns:1fr 1fr}
    .p-team,.p-mode{display:none}
  }
</style>
"""


def build_participants_snippet_en() -> str:
    return """<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap\" rel=\"stylesheet\">

<div style=\"max-width: 900px; margin: 40px auto; font-family:'Inter',sans-serif;\">
  <div style=\"background:#38495C; color:#fff; border-radius:16px; padding:24px; min-height:420px; display:flex; flex-direction:column;\">
    <h2 style=\"margin:0 0 16px; text-align:center; font-size:1.8em;\">Participants</h2>
    <ul id=\"participants-list-en\" class=\"scrollable-list\" style=\"flex:1;\">
      <!-- Injector (Bot):
        <li class=\"p-item\">
          <span class=\"p-name\">Player</span>
          <span class=\"p-country\">Country</span>
          <span class=\"p-contact\">Discord</span>
          <span class=\"p-team\">Team</span>
          <span class=\"p-mode\">Mode</span>
        </li>
      -->
    </ul>
  </div>
</div>

<style>
  .scrollable-list{list-style:none;padding:0 12px 0 0;margin:0;overflow-y:auto;scroll-behavior:smooth;flex-grow:1;scrollbar-gutter:stable both-edges;max-height:520px}
  .scrollable-list::-webkit-scrollbar{width:10px}
  .scrollable-list::-webkit-scrollbar-thumb{background:#5A7FA6;border-radius:10px}
  .p-item{background:#4B627C;display:grid;grid-template-columns:1.2fr .6fr .8fr .6fr .6fr;gap:10px;align-items:center;padding:12px 14px;border-radius:10px;margin-bottom:10px}
  .p-name{font-weight:600}
  .p-country,.p-contact,.p-team,.p-mode{opacity:.95}
  @media (max-width:900px){
    .p-item{grid-template-columns:1fr 1fr}
    .p-team,.p-mode{display:none}
  }
</style>
"""

def export_snippets(out_dir: str = ".") -> dict:
    # Build all four snippets and write files next to exporter.py
    de_block = build_termine_block_de()
    en_block = build_termine_block_en()
    de_part = build_participants_snippet_de()
    en_part = build_participants_snippet_en()
    paths = {
        "termine_de_block.html": de_block,
        "termine_en_block.html": en_block,
        "participants_de_block.html": de_part,
        "participants_en_block.html": en_part,
    }
    for fn, content in paths.items():
        with open(fn, "w", encoding="utf-8") as f:
            f.write(content)
    return paths

if __name__ == "__main__":
    # Optional CLI entrypoint: write snippets into working dir
    export_snippets()
