import discord
from i18n import tr, TITLE_STREAM, BTN_SIGNUP, BTN_WITHDRAW
from utils import load_config
from storage import streamer_profiles_all, set_streamer_profile, streamer_profiles_save

config = load_config()

class StreamerSignupView(discord.ui.View):
    """
    View mit 2 Buttons: Anmelden/Abmelden.
    - 4 Slots total
    - 2 Slots pro Streamer (pro Discord-ID)
    """
    def __init__(self, match_id: str, slots: list[int]):
        super().__init__(timeout=None)
        self.match_id = match_id
        self.slots = slots  # list of discord_ids

    def _count_for(self, discord_id: int) -> int:
        return sum(1 for s in self.slots if s == discord_id)

    def _is_full(self) -> bool:
        return len(self.slots) >= 4

    def _label(self) -> str:
        return tr(f"Stream-Slots ({len(self.slots)}/4)", f"Stream slots ({len(self.slots)}/4)")

    @discord.ui.button(label=BTN_SIGNUP, style=discord.ButtonStyle.success)
    async def signup(self, interaction: discord.Interaction, button: discord.ui.Button):
        profiles = streamer_profiles_all()
        me = next((p for p in profiles if p.get("discord_id") == interaction.user.id), None)
        if not me:
            await interaction.response.send_message(
                tr("Bitte erst Profil setzen: /streamer_setprofile", "Please set profile first: /streamer_setprofile"),
                ephemeral=True
            )
            return
        if self._is_full():
            await interaction.response.send_message(tr("Slots voll.", "Slots full."), ephemeral=True)
            return
        if self._count_for(interaction.user.id) >= 2:
            await interaction.response.send_message(tr("Du hast bereits 2 Slots.", "You already have 2 slots."), ephemeral=True)
            return

        self.slots.append(interaction.user.id)
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label=BTN_WITHDRAW, style=discord.ButtonStyle.danger)
    async def withdraw(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id in self.slots:
            self.slots.remove(interaction.user.id)
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message(tr("Du bist nicht eingetragen.", "You are not signed up."), ephemeral=True)

async def set_profile_cmd(interaction: discord.Interaction, display_name: str, channel_link: str):
    """Helper zum Setzen/Updaten des Streamer-Profils."""
    set_streamer_profile(interaction.user.id, display_name, channel_link)
    await interaction.response.send_message(tr("Profil gespeichert.", "Profile saved."), ephemeral=True)

async def show_profile_cmd(interaction: discord.Interaction):
    """Zeigt eigenes Profil (falls vorhanden)."""
    profiles = streamer_profiles_all()
    me = next((p for p in profiles if p.get("discord_id") == interaction.user.id), None)
    if not me:
        await interaction.response.send_message(tr("Kein Profil gefunden.", "No profile found."), ephemeral=True)
        return
    await interaction.response.send_message(
        tr(f"Name: {me['display_name']} – Link: {me['channel_link']}", f"Name: {me['display_name']} – Link: {me['channel_link']}"),
        ephemeral=True
    )
