import discord
from utils import load_config, streamer_set, streamer_get, load_json, save_json, MATCHES_PATH, get_role, upsert_match_record

config = load_config()

def _has_streamer_rights(member: discord.Member) -> bool:
    roles_cfg = (config.get("roles") or {})
    streamer_name = roles_cfg.get("streamer") if isinstance(roles_cfg.get("streamer"), str) else "Streamer"
    admin_name    = roles_cfg.get("admin")    if isinstance(roles_cfg.get("admin"), str)    else "Admin"
    owner_name    = roles_cfg.get("owner")    if isinstance(roles_cfg.get("owner"), str)    else "Owner"
    names = {streamer_name, admin_name, owner_name}
    return any(getattr(r, 'name', '') in names for r in getattr(member, 'roles', [])) or getattr(member.guild_permissions, 'administrator', False)


def _match_key(m):  # für Sortierung
    return f"{m.get('date','')} {m.get('time','')} {m.get('gruppe','')} {m.get('spieler1','')}"

def _signups_for(rec: dict) -> list[int]:
    return list(map(int, rec.get("stream_signups", [])))

def _set_signups(group, s1, s2, ids: list[int]):
    upsert_match_record(group, s1, s2, stream_signups=[int(x) for x in ids])

def _embed_for_match(rec: dict, guild: discord.Guild) -> discord.Embed:
    grp, s1, s2 = rec.get("gruppe"), rec.get("spieler1"), rec.get("spieler2")
    date, time = rec.get("date"), rec.get("time")
    em = discord.Embed(
        title=f"🎥 Stream-Slots – {grp}: {s1} vs {s2}",
        description=f"`{(date or '?')} {(time or '')}`",
        color=discord.Color.teal()
    )
    ids = _signups_for(rec)
    used = len(ids) * 2
    em.add_field(name="Slots", value=f"**{used}/4** (2 je Streamer / 2 per streamer)")
    if ids:
        lines = []
        for sid in ids:
            prof = streamer_get(sid) or {}
            nm = prof.get("name") or (guild.get_member(sid).display_name if guild.get_member(sid) else f"<@{sid}>")
            link = prof.get("link")
            if link:
                lines.append(f"- **{nm}** → {link}")
            else:
                lines.append(f"- **{nm}**")
        em.add_field(name="Angemeldet / Signed up", value="\n".join(lines), inline=False)
    else:
        em.add_field(name="Angemeldet / Signed up", value="_Noch niemand / Nobody yet_", inline=False)
    return em

class StreamSignupView(discord.ui.View):
    def __init__(self, rec: dict):
        super().__init__(timeout=None)
        self.group = rec["gruppe"]
        self.s1 = rec["spieler1"]
        self.s2 = rec["spieler2"]

    async def _refresh(self, message: discord.Message):
        matches = load_json(MATCHES_PATH, [])
        rec = next((m for m in matches if m.get("gruppe")==self.group and {m.get("spieler1"), m.get("spieler2")}=={self.s1, self.s2}), None)
        if not rec:
            try: await message.edit(view=None)
            except Exception: pass
            return
        await message.edit(embed=_embed_for_match(rec, message.guild), view=self)

    @discord.ui.button(label="Anmelden/Sign up", style=discord.ButtonStyle.success)
    async def signup(self, interaction: discord.Interaction, btn: discord.ui.Button):
        if not _has_streamer_rights(interaction.user, config):
            await interaction.response.send_message("Nur für Streamer. / Streamers only.", ephemeral=True)
            return
        profile = streamer_get(interaction.user.id)
        if not profile:
            await interaction.response.send_message("Kein Streamer-Profil gesetzt. Nutze `/streamer_profile`. / No streamer profile set. Use `/streamer_profile`.", ephemeral=True)
            return

        matches = load_json(MATCHES_PATH, [])
        rec = next((m for m in matches if m.get("gruppe")==self.group and {m.get("spieler1"), m.get("spieler2")}=={self.s1, self.s2}), None)
        if not rec:
            await interaction.response.send_message("Match nicht gefunden. / Match not found.", ephemeral=True)
            return
        ids = _signups_for(rec)
        if interaction.user.id in ids:
            await interaction.response.send_message("Bereits angemeldet. / Already signed up.", ephemeral=True)
            return
        if len(ids) >= 2:
            await interaction.response.send_message("Alle Slots (4/4) belegt. / All slots filled.", ephemeral=True)
            return
        ids.append(interaction.user.id)
        _set_signups(self.group, self.s1, self.s2, ids)
        await interaction.response.defer(ephemeral=True, thinking=False)
        await self._refresh(interaction.message)

    @discord.ui.button(label="Abmelden/Withdraw", style=discord.ButtonStyle.secondary)
    async def withdraw(self, interaction: discord.Interaction, btn: discord.ui.Button):
        matches = load_json(MATCHES_PATH, [])
        rec = next((m for m in matches if m.get("gruppe")==self.group and {m.get("spieler1"), m.get("spieler2")}=={self.s1, self.s2}), None)
        if not rec:
            await interaction.response.send_message("Match nicht gefunden. / Match not found.", ephemeral=True)
            return
        ids = _signups_for(rec)
        if interaction.user.id in ids:
            ids = [x for x in ids if x != interaction.user.id]
            _set_signups(self.group, self.s1, self.s2, ids)
        await interaction.response.defer(ephemeral=True, thinking=False)
        await self._refresh(interaction.message)

async def update_stream_schedule_channel(guild: discord.Guild, schedule_channel_id: int | None):
    if not schedule_channel_id:
        return
    ch = guild.get_channel(schedule_channel_id)
    if not ch:
        return
    try:
        await ch.purge()
    except Exception:
        pass

    # Nimm nur Matches mit bestätigtem Termin
    matches = load_json(MATCHES_PATH, [])
    termins = [(m.get("gruppe"), m.get("spieler1"), m.get("spieler2")) for m in matches if m.get("date") and m.get("time")]
    # Falls Matches.json noch leer, ersatzweise aus termine.json bauen:
    if not termins:
        tjs = load_json("termine.json", [])
        for t in tjs:
            termins.append((t.get("gruppe"), t.get("spieler1"), t.get("spieler2")))

    # Einzigartige Tripel + aktuelle Records
    unique = []
    for g,s1,s2 in termins:
        if (g,s1,s2) not in unique:
            unique.append((g,s1,s2))

    # Nachrichten posten
    for (g,s1,s2) in unique:
        rec = next((m for m in matches if m.get("gruppe")==g and {m.get("spieler1"), m.get("spieler2")}=={s1,s2}), None)
        if not rec:
            # rudimentär aus termine.json
            tjs = load_json("termine.json", [])
            t = next((t for t in tjs if t.get("gruppe")==g and {t.get("spieler1"), t.get("spieler2")}=={s1,s2}), None)
            if t:
                rec = {"gruppe": g, "spieler1": s1, "spieler2": s2, "date": t.get("datum"), "time": t.get("uhrzeit")}
                upsert_match_record(g, s1, s2, date=rec["date"], time=rec["time"])

        if rec:
            await ch.send(embed=_embed_for_match(rec, guild), view=StreamSignupView(rec))
