import itertools
import discord
from utils import load_config, resolve_member_by_name, get_role
# NEU: persistente Root-View
from match import MatchRootPersistentView

config = load_config()

def _roles(guild: discord.Guild):
    roles_cfg = (config.get("roles") or {})
    owner = get_role(guild, roles_cfg.get("owner") if roles_cfg.get("owner") else "Owner")
    admin = get_role(guild, roles_cfg.get("admin") if roles_cfg.get("admin") else "Admin")
    streamer = get_role(guild, roles_cfg.get("streamer") if roles_cfg.get("streamer") else "Streamer")
    player = get_role(guild, roles_cfg.get("player") if roles_cfg.get("player") else "Player")
    return owner, admin, streamer, player

def match_channel_overwrites(guild: discord.Guild, p1_name: str, p2_name: str, orga_ids: list[int]):
    overwrites = {guild.default_role: discord.PermissionOverwrite(view_channel=False)}
    for pname in [p1_name, p2_name]:
        member = resolve_member_by_name(guild, pname)
        if member:
            overwrites[member] = discord.PermissionOverwrite(view_channel=True, send_messages=True)
    for oid in orga_ids or []:
        m = guild.get_member(oid)
        if m:
            overwrites[m] = discord.PermissionOverwrite(view_channel=True, send_messages=True)
    owner, admin, streamer, _player = _roles(guild)
    for r in [owner, admin, streamer]:
        if r:
            overwrites[r] = discord.PermissionOverwrite(view_channel=True, send_messages=True)
    return overwrites

async def _ensure_category(guild: discord.Guild, group: str) -> discord.CategoryChannel:
    name = f"{group} Matches"
    cat = discord.utils.get(guild.categories, name=name)
    if cat:
        return cat
    try:
        return await guild.create_category(name=name, reason="S4WC: Match-Kategorie anlegen")
    except Exception:
        return discord.utils.get(guild.categories) or None



async def create_matches(guild: discord.Guild):
    swiss = (config.get("swiss") or {})
    orga_ids = config.get("turnierleitung_ids") or []
    matches_cfg = swiss.get("matches") or []
    managed = swiss.get("managed_channels") or []

    # Swiss-first
    if swiss and matches_cfg:
        # Alle Paare inkl. Bracket ziehen:
        # - Dict: {"1:0": [...], "0:1": [...]} -> group = Key
        # - Liste (Legacy): [...] -> group = "0:0"
        entries: list[tuple[str, str, str]] = []
        if isinstance(matches_cfg, dict):
            buckets = swiss.get("buckets") or list(matches_cfg.keys())
            for group in buckets:
                plist = matches_cfg.get(group) or []
                for pair in plist:
                    try:
                        p1, p2 = pair[0], pair[1]
                    except Exception:
                        continue
                    entries.append((str(group), str(p1), str(p2)))
            # ggf. weitere Gruppen, die nicht in buckets stehen
            for group, plist in matches_cfg.items():
                if group in (swiss.get("buckets") or []):
                    continue
                for pair in plist:
                    try:
                        p1, p2 = pair[0], pair[1]
                    except Exception:
                        continue
                    entries.append((str(group), str(p1), str(p2)))
        else:
            group = "0:0"
            for pair in matches_cfg:
                try:
                    p1, p2 = pair[0], pair[1]
                except Exception:
                    continue
                entries.append((group, str(p1), str(p2)))

        if not entries:
            return

        for idx, (group, p1, p2) in enumerate(entries):
            cname = f"{p1}-vs-{p2}"

            # Kategorie für dieses Bracket ermitteln
            cat_name = f"{group} Matches"
            cat = discord.utils.get(guild.categories, name=cat_name)
            if not cat:
                # Legacy-Kategorien ggf. übernehmen (nur sinnvoll für erstes Swiss-Bracket)
                legacy = discord.utils.get(guild.categories, name="Swiss Matches") or discord.utils.get(guild.categories, name="0:0 Matches")
                if legacy:
                    try:
                        await legacy.edit(name=cat_name, reason="S4WC: Swiss Match-Kategorie umbenennen")
                    except Exception:
                        pass
                    cat = legacy
                else:
                    try:
                        cat = await guild.create_category(name=cat_name, reason="S4WC: Swiss Match-Kategorie anlegen")
                    except Exception:
                        cat = discord.utils.get(guild.categories, name=cat_name)

            # Wenn Kategorie voll ist (Discord-Limit ~50 Channel), neue Kategorie mit Suffix anlegen
            if cat and len(cat.channels) >= 50:
                base = cat_name
                i = 2
                while True:
                    new_name = f"{base} {i}"
                    existing_cat = discord.utils.get(guild.categories, name=new_name)
                    if existing_cat and len(existing_cat.channels) < 50:
                        cat = existing_cat
                        break
                    if not existing_cat:
                        try:
                            cat = await guild.create_category(name=new_name, reason="S4WC: Swiss Match-Kategorie anlegen")
                        except Exception:
                            cat = existing_cat or cat
                        break
                    i += 1

            # Gemanagten Channel nutzen, falls erreichbar, sonst neu/anderweitig anlegen
            ch: discord.TextChannel | None = None
            if idx < len(managed):
                try:
                    ch_candidate = guild.get_channel(int(managed[idx]))
                except Exception:
                    ch_candidate = guild.get_channel(managed[idx])
                if isinstance(ch_candidate, discord.TextChannel):
                    me = guild.me
                    if me and ch_candidate.permissions_for(me).send_messages:
                        ch = ch_candidate

            if isinstance(ch, discord.TextChannel):
                try:
                    await ch.edit(name=cname, category=cat)
                except Exception:
                    pass
            else:
                # existiert ein gleichnamiger Channel bereits in der Kategorie mit ausreichenden Rechten?
                existing = None
                if cat:
                    me = guild.me
                    for ex in cat.text_channels:
                        if ex.name.lower() == cname.lower():
                            if not me or ex.permissions_for(me).send_messages:
                                existing = ex
                                break
                if existing:
                    ch = existing
                else:
                    overwrites = match_channel_overwrites(guild, p1, p2, orga_ids)
                    try:
                        if cat:
                            ch = await cat.create_text_channel(cname, overwrites=overwrites, reason="S4WC: Swiss Match-Channel anlegen")
                        else:
                            ch = await guild.create_text_channel(cname, overwrites=overwrites, reason="S4WC: Swiss Match-Channel anlegen")
                    except Exception:
                        continue

            if not isinstance(ch, discord.TextChannel):
                continue

            # Topic und Overwrites setzen
            try:
                await ch.edit(topic=f"{group}|{p1}|{p2}")
            except Exception:
                pass
            try:
                ow = match_channel_overwrites(guild, p1, p2, orga_ids)
                await ch.edit(overwrites=ow)
            except Exception:
                pass

            # Begrüßung nur bei Neuerstellung senden
            try:
                is_empty = ch.last_message_id is None
            except AttributeError:
                is_empty = False
            if is_empty:
                await send_match_welcome(ch, group, p1, p2)
        return

    # Fallback: Gruppenphase wie gehabt
    gruppen = config.get("gruppen") or {}
    for group, players in gruppen.items():
        if not players or len(players) < 2:
            continue
        cat = await _ensure_category(guild, group)
        for p1, p2 in itertools.combinations(players, 2):
            cname = f"{p1}-vs-{p2}"
            existing = None
            if cat:
                for ch in cat.text_channels:
                    if ch.name.lower() == cname.lower():
                        existing = ch
                        break
            if existing:
                try:
                    await existing.edit(topic=f"{group}|{p1}|{p2}")
                except Exception:
                    pass
                continue
            overwrites = match_channel_overwrites(guild, p1, p2, orga_ids)
            ch = await cat.create_text_channel(cname, overwrites=overwrites, reason="S4WC: Match-Channel anlegen")
            try:
                await ch.edit(topic=f"{group}|{p1}|{p2}")
            except Exception:
                pass
            await send_match_welcome(ch, group, p1, p2)


async def send_match_welcome(channel: discord.TextChannel, group: str, s1: str, s2: str):
    is_ko = str(group).startswith("KO-")
    if is_ko:
        desc = """## KO-Phase / Playoffs (HGHG)

**Format / Format**
- Bis einschließlich Halbfinale: **Best of 3** (First to 2). / Up to Semifinals: **Bo3** (First to 2).
- Finale: **Best of 5** (First to 3). / Final: **Bo5** (First to 3).
- Der Channel wird erst nach dem **Serien-Sieg** geschlossen. / The channel closes only after the **series** is decided.

**Ablauf pro Game / Per-game flow**
1) `/matchstart` → Bot postet **Map-Preview**
2) **Völkerwahl / Civilization picks** (je nach Game blind oder non-blind)
3) Bot postet danach die **Map-Datei (.map)**
4) Nach dem Spiel: **Sieger melden / Report winner** → Gegner bestätigt/ablehnt → Score wird aktualisiert

**Wichtige Regeln / Important rules**
- Kein **Zufall**. / No **Random**.
- Ein bereits gespieltes Volk kann in derselben Serie nicht erneut gewählt werden. / You cannot repick a civ already used in this series.

## Nächste Schritte / Next steps
1) ✅ **/checkin** (beide Spieler) / (both players)
2) 📅 **Termin vorschlagen / Propose date** (oder Session **+1/+2 Spiele anhängen**)
3) 🎮 **/matchstart** (für jedes Game)
4) 🏆 **Sieger melden / Report winner** (nach jedem Game)
"""
    else:
        desc = """## Match / Spiel

## Next steps / Nächste Schritte
1) ✅ **Check-In** (Button)
2) 📅 **Termin vorschlagen / propose date** (Button)
3) 🎮 **/matchstart** (falls vorhanden)
4) 🏆 **Sieger melden / report winner** (Button) → Gegner bestätigt/ablehnt
"""

    embed = discord.Embed(title=f"{group}: {s1} vs {s2}", description=desc, color=discord.Color.blurple())
    m1 = resolve_member_by_name(channel.guild, s1)
    m2 = resolve_member_by_name(channel.guild, s2)
    p1m = m1.mention if m1 else f"**{s1}**"
    p2m = m2.mention if m2 else f"**{s2}**"
    embed.add_field(name="Spieler / Players", value=f"{p1m} vs {p2m}", inline=False)
    # ping players in content so it is hard to miss
    content = f"{p1m} {p2m}"
    await channel.send(content=content, embed=embed, view=MatchRootPersistentView())

async def delete_matches(guild: discord.Guild) -> dict:
    """Deletes match channels/categories (Swiss + Groups + KO). Returns a report.

    Important: We do not silently swallow everything anymore; we still keep going,
    but we return errors so the command can show you what failed (usually permissions).
    """
    report = {"channels_deleted": 0, "categories_deleted": 0, "errors": []}

    swiss = (config.get("swiss") or {})
    managed = set(swiss.get("managed_channels") or [])
    if swiss and managed:
        # Delete explicitly tracked Swiss match channels, but DO NOT return early.
        # We still want to delete group/KO categories below.
        for cid in list(managed):
            ch = guild.get_channel(cid)
            if isinstance(ch, discord.TextChannel):
                try:
                    await ch.delete(reason="S4WC: Swiss cleanup")
                    report["channels_deleted"] += 1
                except Exception as e:
                    report["errors"].append(f"channel {cid}: {type(e).__name__}")

        cat = discord.utils.get(guild.categories, name="0:0 Matches")
        if cat:
            for ch in list(cat.text_channels):
                try:
                    await ch.delete(reason="S4WC: Swiss cleanup")
                    report["channels_deleted"] += 1
                except Exception as e:
                    report["errors"].append(f"channel {ch.id}: {type(e).__name__}")
            try:
                await cat.delete(reason="S4WC: Swiss cleanup")
                report["categories_deleted"] += 1
            except Exception as e:
                report["errors"].append(f"category {cat.id}: {type(e).__name__}")
        # continue with group/KO cleanup

    # Group phase categories
    gruppen = config.get("gruppen") or {}
    for group in gruppen:
        cat = discord.utils.get(guild.categories, name=f"{group} Matches")
        if cat:
            for ch in list(cat.text_channels):
                try:
                    await ch.delete(reason="S4WC: Aufräumen")
                    report["channels_deleted"] += 1
                except Exception as e:
                    report["errors"].append(f"channel {ch.id}: {type(e).__name__}")
            try:
                await cat.delete(reason="S4WC: Aufräumen")
                report["categories_deleted"] += 1
            except Exception as e:
                report["errors"].append(f"category {cat.id}: {type(e).__name__}")

    # KO categories: names start with "KO " (e.g. "KO R32")
    for cat in list(guild.categories):
        if isinstance(cat, discord.CategoryChannel) and str(cat.name).startswith("KO "):
            for ch in list(cat.text_channels):
                try:
                    await ch.delete(reason="S4WC: KO cleanup")
                    report["channels_deleted"] += 1
                except Exception as e:
                    report["errors"].append(f"channel {ch.id}: {type(e).__name__}")
            try:
                await cat.delete(reason="S4WC: KO cleanup")
                report["categories_deleted"] += 1
            except Exception as e:
                report["errors"].append(f"category {cat.id}: {type(e).__name__}")



    # KO orphan channels (not inside a "KO " category): topic starts with "KO-"
    for tch in list(guild.text_channels):
        try:
            if isinstance(tch, discord.TextChannel) and (tch.topic or "").startswith("KO-"):
                await tch.delete(reason="S4WC: KO orphan cleanup")
                report["channels_deleted"] += 1
        except Exception as e:
            report["errors"].append(f"channel {tch.id}: {type(e).__name__}")
    return report
