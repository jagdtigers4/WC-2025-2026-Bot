import discord
import aiohttp
import io
from typing import Optional, Tuple

from utils import (
    load_json, save_json, load_config,
    ERGEBNISSE_PATH, TERMINE_PATH, UNCONFIRMED_PATH,
    upsert_match_record, get_match_record,
    resolve_member_by_name,
    ko_record_game_win, ko_is_series_complete, ko_get_series_score_str, ko_get_required_wins,
    ko_update_bracket_result, ko_stage_from_group, ko_stage_complete,
    tippspiel_score_stage_if_ready, tippspiel_apply_match_result, tippspiel_update_leaderboard_message, ko_match_id_from_group,
    remove_earliest_confirmed_termin,
    _same_pair, _parse_dt,
)
from embeds import embed_result
from update import update_scoreboard_channel, update_termin_channel, update_stream_schedule_channel, update_orga_overview_channel


def _earliest_termin_record(group: str, s1: str, s2: str):
    """Return (record, dt) for earliest confirmed termin for the pair, or (None,None)."""
    try:
        arr = load_json(TERMINE_PATH, [])
    except Exception:
        arr = []
    cand = [t for t in (arr or []) if _same_pair(group, s1, s2, t)]
    best = None
    best_dt = None
    for t in cand:
        try:
            dt = _parse_dt(str(t.get("datum","")), str(t.get("uhrzeit","")))
        except Exception:
            dt = None
        if dt is None:
            continue
        if best_dt is None or dt < best_dt:
            best_dt = dt
            best = t
    if best is None and cand:
        best = cand[0]
    return best, best_dt

config = load_config()

async def _safe_reply(interaction: discord.Interaction, **kwargs):
    """Send a reply without throwing if the interaction was already responded to."""
    try:
        if hasattr(interaction, "response") and not interaction.response.is_done():
            return await interaction.response.send_message(**kwargs)
    except Exception:
        pass
    try:
        return await interaction.followup.send(**kwargs)
    except Exception:
        return None


async def _get_stats_file_for_result(interaction: discord.Interaction, rec: dict):
    """Return (discord.File|None, attach_url|None) for a stored stats image.

    Priority:
      1) local cached file path (written by /stati)
      2) original Discord attachment (if source channel/message stored)
      3) HTTP download of stored CDN url
    """
    stati_url = rec.get("stati_image")
    local_path = rec.get("stati_local_path")

    file_obj = None
    attach_url = None

    # 1) Local cached file
    if local_path and isinstance(local_path, str):
        try:
            import os
            if os.path.isfile(local_path):
                file_obj = discord.File(local_path, filename=os.path.basename(local_path))
                attach_url = f"attachment://{file_obj.filename}"
                return file_obj, attach_url
        except Exception:
            file_obj = None
            attach_url = None

    # 2) Original Discord attachment
    src_ch_id = rec.get("stati_source_channel_id")
    src_msg_id = rec.get("stati_source_message_id")
    if file_obj is None and src_ch_id and src_msg_id:
        try:
            src_ch = interaction.guild.get_channel(int(src_ch_id))
            if isinstance(src_ch, discord.TextChannel):
                src_msg = await src_ch.fetch_message(int(src_msg_id))
                for a in (src_msg.attachments or []):
                    ctype = getattr(a, "content_type", None) or ""
                    fname = (a.filename or "").lower()
                    if (ctype.startswith("image") or fname.endswith((".png", ".jpg", ".jpeg", ".webp", ".gif"))):
                        file_obj = await a.to_file()
                        attach_url = f"attachment://{file_obj.filename}"
                        return file_obj, attach_url
        except Exception:
            file_obj = None
            attach_url = None

    # 3) HTTP download fallback
    if file_obj is None and isinstance(stati_url, str) and stati_url.startswith("http"):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(stati_url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        fn = "stati.png"
                        low = stati_url.lower()
                        for ext in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
                            if ext in low:
                                fn = "stati" + ext
                                break
                        file_obj = discord.File(io.BytesIO(data), filename=fn)
                        attach_url = f"attachment://{fn}"
                        return file_obj, attach_url
        except Exception:
            file_obj = None
            attach_url = None

    return None, None

async def _post_result_embed(
    interaction: discord.Interaction,
    group: str,
    s1: str,
    s2: str,
    winner: str,
    note: Optional[str],
    results_channel_id: int,
    score: Optional[str] = None
) -> Optional[Tuple[int, int]]:
    ch = interaction.guild.get_channel(int(results_channel_id)) if results_channel_id else None
    if not isinstance(ch, discord.TextChannel):
        return None
    rec = get_match_record(group, s1, s2) or {}
    mode = rec.get("final_mode") or rec.get("mode")
    # If we have stats, attach them directly to the results message.
    file_obj, attach_url = await _get_stats_file_for_result(interaction, rec)

    em = embed_result(group, s1, s2, winner, by=note, mode=mode, score=score, image_url=attach_url if file_obj and attach_url else None)
    if file_obj:
        msg = await ch.send(embed=em, file=file_obj)
    else:
        msg = await ch.send(embed=em)
    return ch.id, msg.id

async def _lock_match_channel(interaction: discord.Interaction, s1: str, s2: str):
    """Remove bot views and lock both players in the current channel."""
    try:
        ch = getattr(interaction, "channel", None)
        if not isinstance(ch, discord.TextChannel):
            return
        # remove views on recent bot messages
        try:
            async for msg in ch.history(limit=50):
                if interaction.client and msg.author.id == interaction.client.user.id:
                    try:
                        await msg.edit(view=None)
                    except Exception:
                        pass
        except Exception:
            pass
        # lock players
        m1 = resolve_member_by_name(interaction.guild, s1)
        m2 = resolve_member_by_name(interaction.guild, s2)
        for mbr in [m1, m2]:
            if mbr:
                try:
                    await ch.set_permissions(mbr, view_channel=True, send_messages=False)
                except Exception:
                    pass
    except Exception:
        pass

async def handle_confirmed_win(
    interaction: discord.Interaction,
    group: str,
    s1: str,
    s2: str,
    winner: str,
    note: Optional[str],
    results_channel_id: int
):
    """
    Swiss: closes match immediately.
    KO: counts as a *game* win; closes match only when the BO-series is complete.
    """
    is_ko = str(group).startswith("KO-")

    if is_ko:
        cur_game_no = None
        # Enforce: each KO game result can only be confirmed after /matchstart was run for that game.
        # Orga overrides use a note marker.
        try:
            if not (note and "FORCE" in str(note).upper()):
                rec0 = get_match_record(group, s1, s2) or {}
                wins0 = rec0.get("ko_wins") or {s1: 0, s2: 0}
                cur_game_no = int(wins0.get(s1, 0) or 0) + int(wins0.get(s2, 0) or 0) + 1

                # Idempotency / double-click protection:
                # If a user confirms the same winner request twice (or Discord replays an interaction
                # after reconnect), do NOT count another game.
                if int(rec0.get("ko_last_confirmed_game_no") or 0) == cur_game_no:
                    await _safe_reply(
                        interaction,
                        embed=discord.Embed(
                            description="⚠️ Dieses Game wurde bereits bestätigt. / This game was already confirmed.",
                            color=discord.Color.orange(),
                        ),
                        ephemeral=True,
                    )
                    return
                # Persisted gate: only the stored game number matters.
                # Do NOT require a transient boolean flag; bot restarts/reconnects can drop it.
                if int(rec0.get("ko_game_started_no") or 0) != cur_game_no:
                    await _safe_reply(
                        interaction,
                        embed=discord.Embed(
                            description="❌ Ergebnis kann erst nach **/matchstart** gelockt werden.",
                            color=discord.Color.red(),
                        ),
                        ephemeral=True,
                    )
                    return
        except Exception:
            pass

        # Record this as a *game* win (KO) and consume one scheduled game slot.
        rec = ko_record_game_win(group, s1, s2, winner)
        score = ko_get_series_score_str(rec, s1, s2)

        # Persist that this specific game number has been confirmed.
        if isinstance(cur_game_no, int) and cur_game_no > 0:
            try:
                upsert_match_record(group, s1, s2, ko_last_confirmed_game_no=cur_game_no)
            except Exception:
                pass

        # clear matchstart gate for next game
        try:
            upsert_match_record(group, s1, s2, ko_game_started=False, ko_game_started_no=None)
        except Exception:
            pass

        # per-game civ stats (count each game, not series)
        try:
            picks = (rec.get("ko_picks_last") or rec.get("ko_picks_partial") or {})
            if isinstance(picks, dict):
                from utils import civstats_apply_game, civstats_update_message
                civstats_apply_game(picks, winner)
                await civstats_update_message(interaction.client, interaction.guild)
        except Exception:
            pass        # consume exactly one game from the earliest confirmed date (supports +1/+2 attachments)
        # If a termin gets fully consumed (cover_games reached), delete its message in the match channel.
        try:
            before_rec, _ = _earliest_termin_record(group, s1, s2)
            before_key = None
            if before_rec:
                before_key = (int(before_rec.get("channel_id", 0) or 0), int(before_rec.get("message_id", 0) or 0))
            remove_earliest_confirmed_termin(group, s1, s2)
            if before_key and all(before_key):
                # check if record still exists
                arr_now = load_json(TERMINE_PATH, [])
                still = any(int(t.get("channel_id",0) or 0)==before_key[0] and int(t.get("message_id",0) or 0)==before_key[1] for t in (arr_now or []))
                if not still:
                    chx = interaction.guild.get_channel(before_key[0])
                    if isinstance(chx, discord.TextChannel):
                        try:
                            m = await chx.fetch_message(before_key[1])
                            await m.delete()
                        except Exception:
                            pass
        except Exception:
            pass

        # If the series is NOT complete yet, post running score and keep the channel open.
        if not ko_is_series_complete(rec, s1, s2):
            # running score message (match channel)
            try:
                if isinstance(interaction.channel, discord.TextChannel):
                    await interaction.channel.send(
                        embed=discord.Embed(
                            description=f"📊 Zwischenstand / Score: **{score}**",
                            color=discord.Color.blurple(),
                        )
                    )
            except Exception:
                pass

            # also post running score to results channel
            try:
                rch = interaction.guild.get_channel(int(results_channel_id))
                if isinstance(rch, discord.TextChannel):
                    rec_now = get_match_record(group, s1, s2) or {}
                    file_obj, attach_url = await _get_stats_file_for_result(interaction, rec_now)
                    em = discord.Embed(
                        title="📊 Zwischenstand / Score",
                        description=f"**{group}** — {s1} vs {s2}\nScore: **{score}**",
                        color=discord.Color.blurple(),
                    )
                    # Attach stats image (as real attachment) if available.
                    if file_obj:
                        # Optionally show it inline
                        try:
                            em.set_image(url=attach_url)
                        except Exception:
                            pass
                        await rch.send(embed=em, file=file_obj)
                    else:
                        await rch.send(embed=em)
            except Exception:
                pass

            upsert_match_record(group, s1, s2, closed=False)
            try:
                cfg = load_config()
                tid = int((((cfg.get('channels', {}) or {}).get('termine_channel_id')) or cfg.get('termine_public_id') or 0) or 0)
                if tid:
                    await update_termin_channel(interaction.guild, tid)
                await update_stream_schedule_channel(interaction.guild, config.get("stream_schedule_channel_id"))
                await update_orga_overview_channel(interaction.guild, int(config.get("orga_overview_channel_id", 0) or 0))
            except Exception:
                pass
            await _safe_reply(
                interaction,
                embed=discord.Embed(
                    description=f"✅ Game bestätigt. / Game confirmed.\n📊 Score: **{score}**\n\n➡️ Weiter: **/matchstart** für das nächste Game.",
                    color=discord.Color.green(),
                ),
                ephemeral=True,
            )
            return

        # ---------------- series complete ----------------
        wins = rec.get("ko_wins") or {}
        w1 = int(wins.get(s1, 0) or 0)
        w2 = int(wins.get(s2, 0) or 0)
        series_winner = s1 if w1 > w2 else s2
        final_score = f"{max(w1, w2)}:{min(w1, w2)}"

        # persist final result
        data = load_json(ERGEBNISSE_PATH, {})
        # Defensive: older/broken files could be a list; treat as empty dict.
        if not isinstance(data, dict):
            data = {}
        pair = {s1, s2}
        for k in list(data.keys()):
            try:
                g, a, b = k.split("|", 2)
            except Exception:
                continue
            if g == group and {a, b} == pair:
                data.pop(k, None)

        a, b = sorted([s1, s2], key=lambda x: x.lower())
        key = f"{group}|{a}|{b}"
        data[key] = {"winner": series_winner, "by": note, "score": final_score}
        save_json(ERGEBNISSE_PATH, data)

        res = await _post_result_embed(
            interaction,
            group,
            s1,
            s2,
            series_winner,
            note,
            results_channel_id,
            score=final_score,
        )
        ch_id, msg_id = (res or (None, None))
        upsert_match_record(
            group,
            s1,
            s2,
            closed=True,
            result_channel_id=ch_id,
            result_message_id=msg_id,
            ko_score=final_score,
            ko_series_winner=series_winner,
        )

        # remove leftover confirmed dates for this match (e.g. if a +1/+2 session was planned but the series ended early)
        try:
            term = load_json(TERMINE_PATH, [])
            term = [t for t in term if not (t.get("gruppe") == group and {t.get("spieler1"), t.get("spieler2")} == {s1, s2})]
            save_json(TERMINE_PATH, term)
        except Exception:
            pass

        # clear any remaining open proposals for this match
        unconf = load_json(UNCONFIRMED_PATH, [])
        unconf = [u for u in unconf if not (u.get("gruppe") == group and {u.get("spieler1"), u.get("spieler2")} == {s1, s2})]
        save_json(UNCONFIRMED_PATH, unconf)

        # update KO bracket file
        try:
            ko_update_bracket_result(group, series_winner, final_score)
        except Exception:
            pass

        await _lock_match_channel(interaction, s1, s2)

        # tips scoring (incremental per match)
        try:
            mid = ko_match_id_from_group(group)
            if mid:
                tippspiel_apply_match_result(mid, series_winner, final_score)
                await tippspiel_update_leaderboard_message(interaction.client, interaction.guild)
        except Exception:
            pass

        # tips scoring (stage-complete, legacy)
        try:
            stage = ko_stage_from_group(group)
            if stage and ko_stage_complete(stage):
                await tippspiel_score_stage_if_ready(interaction.client, interaction.guild, stage)
        except Exception:
            pass

        # update channels
        try:
            tid = int((((config.get('channels', {}) or {}).get('termine_channel_id')) or config.get('termine_public_id') or 0) or 0)
            if tid:
                await update_termin_channel(interaction.guild, tid)
            await update_stream_schedule_channel(interaction.guild, config.get("stream_schedule_channel_id"))
            await update_orga_overview_channel(interaction.guild, int(config.get("orga_overview_channel_id", 0) or 0))
        except Exception:
            pass

        await _safe_reply(
            interaction,
            embed=discord.Embed(
                description=f"✅ Serie abgeschlossen / Series completed: **{series_winner}** ({final_score})",
                color=discord.Color.green(),
            ),
            ephemeral=True,
        )
        return

    # ---------------- Swiss (old behavior) ----------------
    # Enforce: Swiss result can only be confirmed after /matchstart.
    try:
        if not (note and "FORCE" in str(note).upper()):
            rec0 = get_match_record(group, s1, s2) or {}
            if not rec0.get("swiss_match_started"):
                await _safe_reply(
                    interaction,
                    embed=discord.Embed(
                        description="❌ Ergebnis kann erst nach **/matchstart** gelockt werden.",
                        color=discord.Color.red(),
                    ),
                    ephemeral=True,
                )
                return
    except Exception:
        pass

    data = load_json(ERGEBNISSE_PATH, {})
    to_del = []
    pair = {s1, s2}
    for k in list(data.keys()):
        try:
            g, a, b = k.split("|", 2)
        except Exception:
            continue
        if g == group and {a, b} == pair:
            to_del.append(k)
    for k in to_del:
        data.pop(k, None)

    a, b = sorted([s1, s2], key=lambda x: x.lower())
    key = f"{group}|{a}|{b}"
    data[key] = {"winner": winner, "by": note}
    save_json(ERGEBNISSE_PATH, data)

    res = await _post_result_embed(interaction, group, s1, s2, winner, note, results_channel_id)
    ch_id, msg_id = (res or (None, None))
    upsert_match_record(
        group, s1, s2,
        closed=True,
        result_channel_id=ch_id,
        result_message_id=msg_id,
        swiss_match_started=False,
        swiss_stats_attached=False,
        swiss_stats_attachment_url=None,
        swiss_stats_attached_by=None,
    )

    term = load_json(TERMINE_PATH, [])
    term = [t for t in term if not (t.get("gruppe")==group and {t.get("spieler1"), t.get("spieler2")}=={s1, s2})]
    save_json(TERMINE_PATH, term)
    unconf = load_json(UNCONFIRMED_PATH, [])
    unconf = [u for u in unconf if not (u.get("gruppe")==group and {u.get("spieler1"), u.get("spieler2")}=={s1, s2})]
    save_json(UNCONFIRMED_PATH, unconf)

    await _lock_match_channel(interaction, s1, s2)

    try:
        cfg = load_config()
        tid = int((((cfg.get('channels', {}) or {}).get('termine_channel_id')) or cfg.get('termine_public_id') or 0) or 0)
        if tid:
            await update_termin_channel(interaction.guild, tid)
        await update_stream_schedule_channel(interaction.guild, config.get("stream_schedule_channel_id"))
        await update_scoreboard_channel(interaction.guild, config.get("gruppen"), config.get("scoreboard_channel_id"))
        await update_orga_overview_channel(interaction.guild, int(config.get("orga_overview_channel_id", 0) or 0))
    except Exception:
        pass

    await _safe_reply(interaction, embed=discord.Embed(description=f"✅ Sieger gespeichert: **{winner}**.", color=discord.Color.green()), ephemeral=True)

async def change_winner(interaction: discord.Interaction, group: str, s1: str, s2: str, new_winner: str, reason: str, results_channel_id: int):
    await handle_confirmed_win(interaction, group, s1, s2, new_winner, f"{interaction.user.name} (change: {reason})", results_channel_id)


async def force_reset_match_state(
    guild: discord.Guild,
    group: str,
    s1: str,
    s2: str,
    channel: Optional[discord.TextChannel] = None,
):
    """Owner utility: reset a match channel state (dates/UI/KO game progress) without touching bracket.

    This is intentionally conservative: it clears proposed/confirmed dates and pending confirmations,
    re-enables chat permissions for the two players, and clears per-match KO progress fields in the
    match record so /matchstart can be run again.
    """

    # clear schedule/proposals
    try:
        term = load_json(TERMINE_PATH, [])
        term = [t for t in term if not (t.get("gruppe") == group and {t.get("spieler1"), t.get("spieler2")} == {s1, s2})]
        save_json(TERMINE_PATH, term)
    except Exception:
        pass

    try:
        unconf = load_json(UNCONFIRMED_PATH, [])
        unconf = [u for u in unconf if not (u.get("gruppe") == group and {u.get("spieler1"), u.get("spieler2")} == {s1, s2})]
        save_json(UNCONFIRMED_PATH, unconf)
    except Exception:
        pass

    # reset match record fields
    try:
        upsert_match_record(
            group,
            s1,
            s2,
            closed=False,
            result_channel_id=None,
            result_message_id=None,
            final_mode=None,
            ko_score=None,
            ko_series_winner=None,
            ko_wins={s1: 0, s2: 0},
            ko_used_factions={s1: [], s2: []},
            ko_counterpick_pref=None,
            ko_game_no=1,
            ko_map=None,
            ko_map_num=None,
        )
    except Exception:
        pass

    # clean up bot UI in channel and re-enable send permissions
    try:
        ch = channel
        if ch is None:
            # best-effort resolve current channel by scanning topics is not feasible here; caller passes channel.
            return
        # remove views on recent bot messages
        try:
            async for msg in ch.history(limit=50):
                if msg.author and guild.me and msg.author.id == guild.me.id:
                    try:
                        await msg.edit(view=None)
                    except Exception:
                        pass
        except Exception:
            pass

        m1 = resolve_member_by_name(guild, s1)
        m2 = resolve_member_by_name(guild, s2)
        for mbr in [m1, m2]:
            if mbr:
                try:
                    await ch.set_permissions(mbr, view_channel=True, send_messages=True)
                except Exception:
                    pass
    except Exception:
        pass