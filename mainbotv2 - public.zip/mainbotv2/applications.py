import asyncio
import discord
from utils import load_config, apps_state_get, apps_state_set, players_set, get_role
from utils import load_json, save_json, PLAYERS_PATH
from discord import ui

config = load_config()

def _read_excel_rows(path: str):
    try:
        from openpyxl import load_workbook
    except Exception as e:
        return {"error": f"openpyxl fehlt: {e}", "rows": []}
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        headers = {cell.value: idx for idx, cell in enumerate(ws[1], start=1)}
        need = ["DiscordID", "IngameName"]
        if not all(h in headers for h in need):
            return {"error": f"Excel-Header fehlen: {need}", "rows": []}
        rows = []
        for r in range(2, ws.max_row + 1):
            did = ws.cell(row=r, column=headers["DiscordID"]).value
            name = ws.cell(row=r, column=headers["IngameName"]).value
            if did and name:
                try:
                    did = int(str(did).strip())
                except Exception:
                    continue
                rows.append({"row": r, "discord_id": did, "ingame_name": str(name).strip()})
        return {"rows": rows}
    except Exception as e:
        return {"error": str(e), "rows": []}

async def _upsert_staff_message(guild: discord.Guild):
    st = apps_state_get()
    ch_id = config.get("admin_channel_id")
    if not ch_id:
        return
    ch = guild.get_channel(ch_id)
    if not ch:
        return

    # nächster offener Eintrag
    pend = st.get("pending", [])
    entry = pend[0] if pend else None
    content = "Keine offenen Bewerbungen. / No pending applications."
    view = None
    embed = None
    if entry:
        embed = discord.Embed(
            title="Bewerbung / Application",
            description=(f"Discord ID: `{entry['discord_id']}`\n"
                         f"Ingame: **{entry['ingame_name']}**"),
            color=discord.Color.blurple()
        )
        view = _AppView(entry)

    msg_id = st.get("staff_msg_id")
    msg = None
    if msg_id:
        try:
            msg = await ch.fetch_message(int(msg_id))
        except Exception:
            msg = None

    if msg:
        await msg.edit(content=content if not entry else "Nächste Bewerbung / Next application", embed=embed, view=view)
    else:
        m = await ch.send(content if not entry else "Nächste Bewerbung / Next application", embed=embed, view=view)
        st["staff_msg_id"] = m.id
        apps_state_set(st)

class _DenyModal(ui.Modal, title="Ablehnen / Deny"):
    reason = ui.TextInput(label="Begründung / Reason", style=discord.TextStyle.paragraph, required=True)
    def __init__(self, entry, cb):
        super().__init__()
        self.entry = entry
        self.cb = cb
    async def on_submit(self, interaction: discord.Interaction):
        await self.cb(interaction, str(self.reason))

class _AppView(discord.ui.View):
    def __init__(self, entry):
        super().__init__(timeout=None)
        self.entry = entry

    @discord.ui.button(label="Annehmen/Accept", style=discord.ButtonStyle.success)
    async def accept(self, interaction: discord.Interaction, btn: discord.ui.Button):
        if interaction.user.id not in (config.get("turnierleitung_ids") or []) and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Keine Berechtigung. / No permission.", ephemeral=True)
            return
        gid = self.entry["discord_id"]
        ing = self.entry["ingame_name"]
        member = interaction.guild.get_member(gid) or (await interaction.guild.fetch_member(gid) if interaction.guild else None)
        # Rolle + Nick
        try:
            pr = get_role(interaction.guild, (config.get("roles") or {}).get("player"))
            if pr and member:
                await member.add_roles(pr, reason="S4WC registration accepted")
        except Exception:
            pass
        try:
            if member:
                await member.edit(nick=ing, reason="S4WC registration accepted")
        except Exception:
            pass
        players_set(gid, ing)
        # Announcement + DM
        ann_id = config.get("announcements_channel_id")
        if ann_id:
            ann = interaction.guild.get_channel(ann_id)
            if ann:
                await ann.send(f"📣 Spieler **{ing}** wurde registriert.\n📣 Player **{ing}** has been registered.")
        try:
            u = member or (await interaction.client.fetch_user(gid))
            await u.send(f"✅ Deine Anmeldung wurde angenommen. Willkommen, **{ing}**!\n✅ Your application has been accepted. Welcome, **{ing}**!")
        except Exception:
            pass

        # Queue vorrücken
        st = apps_state_get()
        pend = st.get("pending", [])
        if pend and pend[0]["discord_id"] == gid:
            pend.pop(0)
        st["pending"] = pend
        apps_state_set(st)

        await _upsert_staff_message(interaction.guild)
        await interaction.response.send_message("✅ Angenommen. / Accepted.", ephemeral=True)

    @discord.ui.button(label="Ablehnen/Deny", style=discord.ButtonStyle.danger)
    async def deny(self, interaction: discord.Interaction, btn: discord.ui.Button):
        if interaction.user.id not in (config.get("turnierleitung_ids") or []) and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("Keine Berechtigung. / No permission.", ephemeral=True)
            return

        async def _cb(inter: discord.Interaction, reason: str):
            gid = self.entry["discord_id"]
            ing = self.entry["ingame_name"]
            try:
                u = await inter.client.fetch_user(gid)
                await u.send(f"❌ Deine Anmeldung wurde abgelehnt.\nGrund/Reason: {reason}")
            except Exception:
                pass
            st = apps_state_get()
            pend = st.get("pending", [])
            if pend and pend[0]["discord_id"] == gid:
                pend.pop(0)
            st["pending"] = pend
            apps_state_set(st)
            await _upsert_staff_message(inter.guild)
            await inter.response.send_message("❌ Abgelehnt. / Denied.", ephemeral=True)

        await interaction.response.send_modal(_DenyModal(self.entry, _cb))

# ---------- Public API ----------
_app_task: asyncio.Task | None = None

async def applications_on_ready(guild: discord.Guild):
    # erste Auslieferung
    await scan_and_queue(guild)
    await _upsert_staff_message(guild)
    global _app_task
    if _app_task is None:
        _app_task = asyncio.create_task(_poll_loop(guild))

async def _poll_loop(guild: discord.Guild):
    while True:
        try:
            await scan_and_queue(guild)
            await _upsert_staff_message(guild)
        except Exception:
            pass
        await asyncio.sleep(30)

async def scan_and_queue(guild: discord.Guild):
    src = config.get("applications_source", {})
    if (src.get("type") or "").lower() != "excel":
        return
    path = src.get("path_or_id")
    if not path:
        return
    st = apps_state_get()
    last_row = int(st.get("last_row", 1))
    result = _read_excel_rows(path)
    rows = result.get("rows", [])
    # filter neue
    new_rows = [r for r in rows if r["row"] > last_row]
    if not new_rows:
        return
    # Queue anhängen
    pend = st.get("pending", [])
    for r in new_rows:
        pend.append({"discord_id": r["discord_id"], "ingame_name": r["ingame_name"]})
        last_row = max(last_row, r["row"])
    st["pending"] = pend
    st["last_row"] = last_row
    apps_state_set(st)
