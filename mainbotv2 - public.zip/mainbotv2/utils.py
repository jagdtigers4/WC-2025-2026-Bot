import json
import os
from typing import Any, Dict, List, Optional
import datetime
# ---- file paths ----
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")

# ---- KO debug / tournament helpers ----
ERGEBNISSE_PATH = "ergebnisse.json"
TERMINE_PATH = "termine.json"
UNCONFIRMED_PATH = "unconfirmed.json"
MATCHES_PATH = "matches.json"
APPS_STATE_PATH = "apps_state.json"
STREAMERS_PATH = "streamers.json"
PLAYERS_PATH = "players.json"
COUNTERS_PATH = "counters.json"
CANCEL_REQUESTS_PATH = "cancel_requests.json"  # Storno-Anfragen

# ---- additional stores ----
TIPPSPIEL_PATH = "tippspiel.json"
BONUS_TIPS_PATH = "bonus_tips.json"
KO_BRACKET_PATH = "ko_bracket.json"
WINNER_PENDING_PATH = "winner_pending.json"

# ---- Völkerstatistik store ----
CIV_STATS_PATH = "civ_stats.json"
# ---- small helpers ----
def _ensure_parent(path: str):
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)
def swiss_get_all_pairs(config: dict) -> list[tuple[str, str, str]]:
    """
    Liefert alle Swiss-Matches als Liste von (group, s1, s2).
    Unterstützt zwei Varianten von config["swiss"]["matches"]:
    - Dict: { "1:0": [[p1,p2], ...], "0:1": [...], ... }
      -> group entspricht dem jeweiligen Bracket-Key.
    - Liste (Legacy): [[p1,p2], ...]
      -> alles wird im Bracket "0:0" geführt.
    """
    pairs: list[tuple[str, str, str]] = []
    try:
        swiss = (config.get("swiss") or {})
        matches = swiss.get("matches") or []
        if isinstance(matches, dict):
            buckets = swiss.get("buckets") or list(matches.keys())
            used: set[tuple[str, str, str]] = set()
            for group in buckets:
                plist = matches.get(group) or []
                for pair in plist:
                    try:
                        p1, p2 = pair[0], pair[1]
                    except Exception:
                        continue
                    key = (str(group), str(p1), str(p2))
                    if key in used:
                        continue
                    used.add(key)
                    pairs.append(key)
            # eventuelle Gruppen, die nicht in buckets stehen
            for group, plist in matches.items():
                if group in (swiss.get("buckets") or []):
                    continue
                for pair in plist:
                    try:
                        p1, p2 = pair[0], pair[1]
                    except Exception:
                        continue
                    key = (str(group), str(p1), str(p2))
                    if key in used:
                        continue
                    used.add(key)
                    pairs.append(key)
        else:
            group = "0:0"
            for pair in matches:
                try:
                    p1, p2 = pair[0], pair[1]
                except Exception:
                    continue
                pairs.append((group, str(p1), str(p2)))
    except Exception:
        # Fallback: leere Liste
        return []
    return pairs
def load_json(path: str, default: Any):
    try:
        if not os.path.exists(path):
            return default
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default
def save_json(path: str, data: Any):
    try:
        _ensure_parent(path)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass
def load_config() -> Dict[str, Any]:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)
# ---- roles / permissions ----
def get_role(guild, spec):
    """spec may be role name (str) or role id (int)."""
    if spec is None:
        return None
    if isinstance(spec, int):
        return guild.get_role(spec)
    if isinstance(spec, str):
        for r in guild.roles:
            if r.name == spec:
                return r
    return None
def is_owner(user, config: Dict[str, Any]) -> bool:
    roles_cfg = (config.get("roles") or {})
    owner_name = roles_cfg.get("owner") if isinstance(roles_cfg.get("owner"), str) else "Owner"
    return getattr(user.guild_permissions, "administrator", False) or any(r.name == owner_name for r in getattr(user, "roles", []) or [])
def is_admin(user, turnierleitung_ids: List[int]) -> bool:
    if isinstance(turnierleitung_ids, list) and user.id in turnierleitung_ids:
        return True
    if getattr(user.guild_permissions, "manage_guild", False) or getattr(user.guild_permissions, "administrator", False):
        return True
    return any(r.name in ("Admin", "Owner") for r in getattr(user, "roles", []) or [])
# ---- match helpers (checkin / vod / stati) ----
def match_append_vod(group: str, s1: str, s2: str, url: str):
    rec = get_match_record(group, s1, s2) or {}
    urls = rec.get("vod_urls") or []
    # alte Einzel-URL migrieren
    if isinstance(rec.get("vod_url"), str) and rec.get("vod_url") not in urls:
        urls.append(rec.get("vod_url"))
        rec.pop("vod_url", None)
    if url and url not in urls:
        urls.append(url)
    upsert_match_record(group, s1, s2, vod_urls=urls)
def match_set_stati_image(group: str, s1: str, s2: str, url: str | None):
    upsert_match_record(group, s1, s2, stati_image=(url or None))
def match_checked_in(group: str, s1: str, s2: str) -> list[int]:
    rec = get_match_record(group, s1, s2) or {}
    arr = rec.get("checked_in_ids") or []
    try:
        return [int(x) for x in arr]
    except Exception:
        return []
def match_add_checkin(group: str, s1: str, s2: str, discord_id: int):
    ids = set(match_checked_in(group, s1, s2))
    ids.add(int(discord_id))
    upsert_match_record(group, s1, s2, checked_in_ids=list(ids))
# ---- app state ----
def apps_state_get() -> Dict[str, Any]:
    d = load_json(APPS_STATE_PATH, {})
    if "pending" not in d:
        d["pending"] = []
    return d
def apps_state_set(state: Dict[str, Any]):
    save_json(APPS_STATE_PATH, state)
# ---- players / streamers ----
def streamer_get(discord_id: int) -> Dict[str, Any]:
    data = load_json(STREAMERS_PATH, {})
    return data.get(str(discord_id), {})
def streamer_set(discord_id: int, name: str, link: str):
    data = load_json(STREAMERS_PATH, {})
    data[str(discord_id)] = {"name": name, "link": link}
    save_json(STREAMERS_PATH, data)
def players_set(discord_id: int, ingame: str, alias: Optional[str] = None, discord_name: Optional[str] = None):
    """Robust gegen altes String-Format in players.json."""
    data = load_json(PLAYERS_PATH, {})
    key = str(discord_id)
    rec = data.get(key, {"aliases": [], "discord_names": []})
    if isinstance(rec, str):
        rec = {"ingame": rec, "aliases": [], "discord_names": []}
    if not isinstance(rec, dict):
        rec = {"aliases": [], "discord_names": []}
    rec["ingame"] = ingame
    if alias and alias not in rec.get("aliases", []):
        rec.setdefault("aliases", []).append(alias)
    if discord_name and discord_name not in rec.get("discord_names", []):
        rec.setdefault("discord_names", []).append(discord_name)
    data[key] = rec
    save_json(PLAYERS_PATH, data)
def players_get(discord_id: int) -> Dict[str, Any]:
    data = load_json(PLAYERS_PATH, {})
    rec = data.get(str(discord_id))
    if isinstance(rec, str):
        return {"ingame": rec, "aliases": [], "discord_names": []}
    return rec or {}
def players_name_for(discord_id: int) -> Optional[str]:
    return (players_get(discord_id) or {}).get("ingame")
# ---- pair/match persistence ----
def _same_pair(group: str, s1: str, s2: str, rec: Dict[str, Any]) -> bool:
    """Case/whitespace-tolerant match identity.

    This prevents edge cases where the same player appears as e.g. "Jagdtiger" vs
    "jagdtiger" (Discord name, ingame name, topic, imported bracket, etc.).
    """

    def _n(x: Any) -> str:
        return " ".join(str(x or "").strip().split()).casefold()

    if _n(rec.get("gruppe")) != _n(group):
        return False

    a1, a2 = _n(rec.get("spieler1")), _n(rec.get("spieler2"))
    b1, b2 = _n(s1), _n(s2)
    return {a1, a2} == {b1, b2}
def upsert_match_record(group: str, s1: str, s2: str, **updates):
    data = load_json(MATCHES_PATH, [])
    found = None
    for m in data:
        if _same_pair(group, s1, s2, m):
            found = m
            break
    if not found:
        found = {"gruppe": group, "spieler1": s1, "spieler2": s2}
        data.append(found)
    if "stream_signups" in updates:
        try:
            updates["stream_signups"] = [int(x) for x in (updates["stream_signups"] or [])]
        except Exception:
            updates["stream_signups"] = []
    for k, v in updates.items():
        found[k] = v
    save_json(MATCHES_PATH, data)
def get_match_record(group: str, s1: str, s2: str) -> Optional[Dict[str, Any]]:
    data = load_json(MATCHES_PATH, [])
    for m in data:
        if _same_pair(group, s1, s2, m):
            return m
    return None
def match_closed_persisted(group: str, s1: str, s2: str) -> bool:
    """True, falls das Match als 'closed' persistiert wurde (z. B. nach finalem Ergebnis)."""
    rec = get_match_record(group, s1, s2)
    return bool(rec and rec.get("closed"))
def pair_has_unconfirmed(group: str, s1: str, s2: str) -> bool:
    arr = load_json(UNCONFIRMED_PATH, [])
    return any(_same_pair(group, s1, s2, x) for x in arr)
def pair_has_confirmed(group: str, s1: str, s2: str) -> bool:
    arr = load_json(TERMINE_PATH, [])
    return any(_same_pair(group, s1, s2, x) for x in arr)
def confirmed_for_pair(group: str, s1: str, s2: str) -> List[Dict[str, Any]]:
    arr = load_json(TERMINE_PATH, [])
    return [x for x in arr if _same_pair(group, s1, s2, x)]
def confirmed_count_for_pair(group: str, s1: str, s2: str) -> int:
    return len(confirmed_for_pair(group, s1, s2))
def _parse_dt(datum: str, uhrzeit: str) -> Optional[datetime.datetime]:
    try:
        dd, mm, yy = map(int, (datum or "").split("."))
        hh, mi = map(int, (uhrzeit or "").split(":"))
        return datetime.datetime(yy, mm, dd, hh, mi)
    except Exception:
        return None
def next_confirmed_for_pair(group: str, s1: str, s2: str) -> Optional[Dict[str, Any]]:
    items = confirmed_for_pair(group, s1, s2)
    if not items:
        return None
    items.sort(key=lambda t: _parse_dt(t.get("datum",""), t.get("uhrzeit","")) or datetime.datetime.max)
    return items[0]
def upsert_termin_record(group: str, s1: str, s2: str, datum: str, uhrzeit: str,
                         channel_id: Optional[int] = None, message_id: Optional[int] = None):
    """Fügt/aktualisiert einen bestätigten Termin und speichert optional Channel/Message-ID der Bestätigungsnachricht."""
    arr = load_json(TERMINE_PATH, [])
    found = None
    for t in arr:
        if _same_pair(group, s1, s2, t) and t.get("datum")==datum and t.get("uhrzeit")==uhrzeit:
            found = t
            break
    if not found:
        found = {"gruppe": group, "spieler1": s1, "spieler2": s2, "datum": datum, "uhrzeit": uhrzeit, "cover_games": 1, "used_games": 0}
        arr.append(found)
    # defaults for KO multi-game sessions
    found.setdefault("cover_games", 1)
    found.setdefault("used_games", 0)
    if channel_id is not None:
        found["channel_id"] = int(channel_id)
    if message_id is not None:
        found["message_id"] = int(message_id)
    save_json(TERMINE_PATH, arr)
def get_termin_record(group: str, s1: str, s2: str, datum: str, uhrzeit: str) -> Optional[Dict[str, Any]]:
    arr = load_json(TERMINE_PATH, [])
    for t in arr:
        if _same_pair(group, s1, s2, t) and t.get("datum")==datum and t.get("uhrzeit")==uhrzeit:
            return t
    return None
def remove_confirmed_termin(group: str, s1: str, s2: str, datum: str, uhrzeit: str) -> bool:
    """Entfernt exakt den bestätigten Termin und speichert die Liste – gibt True zurück, wenn etwas entfernt wurde.
    Zusätzlich werden vorhandene Streamer-Anmeldungen für dieses Match zurückgesetzt, damit sie bei einem neuen Termin
    nicht automatisch weitergelten."""
    arr = load_json(TERMINE_PATH, [])
    new_arr = [t for t in arr if not (_same_pair(group, s1, s2, t) and t.get("datum")==datum and t.get("uhrzeit")==uhrzeit)]
    changed = len(new_arr) != len(arr)
    if changed:
        save_json(TERMINE_PATH, new_arr)
        # Stream-Signups zurücksetzen
        try:
            upsert_match_record(group, s1, s2, stream_signups=[])
        except Exception:
            pass
    return changed
def pending_cancel_exists(group: str, s1: str, s2: str) -> bool:
    store = load_json(CANCEL_REQUESTS_PATH, [])
    return any(_same_pair(group, s1, s2, r) for r in store)
# ---- discord helpers ----
def resolve_member_by_name(guild, name: str):
    """Sucht Member zuerst direkt über Namen/Nickname. Fallback: players.json Mapping (ingame/aliases/discord_names)."""
    try:
        if not guild or not name:
            return None
        # 1) Direkter Name/Nickname
        m = guild.get_member_named(name)
        if m:
            return m
        for mem in guild.members:
            if mem.name == name or getattr(mem, "display_name", None) == name:
                return mem
        # 2) players.json Fallback
        data = load_json(PLAYERS_PATH, {})
        # exact match on 'ingame' or alias
        for sid, rec in data.items():
            try:
                ingame = (rec.get("ingame") or "").strip()
                aliases = [a.strip() for a in rec.get("aliases", []) if isinstance(a, str)]
                disc_names = [d.strip() for d in rec.get("discord_names", []) if isinstance(d, str)]
                if name.strip() in ([ingame] + aliases + disc_names):
                    mm = guild.get_member(int(sid))
                    if mm:
                        return mm
            except Exception:
                continue
        return None
    except Exception:
        return None
# ---------------- KO bracket & tips game ----------------
KO_BRACKET_PATH = os.path.join(SCRIPT_DIR, "ko_bracket.json")
TIPPSPIEL_PATH = os.path.join(SCRIPT_DIR, "tippspiel.json")
PLAYED_MAPS_KO_PATH = os.path.join(SCRIPT_DIR, "played_maps_ko.json")
BONUS_TIPS_PATH = os.path.join(SCRIPT_DIR, "bonus_tips.json")
KO_STAGES = ["R32", "R16", "QF", "SF", "F"]
def _ko_match_ids_for_stage(stage: str) -> List[str]:
    stage = (stage or "").upper()
    if stage == "R32":
        return [f"M{n:02d}" for n in range(1, 17)]
    if stage == "R16":
        return [f"M{n:02d}" for n in range(17, 25)]
    if stage == "QF":
        return [f"M{n:02d}" for n in range(25, 29)]
    if stage == "SF":
        return [f"M{n:02d}" for n in range(29, 31)]
    if stage == "F":
        return ["M31"]
    # Extra match (not part of the stage progression): 3rd place match
    if stage == "3P":
        return ["M32"]
    return []

def _ko_try_fill_third_place(data: Dict[str, Any]) -> bool:
    """If both semifinals have a winner, fill the 3rd-place match participants (losers).

    Returns True if the bracket was modified.
    """
    try:
        matches = data.get("matches") or {}
        m32 = matches.get("M32")
        m29 = matches.get("M29") or {}
        m30 = matches.get("M30") or {}
        if not isinstance(m32, dict):
            return False

        def _loser(m: Dict[str, Any]) -> Optional[str]:
            p1, p2 = m.get("p1"), m.get("p2")
            w = m.get("winner")
            if not (p1 and p2 and w):
                return None
            return p2 if str(w).strip() == str(p1).strip() else p1

        l1 = _loser(m29)
        l2 = _loser(m30)
        if not (l1 and l2):
            return False

        changed = False
        if m32.get("p1") != l1:
            m32["p1"] = l1
            changed = True
        if m32.get("p2") != l2:
            m32["p2"] = l2
            changed = True
        return changed
    except Exception:
        return False
def ko_new_bracket() -> Dict[str, Any]:
    matches: Dict[str, Any] = {}
    # create empty matches
    for st in KO_STAGES:
        for mid in _ko_match_ids_for_stage(st):
            matches[mid] = {"id": mid, "stage": st, "p1": None, "p2": None, "winner": None, "score": None, "next": None, "next_slot": None}

    # 3rd place match (extra, not part of KO_STAGES progression)
    for mid in _ko_match_ids_for_stage("3P"):
        matches[mid] = {"id": mid, "stage": "3P", "p1": None, "p2": None, "winner": None, "score": None, "next": None, "next_slot": None}
    # wiring winners (fixed tree)
    # R32 -> R16
    for i in range(1, 17, 2):
        a = f"M{i:02d}"
        b = f"M{i+1:02d}"
        tgt = f"M{16 + (i+1)//2:02d}"  # M17..M24
        matches[a]["next"] = tgt; matches[a]["next_slot"] = "p1"
        matches[b]["next"] = tgt; matches[b]["next_slot"] = "p2"
    # R16 -> QF (M17/18 -> M25, ...)
    for i in range(17, 25, 2):
        a = f"M{i:02d}"
        b = f"M{i+1:02d}"
        tgt = f"M{24 + (i-16+1)//2:02d}"  # M25..M28
        matches[a]["next"] = tgt; matches[a]["next_slot"] = "p1"
        matches[b]["next"] = tgt; matches[b]["next_slot"] = "p2"
    # QF -> SF (M25/26 -> M29, M27/28 -> M30)
    matches["M25"]["next"] = "M29"; matches["M25"]["next_slot"] = "p1"
    matches["M26"]["next"] = "M29"; matches["M26"]["next_slot"] = "p2"
    matches["M27"]["next"] = "M30"; matches["M27"]["next_slot"] = "p1"
    matches["M28"]["next"] = "M30"; matches["M28"]["next_slot"] = "p2"
    # SF -> F (M29/M30 -> M31)
    matches["M29"]["next"] = "M31"; matches["M29"]["next_slot"] = "p1"
    matches["M30"]["next"] = "M31"; matches["M30"]["next_slot"] = "p2"
    return {"current_stage": "R32", "matches": matches}
def ko_load_bracket() -> Dict[str, Any]:
    data = load_json(KO_BRACKET_PATH, None)
    if not isinstance(data, dict) or "matches" not in data:
        data = ko_new_bracket()
        save_json(KO_BRACKET_PATH, data)
        return data

    # Migration: ensure M32 (3rd place) exists.
    try:
        matches = data.get("matches") or {}
        if isinstance(matches, dict) and "M32" not in matches:
            matches["M32"] = {"id": "M32", "stage": "3P", "p1": None, "p2": None, "winner": None, "score": None, "next": None, "next_slot": None}
            data["matches"] = matches
            save_json(KO_BRACKET_PATH, data)
    except Exception:
        pass

    # If possible, keep 3rd place participants filled from semifinal losers.
    try:
        if _ko_try_fill_third_place(data):
            save_json(KO_BRACKET_PATH, data)
    except Exception:
        pass
    return data
def reset_for_ko_testing(keep_tipps_channels: bool = True) -> None:
    """Reset KO + tips + match state for clean end-to-end tests.
    - Clears: termine, unconfirmed, ergebnisse, match records
    - Resets: ko_bracket to fresh template, played maps, scored stages/tips (optionally keeping channel ids)
    - Does NOT wipe player database/roles.
    """
    cfg = load_config()
    # clear match state
    save_json(ERGEBNISSE_PATH, {})
    save_json(TERMINE_PATH, [])
    save_json(UNCONFIRMED_PATH, [])
    save_json(MATCHES_PATH, [])
    # KO
    try:
        save_json("ko_bracket.json", ko_new_bracket())
    except Exception:
        pass
    try:
        save_json("played_maps_ko.json", {})
    except Exception:
        pass
    # Tippspiel
    try:
        old = tippspiel_load()
        base = {
            "checked_in": [],
            "tips": {},
            "scores": {},
            "scored_stages": [],
        }
        if keep_tipps_channels:
            for k in ("channel_id", "scoreboard_channel_id", "anmeldung_channel_id", "leaderboard_message_id"):
                if old.get(k):
                    base[k] = old.get(k)
        tippspiel_save(base)
    except Exception:
        pass
def ko_save_bracket(data: Dict[str, Any]):
    save_json(KO_BRACKET_PATH, data)
def ko_current_stage() -> str:
    return str((ko_load_bracket().get("current_stage") or "R32")).upper()
def ko_set_current_stage(stage: str):
    data = ko_load_bracket()
    data["current_stage"] = str(stage).upper()
    ko_save_bracket(data)
def ko_import_round_of_32(lines: List[str]):
    data = ko_load_bracket()
    ids = _ko_match_ids_for_stage("R32")
    for idx, mid in enumerate(ids):
        p = lines[idx] if idx < len(lines) else None
        if not p:
            data["matches"][mid]["p1"] = None
            data["matches"][mid]["p2"] = None
            continue
        data["matches"][mid]["p1"] = p[0]
        data["matches"][mid]["p2"] = p[1]
        data["matches"][mid]["winner"] = None
        data["matches"][mid]["score"] = None
    data["current_stage"] = "R32"
    ko_save_bracket(data)
def ko_players_for_stage(stage: str) -> List[Dict[str, Any]]:
    data = ko_load_bracket()
    # keep M32 filled if possible
    try:
        if str(stage).upper() == "3P":
            if _ko_try_fill_third_place(data):
                ko_save_bracket(data)
    except Exception:
        pass
    out = []
    for mid in _ko_match_ids_for_stage(stage):
        m = data["matches"].get(mid) or {}
        out.append({"id": mid, "stage": m.get("stage") or str(stage).upper(), "p1": m.get("p1"), "p2": m.get("p2"), "winner": m.get("winner"), "score": m.get("score")})
    return out
def ko_stage_complete(stage: str) -> bool:
    data = ko_load_bracket()
    for mid in _ko_match_ids_for_stage(stage):
        m = data["matches"].get(mid) or {}
        if not m.get("winner"):
            return False
    return True
def ko_stage_from_group(group: str) -> Optional[str]:
    # group format: KO-<STAGE>-<MID>
    g = str(group or "")
    if not g.startswith("KO-"):
        return None
    parts = g.split("-")
    if len(parts) >= 3:
        return parts[1].upper()
    return None
def ko_match_id_from_group(group: str) -> Optional[str]:
    g = str(group or "")
    if not g.startswith("KO-"):
        return None
    parts = g.split("-")
    if len(parts) >= 3:
        return parts[2].split('|')[0].upper()
    return None
def ko_update_bracket_result(group: str, winner: str, score: str):
    data = ko_load_bracket()
    mid = ko_match_id_from_group(group)
    if not mid or mid not in data["matches"]:
        return
    data["matches"][mid]["winner"] = winner
    data["matches"][mid]["score"] = score
    # propagate
    nxt = data["matches"][mid].get("next")
    slot = data["matches"][mid].get("next_slot")
    if nxt and slot and nxt in data["matches"]:
        data["matches"][nxt][slot] = winner

    # If a semifinal got resolved, fill the 3rd place match with the losers.
    try:
        if mid in ("M29", "M30"):
            _ko_try_fill_third_place(data)
    except Exception:
        pass
    ko_save_bracket(data)
def ko_next_stage(stage: str) -> Optional[str]:
    st = str(stage).upper()
    if st not in KO_STAGES:
        return None
    i = KO_STAGES.index(st)
    return KO_STAGES[i+1] if i+1 < len(KO_STAGES) else None
# ---------------- KO series state (stored in matches.json record) ----------------
def ko_get_required_wins(group: str) -> int:
    # BO5 only for Final (stage F)
    stage = ko_stage_from_group(group) or ""
    return 3 if stage == "F" else 2
def ko_record_game_win(group: str, s1: str, s2: str, winner: str) -> Dict[str, Any]:
    rec = get_match_record(group, s1, s2) or {}
    wins = rec.get("ko_wins") or {s1: 0, s2: 0}
    # normalize keys
    if s1 not in wins: wins[s1] = 0
    if s2 not in wins: wins[s2] = 0
    if winner in wins:
        wins[winner] = int(wins.get(winner, 0) or 0) + 1
    rec["ko_wins"] = wins
    # store used civs container if missing
    rec.setdefault("ko_used_civs", {s1: [], s2: []})
    upsert_match_record(group, s1, s2, **rec)
    return get_match_record(group, s1, s2) or rec
def ko_get_series_score_str(rec: Dict[str, Any], s1: str, s2: str) -> str:
    wins = rec.get("ko_wins") or {}
    return f"{int(wins.get(s1,0) or 0)}:{int(wins.get(s2,0) or 0)}"
def ko_is_series_complete(rec: Dict[str, Any], s1: str, s2: str) -> bool:
    wins = rec.get("ko_wins") or {}
    g = rec.get("gruppe") or rec.get("group") or rec.get("ko_group") or ""
    need = ko_get_required_wins(str(g))
    return int(wins.get(s1, 0) or 0) >= need or int(wins.get(s2, 0) or 0) >= need
def tippspiel_load() -> Dict[str, Any]:
    """Loads tippspiel.json with sane defaults."""
    data = load_json(TIPPSPIEL_PATH, None)
    if not isinstance(data, dict):
        data = {}
    # defaults
    data.setdefault("channel_id", None)  # signup channel (legacy)
    # Tournament defaults (can still be overridden by /tipps_setup)
    data.setdefault("scoreboard_channel_id", "<DISCORD_LEGACY_SCOREBOARD_CHANNEL_ID>")
    data.setdefault("signup_channel_id", "<DISCORD_LEGACY_SIGNUP_CHANNEL_ID>")
    data.setdefault("leaderboard_message_id", None)
    data.setdefault("checked_in", [])
    data.setdefault("tips", {})  # {stage:{user_id:{match_id:{winner,score}}}}
    data.setdefault("scores", {})  # {user_id: total_points}
    data.setdefault("scored_stages", [])  # legacy stage-scoring
    data.setdefault("scored_matches", {})  # {match_id: true} to avoid double scoring
    data.setdefault("ko_locked_after_first_result", {})  # {KO-group: true} lock tips after first intermediate result
    data.setdefault("banned", [])  # [user_id]
    data.setdefault("tip_times", {})  # {stage:{user_id:{match_id:iso_ts}}}
    data.setdefault("adjustments", {})  # {user_id:int_delta}
    data.setdefault("adjust_log", {})  # {user_id:[{delta,reason,ts}]}
    data.setdefault("last_updated", None)
    save_json(TIPPSPIEL_PATH, data)
    return data
def tippspiel_save(data: Dict[str, Any]):
    save_json(TIPPSPIEL_PATH, data)
def tippspiel_checkin(user_id: int):
    data = tippspiel_load()
    arr = data.get("checked_in") or []
    if int(user_id) not in arr:
        arr.append(int(user_id))
    data["checked_in"] = arr
    tippspiel_save(data)
def tippspiel_ensure_user_visible(user_id: int):
    """Ensure a checked-in user appears on the leaderboard with 0 points."""
    data = tippspiel_load()
    scores = {str(k): int(v) for k, v in (data.get("scores") or {}).items()}
    uid = str(int(user_id))
    if uid not in scores:
        scores[uid] = 0
        data["scores"] = scores
        tippspiel_save(data)
def tippspiel_is_checked_in(user_id: int) -> bool:
    data = tippspiel_load()
    return int(user_id) in (data.get("checked_in") or [])
def tippspiel_store_tips(stage: str, user_id: int, tips: Dict[str, str]):
    data = tippspiel_load()
    stage = str(stage).upper()
    all_tips = data.get("tips") or {}
    stage_tips = all_tips.get(stage) or {}
    stage_tips[str(int(user_id))] = tips
    all_tips[stage] = stage_tips
    data["tips"] = all_tips
    tippspiel_save(data)
def _parse_score(s: str) -> Optional[tuple[int,int]]:
    s = (s or "").strip()
    s = s.replace("-", ":")
    if ":" not in s:
        return None
    a,b = s.split(":",1)
    try:
        return int(a.strip()), int(b.strip())
    except Exception:
        return None
def _tipps_points_for_match(match_id: str) -> tuple[int, int]:
    """Return (exact_points, tendency_points) for a KO match.

    Rules:
    - Finale (M31): exact 5, tendency 2
    - Spiel um Platz 3 (M32): exact 3, tendency 2
    - Default (all other matches): exact 3, tendency 2
    """
    mid = str(match_id or "").upper()
    if mid == "M31":
        return 5, 2
    if mid == "M32":
        return 3, 2
    return 3, 2

def tippspiel_score_stage(stage: str) -> Dict[str, int]:
    """Scores a stage based on ko_bracket.json. Returns updated total scores."""
    stage = str(stage).upper()
    bracket = ko_load_bracket()
    actual = {}
    for mid in _ko_match_ids_for_stage(stage):
        m = bracket["matches"].get(mid) or {}
        if not m.get("winner") or not m.get("score"):
            return {}  # not ready
        actual[mid] = {"winner": m.get("winner"), "score": m.get("score")}
    data = tippspiel_load()

    # IMPORTANT:
    # The bot supports two scoring paths:
    #   (A) per-match incremental scoring via tippspiel_apply_match_result()
    #   (B) whole-stage scoring via this function
    # If both run for the same matches, everyone gets points twice.
    # Therefore this function must be idempotent PER MATCH as well.
    scored_matches = data.get("scored_matches") or {}

    if stage in (data.get("scored_stages") or []):
        return {str(k): int(v) for k, v in (data.get("scores") or {}).items()}

    scores = {str(k): int(v) for k, v in (data.get("scores") or {}).items()}
    stage_tips = ((data.get("tips") or {}).get(stage) or {})
    for uid, user_tips in stage_tips.items():
        pts = 0
        for mid, act in actual.items():
            # Skip matches already scored via incremental scoring.
            if scored_matches.get(mid):
                continue
            pred = (user_tips or {}).get(mid)
            if not pred:
                continue
            if isinstance(pred, dict):
                pred = pred.get("score")
            pred_pair = _parse_score(str(pred) if pred is not None else "")
            # act["score"] is stored as "max:min" (winner perspective). Convert to p1-perspective.
            act_score = str(act["score"]).replace("-", ":")
            p1n = str(bracket["matches"][mid].get("p1") or "")
            if str(act.get("winner")) != p1n:
                try:
                    a,b = act_score.split(":", 1)
                    act_score = f"{b}:{a}"
                except Exception:
                    pass
            act_pair = _parse_score(act_score)
            if not pred_pair or not act_pair:
                continue
            # determine predicted winner
            pw = act["winner"]  # default
            if pred_pair[0] > pred_pair[1]:
                pw = (bracket["matches"][mid].get("p1") or "")
            elif pred_pair[1] > pred_pair[0]:
                pw = (bracket["matches"][mid].get("p2") or "")
            else:
                pw = ""
            # actual winner is act["winner"]
            exact_pts, tendency_pts = _tipps_points_for_match(mid)
            if pred_pair == act_pair:
                pts += exact_pts
            else:
                if pw and pw == act["winner"]:
                    pts += tendency_pts
        scores[uid] = int(scores.get(uid, 0) or 0) + pts

    # Mark all matches in this stage as scored so later incremental scoring cannot double-award.
    for mid in actual.keys():
        scored_matches[mid] = True

    data["scores"] = scores
    data["scored_matches"] = scored_matches
    scored = data.get("scored_stages") or []
    scored.append(stage)
    data["scored_stages"] = scored
    tippspiel_save(data)
    return scores
def tippspiel_apply_match_result(match_id: str, actual_winner: str, actual_score: str) -> Dict[str, int]:
    """Incrementally scores ONE match result for all checked-in users who have a tip for it.
    - Match-specific points (e.g. Finale exact=5/tendency=2; default exact=3/tendency=2)
    - 0 otherwise
    This is idempotent per match_id via tippspiel.json['scored_matches'].
    Returns updated total scores.
    """
    match_id = str(match_id).upper()
    data = tippspiel_load()
    scored_matches = data.get("scored_matches") or {}
    if scored_matches.get(match_id):
        return {str(k): int(v) for k, v in (data.get("scores") or {}).items()}
    scores = {str(k): int(v) for k, v in (data.get("scores") or {}).items()}
    tips = data.get("tips") or {}
    # Normalize actual score to the perspective of p1 for "exact score" comparisons.
    # In KO we store final_score as "max:min" (winner perspective), so we need bracket info.
    bracket = load_json(KO_BRACKET_PATH, {})
    bm = ((bracket.get("matches") or {}).get(match_id) or {})
    p1_name = str(bm.get("p1") or "")
    p2_name = str(bm.get("p2") or "")
    def _invert(sc: str) -> str:
        try:
            a, b = str(sc).replace("-", ":").split(":", 1)
            return f"{b}:{a}"
        except Exception:
            return str(sc)
    actual_score = str(actual_score).replace("-", ":")
    actual_score_p1 = actual_score if str(actual_winner) == p1_name else _invert(actual_score)
    # find predictions for this match across stages
    for stage, stage_tips in tips.items():
        if not isinstance(stage_tips, dict):
            continue
        for uid, user_tips in stage_tips.items():
            if not isinstance(user_tips, dict):
                continue
            pred = user_tips.get(match_id)
            # UI stores either:
            # - string score in p1-perspective ("2:0", "2:1", "0:2", "1:2")
            # - or a dict {winner, score} (legacy)
            pw = None
            ps = None
            if isinstance(pred, dict):
                # current format: {"score": "2:1", "ts": "..."}
                # legacy format:  {"winner": "Name", "score": "2:1"}
                pw = pred.get("winner")
                ps = pred.get("score")
                if pw is None and ps:
                    try:
                        a, b = str(ps).replace("-", ":").split(":", 1)
                        ai = int(a); bi = int(b)
                        if ai > bi:
                            pw = p1_name
                        elif bi > ai:
                            pw = p2_name
                    except Exception:
                        pass
            elif isinstance(pred, str):
                ps = pred.replace("-", ":")
                # derive predicted winner from p1-perspective score
                try:
                    a, b = ps.split(":", 1)
                    ai = int(a); bi = int(b)
                    if ai > bi:
                        pw = p1_name
                    elif bi > ai:
                        pw = p2_name
                except Exception:
                    pw = None
            exact_pts, tendency_pts = _tipps_points_for_match(match_id)
            add = 0
            if ps and str(ps).replace("-", ":") == str(actual_score_p1) and pw and str(pw) == str(actual_winner):
                add = exact_pts
            elif pw and str(pw) == str(actual_winner):
                add = tendency_pts
            if add:
                scores[str(uid)] = int(scores.get(str(uid), 0) or 0) + add
    scored_matches[match_id] = True
    data["scores"] = scores
    data["scored_matches"] = scored_matches
    tippspiel_save(data)
    return scores
def tippspiel_leaderboard() -> List[tuple[int,int]]:
    data = tippspiel_load()
    scores = {int(k): int(v) for k,v in (data.get("scores") or {}).items()}
    # show checked-in users even if they have 0 points yet
    for uid in (data.get("checked_in") or []):
        try:
            scores.setdefault(int(uid), 0)
        except Exception:
            pass
    return sorted(scores.items(), key=lambda kv: (kv[1], -kv[0]), reverse=True)
async def tippspiel_score_stage_if_ready(bot, guild: Any, stage: str):
    """Called when a KO-stage completes: scores the stage (once) and updates the permanent leaderboard message."""
    scores = tippspiel_score_stage(stage)
    if not scores:
        return
    data = tippspiel_load()
    # permanent leaderboard lives in scoreboard_channel_id (fallback: channel_id)
    if not data.get("scoreboard_channel_id"):
        data["scoreboard_channel_id"] = data.get("channel_id") or load_config().get("tippspiel_channel_id")
        tippspiel_save(data)
    try:
        await tippspiel_update_leaderboard_message(bot, guild)
    except Exception:
        pass
def remove_earliest_confirmed_termin(group: str, s1: str, s2: str) -> bool:
    """
    KO: Consumes exactly ONE "game slot" from the earliest confirmed termin.
    - Each confirmed termin can optionally cover multiple games (cover_games: 1..3) via "+1/+2" append feature.
    - We track used_games. Only when used_games reaches cover_games the termin is removed.
    Returns True if a termin record was modified (consumed) or removed.
    """
    arr = load_json(TERMINE_PATH, [])
    # candidates for this pair
    cand = [t for t in arr if _same_pair(group, s1, s2, t)]
    if not cand:
        return False
    # pick earliest by datetime
    best = None
    best_dt = None
    for t in cand:
        dt = _parse_dt(str(t.get("datum","")), str(t.get("uhrzeit","")))
        if not dt:
            continue
        if best_dt is None or dt < best_dt:
            best_dt = dt
            best = t
    if best is None:
        best = cand[0]
    cover = int(best.get("cover_games", 1) or 1)
    used = int(best.get("used_games", 0) or 0)
    # consume one slot
    used += 1
    if used < cover:
        best["used_games"] = used
        save_json(TERMINE_PATH, arr)
        # lock tipps for this KO match after first intermediate result is locked
        try:
            if str(group).upper().startswith("KO-"):
                td = tippspiel_load()
                locks = td.get("ko_locked_after_first_result") or {}
                g = str(group).upper()
                a = str(s1).strip().lower()
                b = str(s2).strip().lower()
                if a > b:
                    a, b = b, a
                locks[f"{g}::{a}::{b}"] = True
                td["ko_locked_after_first_result"] = locks
                save_json(TIPPSPIEL_PATH, td)
        except Exception:
            pass
        return True
    # used >= cover => remove termin
    # lock tipps for this KO match after first intermediate result is locked
    try:
        if str(group).upper().startswith("KO-"):
            td = tippspiel_load()
            locks = td.get("ko_locked_after_first_result") or {}
            g = str(group).upper()
            a = str(s1).strip().lower()
            b = str(s2).strip().lower()
            if a > b:
                a, b = b, a
            locks[f"{g}::{a}::{b}"] = True
            td["ko_locked_after_first_result"] = locks
            save_json(TIPPSPIEL_PATH, td)
    except Exception:
        pass
    return remove_confirmed_termin(group, s1, s2, best.get("datum",""), best.get("uhrzeit",""))

def tippspiel_render_leaderboard_embed(limit: int | None = None):
    """Returns a bilingual leaderboard embed."""
    import discord as _d
    lb = tippspiel_leaderboard()
    lines = []
    data = tippspiel_load()
    adj = {str(k): int(v) for k, v in (data.get("adjustments") or {}).items()}
    for i, (uid, pts) in enumerate((lb if limit is None else (lb if limit is None else lb[:limit])), start=1):
        d = int(adj.get(str(uid), 0) or 0)
        delta_txt = f" ({d:+d})" if d else ""
        lines.append(f"{i}. <@{uid}> — **{pts}**{delta_txt}")
    desc = "\n".join(lines) if lines else "_(no tips yet / noch keine Tipps)_"
    e = _d.Embed(
        title="🏆 Tippspiel Leaderboard / Prediction Game Leaderboard",
        description=desc,
        color=_d.Color.gold()
    )
    e.set_footer(text="Auto-updated / Wird automatisch aktualisiert")
    return e
async def tippspiel_update_leaderboard_message(bot, guild):
    """Edits the permanent leaderboard message in the scoreboard channel (if configured)."""
    import discord as _d
    data = tippspiel_load()
    ch_id = data.get("scoreboard_channel_id") or data.get("channel_id") or load_config().get("tippspiel_channel_id")
    msg_id = data.get("leaderboard_message_id")
    if not ch_id:
        return
    ch = guild.get_channel(int(ch_id))
    if ch is None:
        try:
            ch = await guild.fetch_channel(int(ch_id))
        except Exception:
            ch = None
    if not ch or not hasattr(ch, "fetch_message"):
        return
    embed = tippspiel_render_leaderboard_embed()
    try:
        if msg_id:
            try:
                msg = await ch.fetch_message(int(msg_id))
                await msg.edit(embed=embed, view=None)
                return
            except Exception:
                pass
        # create new permanent message
        msg = await ch.send(embed=embed)
        data["leaderboard_message_id"] = int(msg.id)
        # best-effort pin
        try:
            await msg.pin(reason="Tippspiel Leaderboard")
        except Exception:
            pass
        tippspiel_save(data)
    except Exception:
        return
# ---------------- Bonus questions (Sondertipps) ----------------
def bonus_load() -> Dict[str, Any]:
    data = load_json(BONUS_TIPS_PATH, None)
    if not isinstance(data, dict):
        data = {}
    # Channels
    data.setdefault("channel_id", "<DISCORD_BONUS_PUBLIC_CHANNEL_ID>")  # public bonus channel (players)
    data.setdefault("orga_channel_id", "<DISCORD_BONUS_ORGA_CHANNEL_ID_LEGACY>")  # orga-only management channel
    data.setdefault("tendencies_channel_id", "<DISCORD_BONUS_TENDENCIES_CHANNEL_ID_LEGACY>")
    # Questions (merge defaults into existing file content)
    default_qs = {
        "Q1": {
            "text_de": "Wer wird der neue Weltmeister?",
            "text_en": "Who will become the new world champion?",
            "points": 5,
        },
        "Q2": {
            "text_de": "Wer stellt den PT Rekord auf?",
            "text_en": "Who will set the PT record?",
            "points": 5,
        },
        "Q3": {
            "text_de": "Wie hoch wird der PT Rekord ausfallen? (Gemessen wird bei 1:00:04, gezählt werden Startsoldaten + T3. Produzierte T2 und T1 Soldaten gehen mit Faktor 0,5 bzw. 0,33 in die Berechnung.)",
            "text_en": "How high will the PT record be? (Measured at 1:00:04; counted: starting soldiers + T3. Produced T2 and T1 soldiers count with factors 0.5 and 0.33 respectively.)",
            "points": 5,
        },
        "Q4": {
            "text_de": "Wie lange wird das längste Spiel gehen? (Format: HH:MM:SS)",
            "text_en": "How long will the longest game be?",
            "points": 5,
        },
    }
    qs = data.get("questions")
    if not isinstance(qs, dict):
        qs = {}
    # Normalize keys and merge
    norm = {}
    for k, v in qs.items():
        if not isinstance(v, dict):
            continue
        norm[str(k).upper()] = v
    for qid, q in default_qs.items():
        norm.setdefault(qid, q)
        # ensure fields exist
        norm[qid].setdefault("text_de", q.get("text_de"))
        norm[qid].setdefault("text_en", q.get("text_en"))
        norm[qid].setdefault("points", q.get("points", 5))
    data["questions"] = norm
    # Deadline and stored data
    data.setdefault("deadline_iso", "2026-01-07T22:59:00+00:00")  # 23:59 Europe/Berlin in UTC
    data.setdefault("tips", {})        # {qid:{user_id:{answer,ts}}}
    data.setdefault("correct", {})     # {qid: answer_string}
    data.setdefault("awarded", {})     # {qid:true} once points applied
    # Overlay message ids
    data.setdefault("overlay_message_id", None)        # public channel message id
    data.setdefault("orga_overlay_message_id", None)   # orga channel message id
    # Persist upgraded file
    save_json(BONUS_TIPS_PATH, data)
    return data
def bonus_save(data: Dict[str, Any]):
    save_json(BONUS_TIPS_PATH, data)
def bonus_deadline_passed() -> bool:
    data = bonus_load()
    try:
        dl = datetime.datetime.fromisoformat(str(data.get("deadline_iso")))
        return datetime.datetime.now(datetime.timezone.utc) > dl
    except Exception:
        return False
def bonus_submit_tip(qid: str, user_id: int, answer: str) -> bool:
    """Store/overwrite a user's answer (until deadline).
    Returns True if accepted, False if deadline passed.
    """
    data = bonus_load()
    if bonus_deadline_passed():
        return False
    qid = str(qid).upper()
    tips = data.get("tips") or {}
    qt = tips.get(qid) or {}
    uid = str(int(user_id))
    # allow overwriting/changing the answer until the deadline
    qt[uid] = {"answer": str(answer).strip(), "ts": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    tips[qid] = qt
    data["tips"] = tips
    bonus_save(data)
    return True
def bonus_set_correct(qid: str, correct_answer: str):
    data = bonus_load()
    cor = data.get("correct") or {}
    cor[str(qid).upper()] = str(correct_answer).strip()
    data["correct"] = cor
    bonus_save(data)
def tippspiel_apply_adjustment(user_id: int, delta: int, reason: str = ""):
    data = tippspiel_load()
    uid = str(int(user_id))
    adj = {str(k): int(v) for k, v in (data.get("adjustments") or {}).items()}
    adj[uid] = int(adj.get(uid, 0) or 0) + int(delta)
    data["adjustments"] = adj
    # apply to total scores as well
    scores = {str(k): int(v) for k, v in (data.get("scores") or {}).items()}
    scores[uid] = int(scores.get(uid, 0) or 0) + int(delta)
    data["scores"] = scores
    log = data.get("adjust_log") or {}
    arr = log.get(uid) or []
    arr.append({"delta": int(delta), "reason": str(reason or ""), "ts": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    log[uid] = arr
    data["adjust_log"] = log
    tippspiel_save(data)
def bonus_reset(all_data: bool = False) -> None:
    """Reset stored bonus tips.

    - Always clears submitted tips.
    - If all_data=True, also clears correct answers + awarded flags and overlay message ids.
      Channel ids and question texts are kept.
    """
    b = bonus_load()
    b["tips"] = {}
    if all_data:
        b["correct"] = {}
        b["awarded"] = {}
        b["overlay_message_id"] = None
        b["orga_overlay_message_id"] = None
    bonus_save(b)

def _bonus_parse_number(s: str) -> int | None:
    try:
        s = str(s).strip().replace(".", "").replace(" ", "")
        # allow 1,234 and 1234 and 1.234
        s = s.replace(",", "")
        return int(s)
    except Exception:
        return None

def _bonus_parse_hms(s: str) -> int | None:
    try:
        s = str(s).strip()
        parts = s.split(":")
        if len(parts) != 3:
            return None
        h, m, sec = [int(x) for x in parts]
        if h < 0 or m < 0 or sec < 0 or m >= 60 or sec >= 60:
            return None
        return h * 3600 + m * 60 + sec
    except Exception:
        return None

def bonus_apply_points_to_correct() -> dict:
    """Award bonus points based on correct answers (idempotent per question).

    Rules:
    - Q1/Q2: case-insensitive exact match -> all matching users get points.
    - Q3: numeric (PT record) -> closest to correct value gets points (ties share).
    - Q4: duration in format HH:MM:SS -> closest to correct value gets points (ties share).

    Returns a report dict for UI display.
    """
    b = bonus_load()
    cor = b.get("correct") or {}
    awarded = b.get("awarded") or {}
    tips = b.get("tips") or {}
    qs = b.get("questions") or {}

    report: dict = {"questions": {}, "skipped": []}

    for qid, ans in cor.items():
        qid = str(qid).upper()
        if awarded.get(qid):
            report["skipped"].append(qid)
            continue

        q = qs.get(qid) or {}
        pts = int(q.get("points") or 5)
        qt = tips.get(qid) or {}

        winners: list[str] = []
        detail: str = ""

        # Q3/Q4: closest
        if qid in ("Q3", "Q4"):
            target = _bonus_parse_number(ans) if qid == "Q3" else _bonus_parse_hms(ans)
            if target is None:
                report["questions"][qid] = {"awarded": False, "reason": "Correct answer is not parseable.", "winners": []}
                awarded[qid] = True
                continue

            parsed = []
            for uid, obj in qt.items():
                raw = str((obj or {}).get("answer", "")).strip()
                val = _bonus_parse_number(raw) if qid == "Q3" else _bonus_parse_hms(raw)
                if val is None:
                    continue
                parsed.append((uid, raw, val, abs(val - target)))

            if not parsed:
                report["questions"][qid] = {"awarded": False, "reason": "No valid answers.", "winners": []}
                awarded[qid] = True
                continue

            parsed.sort(key=lambda t: (t[3], t[0]))
            best_diff = parsed[0][3]
            best = [t for t in parsed if t[3] == best_diff]
            winners = [uid for uid, _raw, _val, _d in best]
            if qid == "Q3":
                detail = f"Closest to {target} (diff {best_diff})."
            else:
                detail = f"Closest to {ans.strip()} (diff {best_diff}s)."

            for uid in winners:
                tippspiel_apply_adjustment(int(uid), pts, reason=f"Bonus {qid}")
        else:
            # Q1/Q2: exact case-insensitive match
            corr = str(ans).strip().lower()
            for uid, obj in qt.items():
                if str((obj or {}).get("answer", "")).strip().lower() == corr:
                    winners.append(str(uid))
                    tippspiel_apply_adjustment(int(uid), pts, reason=f"Bonus {qid}")
            detail = f"Exact (case-insensitive) match: {ans.strip()}."

        report["questions"][qid] = {"awarded": True, "points": pts, "reason": detail, "winners": winners}
        awarded[qid] = True

    b["awarded"] = awarded
    bonus_save(b)
    return report
def bonus_render_overlay_embed() -> Any:
    import discord as _d
    b = bonus_load()
    qs = b.get("questions") or {}
    tips = b.get("tips") or {}
    cor = b.get("correct") or {}
    dl = b.get("deadline_iso")
    lines = []
    for qid, q in qs.items():
        cnt = len((tips.get(qid) or {}).keys())
        corr = cor.get(qid)
        ctxt = f"✅ Correct: **{corr}**" if corr else "⏳ Correct: _(unset)_"
        lines.append(f"**{qid}** — {q.get('text_de')} / {q.get('text_en')}\nTips: **{cnt}**\n{ctxt}")
    e = _d.Embed(
        title="🧩 Bonusfragen / Bonus Questions (Orga)",
        description="\n\n".join(lines) if lines else "_(no questions)_",
        color=_d.Color.blurple(),
    )
    e.set_footer(text=f"Deadline (UTC): {dl} | Set correct answers here, then apply points.")
    return e

def bonus_render_public_overlay_embed() -> Any:
    import discord as _d
    b = bonus_load()
    qs = b.get("questions") or {}
    dl = b.get("deadline_iso")
    lines = []
    for qid, q in qs.items():
        lines.append(f"**{qid}** — {q.get('text_de')} / {q.get('text_en')}")
    desc = "\n".join(lines) if lines else "_(no questions)_"
    e = _d.Embed(
        title="🎯 Bonusfragen / Bonus questions",
        description=desc + f"\n\n🕒 Deadline (UTC): `{dl}`\nAntworten/ändern über den Button unten.",
        color=_d.Color.blurple(),
    )
    return e

def bonus_render_public_tendencies(qid: str) -> str:
    b = bonus_load()
    qid = str(qid).upper()
    tips = (b.get('tips') or {}).get(qid) or {}
    total = len(tips)
    counts = {}
    for obj in tips.values():
        a = str(obj.get('answer', '')).strip()
        if not a:
            continue
        counts[a] = counts.get(a, 0) + 1
    items = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].lower()))
    q = (b.get('questions') or {}).get(qid) or {}
    header = f"{q.get('text_de')} / {q.get('text_en')} — {total} Tipper"
    lines = [header]
    for a, c in items:
        pct = (c / total * 100.0) if total else 0.0
        lines.append(f"- **{a}** — {c} ({pct:.1f}%)")
    return "\n".join(lines) if lines else header

# ---------------- Völkerstatistik (per-game) ----------------


def civstats_load() -> Dict[str, Any]:
    data = load_json(CIV_STATS_PATH, None)
    if not isinstance(data, dict):
        data={}
    data.setdefault("channel_id", "<DISCORD_CIVSTATS_CHANNEL_ID_LEGACY>")
    data.setdefault("message_id", None)
    data.setdefault("civs", {})  # {civ:{picked:int,wins:int}}
    return data
def civstats_save(data: Dict[str, Any]):
    save_json(CIV_STATS_PATH, data)
def civstats_apply_game(picks: Dict[str,str], winner: str):
    data = civstats_load()
    civs = data.get("civs") or {}
    for player, civ in (picks or {}).items():
        civ=str(civ)
        if not civ:
            continue
        ent=civs.get(civ) or {"picked":0, "wins":0}
        ent["picked"] = int(ent.get("picked",0) or 0) + 1
        if str(player) == str(winner):
            ent["wins"] = int(ent.get("wins",0) or 0) + 1
        civs[civ]=ent
    data["civs"] = civs
    civstats_save(data)
def civstats_render_embed() -> Any:
    import discord as _d
    data=civstats_load()
    civs=data.get("civs") or {}
    items=[]
    for civ, ent in civs.items():
        p=int(ent.get("picked",0) or 0)
        w=int(ent.get("wins",0) or 0)
        wr=(w/p*100.0) if p else 0.0
        items.append((p, wr, civ, w))
    items.sort(key=lambda t: (-t[0], -t[1], t[2].lower()))
    lines=[]
    for p, wr, civ, w in items:
        lines.append(f"**{civ}** — Picks: **{p}** | Wins: **{w}** | Winrate: **{wr:.1f}%**")
    desc="\n".join(lines) if lines else "_(no games yet / noch keine Games)_"
    e=_d.Embed(title="🛡️ Völker-Stats (per Game) / Civ stats (per game)", description=desc, color=_d.Color.dark_teal())
    e.set_footer(text="Counted per single game (not per series). / Pro einzelnes Spiel gezählt.")
    return e
async def civstats_update_message(bot, guild):
    import discord as _d
    data=civstats_load()
    cid=int(data.get("channel_id") or 0)
    if not cid:
        return
    ch = guild.get_channel(cid)
    if ch is None:
        try:
            ch = await guild.fetch_channel(cid)
        except Exception:
            return
    mid=data.get("message_id")
    embed=civstats_render_embed()
    if mid:
        try:
            msg=await ch.fetch_message(int(mid))
            await msg.edit(embed=embed)
            return
        except Exception:
            mid=None
    try:
        msg=await ch.send(embed=embed)
        data["message_id"] = int(msg.id)
        civstats_save(data)
    except Exception:
        pass

def tippspiel_recalc_all():
    """
    Recalculate all Tippspiel scores from current KO results.

    Scoring:
      - Match-spezifisch (z.B. Finale exact=5/Tendenz=2, sonst exact=3/Tendenz=2)

    Important:
      - KO-Bracket speichert "score" in WINNER-Perspektive (z.B. 2:0 für Sieger),
        Tipps sind in P1-Perspektive (erste Zahl gehört zu p1). Daher konvertieren wir
        Resultate in P1-Perspektive, bevor verglichen wird.
      - Manuelle Adjustments (data["adjustments"]) werden nach dem Recalc addiert.
    """
    data = tippspiel_load()

    # -------- collect match results (P1 perspective) --------
    results: dict[str, dict[str, str]] = {}

    root = os.path.dirname(__file__)
    bracket_path = os.path.join(root, "ko_bracket.json")
    if os.path.exists(bracket_path):
        try:
            with open(bracket_path, "r", encoding="utf-8") as f:
                bracket = json.load(f)

            matches = bracket.get("matches") if isinstance(bracket, dict) else None

            # matches can be: dict(mid -> matchdict) OR list[matchdict]
            if isinstance(matches, dict):
                items = list(matches.items())
            elif isinstance(matches, list):
                items = [(m.get("id") or m.get("mid") or m.get("match_id"), m) for m in matches if isinstance(m, dict)]
            else:
                items = []

            for mid, m in items:
                if not mid or not isinstance(m, dict):
                    continue
                score = m.get("score") or m.get("result")
                winner = m.get("winner")
                p1 = m.get("p1")
                if not score:
                    continue

                # normalize score format
                s = str(score).strip().replace("-", ":")
                # convert winner-perspective -> p1-perspective (swap if winner != p1)
                if p1 and str(winner) != str(p1):
                    try:
                        a, b = s.split(":", 1)
                        s = f"{b}:{a}"
                    except Exception:
                        pass

                results[str(mid)] = {"score": s, "winner": str(winner)}
        except Exception:
            results = {}

    # fallback: ergebnisse.json (if present) – expected to already be in p1-perspective
    if not results:
        try:
            er_path = os.path.join(root, "ergebnisse.json")
            if os.path.exists(er_path):
                with open(er_path, "r", encoding="utf-8") as f:
                    er = json.load(f)
                if isinstance(er, dict):
                    for mid, obj in er.items():
                        if isinstance(obj, dict) and obj.get("score"):
                            results[str(mid)] = {"score": str(obj.get("score")).replace("-", ":"), "winner": str(obj.get("winner") or "")}
        except Exception:
            pass

    # -------- flatten tips across stages --------
    tips = data.get("tips", {})
    all_tips: dict[str, dict[str, object]] = {}
    if isinstance(tips, dict):
        for _stage, stage_tips in tips.items():
            if isinstance(stage_tips, dict):
                for uid, usertips in stage_tips.items():
                    all_tips.setdefault(str(uid), {}).update(usertips or {})

    def _parse(s: object):
        try:
            s = str(s).strip().replace("-", ":")
            a, b = s.split(":", 1)
            return int(a), int(b)
        except Exception:
            return None

    # -------- compute base scores --------
    scores: dict[str, int] = {}
    for uid, usertips in all_tips.items():
        total = 0
        for mid, tipobj in (usertips or {}).items():
            tscore = tipobj.get("score") if isinstance(tipobj, dict) else tipobj
            r = results.get(str(mid))
            if not r:
                continue

            ps = _parse(tscore)
            rs = _parse(r.get("score"))
            if not ps or not rs:
                continue

            exact_pts, tendency_pts = _tipps_points_for_match(str(mid))
            if ps == rs:
                total += exact_pts
            else:
                # tendency: same winner/draw
                pwin = 0 if ps[0] == ps[1] else (1 if ps[0] > ps[1] else 2)
                rwin = 0 if rs[0] == rs[1] else (1 if rs[0] > rs[1] else 2)
                if pwin == rwin:
                    total += tendency_pts

        scores[str(uid)] = int(total)

    # ensure checked-in users exist in scores, even if they haven't tipped (=> 0)
    for uid in (data.get("checked_in") or []):
        suid = str(uid)
        scores.setdefault(suid, 0)

    # -------- apply manual adjustments --------
    adj = {str(k): int(v) for k, v in (data.get("adjustments") or {}).items()}
    for uid, delta in adj.items():
        scores[uid] = int(scores.get(uid, 0) or 0) + int(delta)

    # -------- sync scored markers (avoid double scoring after recalc) --------
    try:
        # scores now reflect all matches that currently have a result in ko_bracket.
        # Mark those matches as scored, so incremental scoring cannot add them again.
        sm = data.get("scored_matches")
        if not isinstance(sm, dict):
            sm = {}
        for mid in results.keys():
            sm[str(mid).upper()] = True
        data["scored_matches"] = sm

        # Also mark fully completed stages (legacy stage-scoring) to avoid any re-scoring.
        ss = data.get("scored_stages")
        if not isinstance(ss, list):
            ss = []
        seen = {str(s).upper() for s in ss if isinstance(s, str)}
        completed = set(sm.keys())
        for st in KO_STAGES:
            mids = set(_ko_match_ids_for_stage(st))
            if mids and mids.issubset(completed):
                seen.add(st)
        # keep deterministic order
        ordered = [st for st in KO_STAGES if st in seen]
        # keep any unknown stages too
        ordered += sorted([st for st in seen if st not in KO_STAGES])
        data["scored_stages"] = ordered
    except Exception:
        pass

    data["scores"] = scores
    tippspiel_save(data)
    return data