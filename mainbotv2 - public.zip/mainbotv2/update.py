import discord
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Dict, List
from utils import load_json, load_config, MATCHES_PATH, STREAMERS_PATH, TERMINE_PATH, upsert_match_record, streamer_get, pair_has_unconfirmed, pair_has_confirmed, match_closed_persisted, next_confirmed_for_pair, swiss_get_all_pairs, ko_stage_from_group
from embeds import embed_group_table, embed_termin_list, embed_match_overview

config = load_config()

# Stream capacity
STREAM_SLOTS_PER_STREAMER = 2
MAX_STREAMERS = 3  # total = 6 slots


# ---- Guard: ensure _streamer_links exists (hotfix) ----
if '_streamer_links' not in globals():
    def _streamer_links(guild: discord.Guild, group: str, s1: str, s2: str) -> str:
        try:
            recs = load_json(MATCHES_PATH, [])
            rec = next((m for m in recs if m.get("gruppe")==group and {m.get("spieler1"), m.get("spieler2")}=={s1, s2}), None)
            ids = list(map(int, rec.get("stream_signups", []))) if rec else []
            if not ids:
                return ""
            parts = []
            # Show all registered streamers up to MAX_STREAMERS.
            for sid in ids[:MAX_STREAMERS]:
                prof = streamer_get(sid) or {}
                member = guild.get_member(sid)
                name = prof.get("name") or (getattr(member, "display_name", None) or str(sid))
                link = prof.get("link")
                parts.append(f" — [{name}]({link})" if link else f" — {name}")
            return "".join(parts)
        except Exception:
            return ""


def _parse_dt(datum: str, uhrzeit: str):
    try:
        dd, mm, yy = map(int, datum.split("."))
        hh, mi = map(int, uhrzeit.split(":"))
        return datetime(yy, mm, dd, hh, mi, tzinfo=ZoneInfo("Europe/Berlin"))
    except Exception:
        return None

async def update_scoreboard_channel(guild: discord.Guild, gruppen: Dict[str, List[str]], scoreboard_channel_id: int):
    channel = guild.get_channel(scoreboard_channel_id)
    if not isinstance(channel, discord.TextChannel):
        return
    try:
        await channel.purge(check=lambda m: m.author == guild.me)
    except Exception:
        pass

    # Ergebnisse nach Spieler aufsummieren
    results = load_json("ergebnisse.json", {})
    wins_by_player = {}
    for key, val in (results or {}).items():
        try:
            winner = (val or {}).get("winner")
            if not winner:
                continue
            wins_by_player[winner] = wins_by_player.get(winner, 0) + 1
        except Exception:
            continue

    # Für jede Gruppe Tabelle senden (sortiert: Siege desc, dann Name)
    for group, players in (gruppen or {}).items():
        sieges = {p: int(wins_by_player.get(p, 0) or 0) for p in players}
        players_sorted = sorted(players, key=lambda p: (-sieges.get(p, 0), p.lower()))
        await channel.send(embed=embed_group_table(group, players_sorted, sieges))


async def update_termin_channel(guild: discord.Guild, termine_channel_id: int):
    channel = guild.get_channel(termine_channel_id)
    if channel is None:
        try:
            channel = await guild.fetch_channel(termine_channel_id)
        except Exception:
            channel = None
    if not isinstance(channel, discord.TextChannel):
        return
    from utils import apps_state_get, apps_state_set

    state = apps_state_get()
    key = "termine_message_id"
    msg = None
    try:
        mid = int(state.get(key, 0))
        if mid:
            msg = await channel.fetch_message(mid)
    except Exception:
        msg = None

    termine = load_json(TERMINE_PATH, [])
    # sort nach Datum/Zeit
    from datetime import datetime
    def _parse_dt(d, t):
        try:
            return datetime.strptime(f"{d} {t}", "%d.%m.%Y %H:%M")
        except Exception:
            return None
    termine = sorted(termine, key=lambda x: _parse_dt(x.get("datum",""), x.get("uhrzeit","")) or datetime.max)

    lines = []
    for t in termine:
        stage = ko_stage_from_group(t.get('gruppe','')) if str(t.get('gruppe','')).startswith('KO-') else None
        stage_label = ''
        if stage:
            stage_map = {
                'R32': 'Round of 32 / Sechzehntelfinale',
                'R16': 'Round of 16 / Achtelfinale',
                'QF': 'Quarterfinals / Viertelfinale',
                'SF': 'Semifinals / Halbfinale',
                'F': 'Final / Finale',
            }
            stage_label = stage_map.get(stage, stage)
        cover = int(t.get('cover_games', 1) or 1)
        used = int(t.get('used_games', 0) or 0)
        extra = f' (+{cover-1})' if cover > 1 else ''
        prog = f' [{used}/{cover}]' if (cover > 1 and used > 0) else ''
        gtxt = stage_label if stage_label else str(t.get('gruppe',''))
        line = f"**{gtxt}**: {t['spieler1']} vs {t['spieler2']} – `{t['datum']} {t['uhrzeit']}`{extra}{prog}"
        line += _streamer_links(guild, t["gruppe"], t["spieler1"], t["spieler2"])
        lines.append(line)

    chunks, buf, L = [], [], 0
    for ln in (lines or ["_(Keine Termine)_"]):
        if L + len(ln) > 3500:
            chunks.append("\n".join(buf))
            buf = []
            L = 0
        buf.append(ln)
        L += len(ln) + 1
    if buf:
        chunks.append("\n".join(buf))

    desc = "\n".join(chunks) if chunks else "_(Keine Termine)_"
    em = embed_termin_list(desc.split("\n"))

    if msg:
        try:
            await msg.edit(embed=em, view=None)
            return
        except Exception:
            msg = None

    # Erstmalig Nachricht erstellen
    m = await channel.send(embed=em)
    try:
        state[key] = m.id
        apps_state_set(state)
    except Exception:
        pass



# -------- Streamer-Schedule mit Buttons im Streamer-Channel --------

class StreamSignupView(discord.ui.View):
    def __init__(self, group: str, s1: str, s2: str):
        super().__init__(timeout=None)
        self.group = group
        self.s1 = s1
        self.s2 = s2

    def _has_streamer_rights(self, member: discord.Member) -> bool:
            roles_cfg = (config.get("roles") or {})
            streamer_name = roles_cfg.get("streamer") if isinstance(roles_cfg.get("streamer"), str) else "Streamer"
            admin_name    = roles_cfg.get("admin")    if isinstance(roles_cfg.get("admin"), str)    else "Admin"
            owner_name    = roles_cfg.get("owner")    if isinstance(roles_cfg.get("owner"), str)    else "Owner"
            names = {streamer_name, admin_name, owner_name}
            return any(getattr(r, 'name', '') in names for r in getattr(member, 'roles', []))

    @discord.ui.button(label="🎥 Anmelden / Sign up", style=discord.ButtonStyle.success)
    async def signup(self, interaction: discord.Interaction, _):
        if not self._has_streamer_rights(interaction.user):
            await interaction.response.send_message(
                embed=discord.Embed(description="Nur für Streamer. Profil via </streamer_profile:> anlegen oder Rolle erhalten.", color=discord.Color.red()),
                ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        recs = load_json(MATCHES_PATH, [])
        rec = next((m for m in recs if m.get("gruppe")==self.group and {m.get("spieler1"),m.get("spieler2")}=={self.s1,self.s2}), None)
        signups = list(map(int, rec.get("stream_signups", []))) if rec else []
        if interaction.user.id in signups:
            await interaction.followup.send(embed=discord.Embed(description="Du bist bereits angemeldet.", color=discord.Color.blurple()), ephemeral=True); return
        if len(signups) >= MAX_STREAMERS:
            await interaction.followup.send(embed=discord.Embed(description="Slots voll ({MAX_STREAMERS*STREAM_SLOTS_PER_STREAMER}/{MAX_STREAMERS*STREAM_SLOTS_PER_STREAMER}).", color=discord.Color.orange()), ephemeral=True); return
        signups.append(interaction.user.id)
        upsert_match_record(self.group, self.s1, self.s2, stream_signups=signups)
        await interaction.followup.send(embed=discord.Embed(description="✅ Angemeldet ({min(len(signups)*STREAM_SLOTS_PER_STREAMER, MAX_STREAMERS*STREAM_SLOTS_PER_STREAMER)}/{MAX_STREAMERS*STREAM_SLOTS_PER_STREAMER}).", color=discord.Color.green()), ephemeral=True)
        try:
            await update_stream_schedule_channel(interaction.guild, config.get("stream_schedule_channel_id"))
            await update_termin_channel(interaction.guild, config.get("termine_public_id"))
        except Exception:
            pass

    @discord.ui.button(label="🚫 Abmelden / Unregister", style=discord.ButtonStyle.secondary)
    async def unsign(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        recs = load_json(MATCHES_PATH, [])
        rec = next((m for m in recs if m.get("gruppe")==self.group and {m.get("spieler1"),m.get("spieler2")}=={self.s1,self.s2}), None)
        signups = list(map(int, rec.get("stream_signups", []))) if rec else []
        if interaction.user.id not in signups:
            await interaction.followup.send(embed=discord.Embed(description="Du warst nicht angemeldet.", color=discord.Color.orange()), ephemeral=True); return
        signups = [x for x in signups if x != interaction.user.id]
        upsert_match_record(self.group, self.s1, self.s2, stream_signups=signups)
        await interaction.followup.send(embed=discord.Embed(description="✅ Abgemeldet.", color=discord.Color.green()), ephemeral=True)
        try:
            await update_stream_schedule_channel(interaction.guild, config.get("stream_schedule_channel_id"))
            await update_termin_channel(interaction.guild, config.get("termine_public_id"))
        except Exception:
            pass




async def update_orga_overview_channel(guild: discord.Guild, overview_channel_id: int):
    """Aktualisiert eine Orga-Übersicht aller Matches mit Status. / Updates staff match overview."""
    channel = guild.get_channel(overview_channel_id)
    if not isinstance(channel, discord.TextChannel):
        return
    from utils import apps_state_get, apps_state_set

    state = apps_state_get()
    key = "orga_overview_message_id"
    msg = None
    try:
        mid = int(state.get(key, 0))
        if mid:
            try:
                msg = await channel.fetch_message(mid)
            except Exception:
                msg = None
    except Exception:
        msg = None

    # Prefer KO bracket if present; otherwise fall back to Swiss/group phase.
    entries = []  # List[(group, s1, s2, label)]
    try:
        from utils import ko_load_bracket
        b = ko_load_bracket()
        if isinstance(b, dict) and isinstance(b.get("matches"), dict) and b.get("matches"):
            for mid, mdata in b["matches"].items():
                g = mdata.get("group") or f"KO-{mdata.get('stage','').upper()}-{mid}"
                s1 = mdata.get("p1") or "?"
                s2 = mdata.get("p2") or "?"
                label = f"{mdata.get('stage','KO').upper()} {mid}"
                entries.append((g, s1, s2, label))
    except Exception:
        entries = []
    if not entries:
        # Zentrale Matchliste: exakt dieselben Paare wie /gen_matches (Swiss 0:0)
        entries = [(g, a, b, g) for (g, a, b) in swiss_get_all_pairs(config)]  # type: ignore
    results = load_json("ergebnisse.json", {}) or {}

    lines: list[str] = []
    for group, s1, s2, label in entries:
        # Match-Channel per Topic "Gruppe|S1|S2" suchen
        chan_mention = "_kein Match-Channel gefunden / no match channel_"
        for ch in guild.text_channels:
            topic = (getattr(ch, "topic", "") or "")
            parts = topic.split("|")
            if len(parts) == 3 and parts[0] == group and parts[1] == s1 and parts[2] == s2:
                chan_mention = ch.mention
                break

        # Status bestimmen
        status = "🕒 Offen / Pending"
        key_res = f"{group}|{min(s1, s2)}|{max(s1, s2)}"
        res = results.get(key_res) or {}
        winner = res.get("winner")

        if match_closed_persisted(group, s1, s2) or winner:
            status = "✅ Abgeschlossen / Completed"
        else:
            if pair_has_confirmed(group, s1, s2):
                dt = next_confirmed_for_pair(group, s1, s2)
                if dt:
                    datum = dt.get("datum") or dt.get("date") or "?"
                    uhr = dt.get("uhrzeit") or dt.get("time") or "?"
                    status = f"📅 Termin {datum} {uhr} / Date scheduled"
                else:
                    status = "📅 Termin vereinbart / Date scheduled"
            elif pair_has_unconfirmed(group, s1, s2):
                status = "⏳ Terminvorschlag offen / Proposal pending"

        lines.append(f"**{label}** — {s1} vs {s2} • {chan_mention} • {status}")

    if not lines:
        lines.append("_(Keine Matches gefunden / No matches found)_")

    # Sortierung: erst Gruppe, dann Spieler
    lines.sort(key=lambda ln: ln.lower())

    embed = embed_match_overview(lines)

    if msg is None:
        sent = await channel.send(embed=embed)
        state[key] = int(sent.id)
        apps_state_set(state)
    else:
        await msg.edit(embed=embed)

async def update_stream_schedule_channel(guild: discord.Guild, channel_id: int | None):
    if not channel_id:
        return
    channel = guild.get_channel(channel_id)
    if not isinstance(channel, discord.TextChannel):
        return
    try:
        await channel.purge(check=lambda m: m.author == guild.me)
    except Exception:
        pass

    termine = load_json(TERMINE_PATH, [])
    termine = sorted(termine, key=lambda t: _parse_dt(t.get("datum",""), t.get("uhrzeit","")) or datetime.max.replace(tzinfo=ZoneInfo("Europe/Berlin")))
    matches = load_json(MATCHES_PATH, [])

    def _slots(group, s1, s2):
        recs = load_json(MATCHES_PATH, [])
        rec = next((m for m in recs if m.get("gruppe")==group and {m.get("spieler1"), m.get("spieler2")}=={s1,s2}), None)
        ids = list(map(int, rec.get("stream_signups", []))) if rec else []
        used = min(len(ids)*STREAM_SLOTS_PER_STREAMER, MAX_STREAMERS*STREAM_SLOTS_PER_STREAMER)
        return used, MAX_STREAMERS*STREAM_SLOTS_PER_STREAMER, ids

    if not termine:
        await channel.send(embed=discord.Embed(title="🎥 Stream Schedule", description="_(Keine Spiele geplant)_", color=discord.Color.purple()))
        return

    for t in termine:
        used, total, _ids = _slots(t["gruppe"], t["spieler1"], t["spieler2"])
        links = _streamer_links(guild, t["gruppe"], t["spieler1"], t["spieler2"])
        desc = f"**{t['gruppe']}** — {t['spieler1']} vs {t['spieler2']} — `{t['datum']} {t['uhrzeit']}` • **{used}/{total}**"
        if links: desc += links
        em = discord.Embed(title="🎥 Stream-Slot Buchung", description=desc, color=discord.Color.purple())
        await channel.send(embed=em, view=StreamSignupView(t["gruppe"], t["spieler1"], t["spieler2"]))