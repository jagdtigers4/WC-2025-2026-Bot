import re
import asyncio
import discord
from utils import (
    confirmed_count_for_pair,
    load_json, save_json, load_config, resolve_member_by_name,
    UNCONFIRMED_PATH, TERMINE_PATH, CANCEL_REQUESTS_PATH,
    remove_confirmed_termin, upsert_termin_record, get_termin_record,
    pair_has_unconfirmed, pair_has_confirmed, pending_cancel_exists,
    _same_pair
)
from embeds import (
    embed_cancel_request, embed_hilfe_request,
    embed_termin_proposed, embed_termin_confirmed
)
from update import update_termin_channel, update_orga_overview_channel
try:
    from update import update_stream_schedule_channel
except Exception:
    update_stream_schedule_channel = None

config = load_config()
hilfe_channel_id = config.get("hilfe_channel_id")
cancel_channel_id = config.get("cancel_channel_id")

_pair_locks: dict[tuple[str, str, str], asyncio.Lock] = {}

def _lock_for(group: str, s1: str, s2: str) -> asyncio.Lock:
    key = (group, s1, s2)
    if key not in _pair_locks:
        _pair_locks[key] = asyncio.Lock()
    return _pair_locks[key]

DATE_RE = re.compile(r"^\d{2}\.\d{2}\.\d{4}$")
TIME_RE = re.compile(r"^(?:[01]\d|2[0-3]):[0-5]\d$")

def _e(text: str, color: discord.Color = discord.Color.blurple()) -> discord.Embed:
    return discord.Embed(description=text, color=color)

def _mentions(guild: discord.Guild, s1: str, s2: str):
    m1 = resolve_member_by_name(guild, s1)
    m2 = resolve_member_by_name(guild, s2)
    p1m = m1.mention if m1 else f"**{s1}**"
    p2m = m2.mention if m2 else f"**{s2}**"
    return p1m, p2m

class HilfeModal(discord.ui.Modal, title="🆘 Hilfe / Help"):
    def __init__(self, group: str, s1: str, s2: str, channel: discord.TextChannel):
        super().__init__()
        self.group, self.s1, self.s2, self.channel = group, s1, s2, channel
        self.add_item(discord.ui.TextInput(
            label="Grund / Reason",
            placeholder="Kurz beschreiben / Short description",
        ))

    async def on_submit(self, interaction: discord.Interaction):
        reason = self.children[0].value.strip()
        if not reason:
            await interaction.response.send_message(
                embed=_e("Bitte Grund angeben. / Please provide a reason.", discord.Color.orange()),
                ephemeral=True
            )
            return
        if hilfe_channel_id:
            hilfe_channel = interaction.guild.get_channel(hilfe_channel_id)
            if isinstance(hilfe_channel, discord.TextChannel):
                await hilfe_channel.send(embed=embed_hilfe_request(
                    interaction.user, reason, self.group, self.s1, self.s2, self.channel
                ))
        await interaction.response.send_message(
            embed=_e("Hilfeanfrage gesendet. / Help request sent.", discord.Color.green()),
            ephemeral=True
        )

class TerminModal(discord.ui.Modal, title="📅 Termin vorschlagen / Propose date"):
    def __init__(self, group: str, s1: str, s2: str):
        super().__init__()
        self.group, self.s1, self.s2 = group, s1, s2
        self.add_item(discord.ui.TextInput(
            label="Datum / Date (TT.MM.JJJJ)",
            placeholder="z. B. 24.07.2025",
        ))
        self.add_item(discord.ui.TextInput(
            label="Uhrzeit / Time (HH:MM)",
            placeholder="z. B. 19:00",
        ))

    async def on_submit(self, interaction: discord.Interaction):
        datum = self.children[0].value.strip()
        uhrzeit = self.children[1].value.strip()

        if not DATE_RE.match(datum) or not TIME_RE.match(uhrzeit):
            await interaction.response.send_message(
                embed=_e("⚠️ Ungültiges Format. Nutze **TT.MM.JJJJ** und **HH:MM**.", discord.Color.orange()),
                ephemeral=True
            )
            return

        # Block: no date/time in the past
        try:
            from utils import _parse_dt
            import datetime as _dt
            dt = _parse_dt(datum, uhrzeit)
            if dt and dt < _dt.datetime.now():
                await interaction.response.send_message(
                    embed=_e("⛔ Termin liegt in der Vergangenheit. Bitte wähle ein Datum in der Zukunft.", discord.Color.red()),
                    ephemeral=True
                )
                return
        except Exception:
            pass

        # Blockieren: es gibt schon was Offenes/Bestätigtes oder eine Cancel-Anfrage
        if pair_has_unconfirmed(self.group, self.s1, self.s2) or confirmed_count_for_pair(self.group, self.s1, self.s2) >= 3 or pending_cancel_exists(self.group, self.s1, self.s2):
            await interaction.response.send_message(
                embed=_e("⚠️ Bereits offener/bestätigter Termin **oder** offene Storno-Anfrage.", discord.Color.orange()),
                ephemeral=True
            )
            return

        async with _lock_for(self.group, self.s1, self.s2):
            unconf = load_json(UNCONFIRMED_PATH, [])
            # Ein offener Vorschlag pro Paar
            unconf = [x for x in unconf if not (x.get("gruppe") == self.group and {x.get("spieler1"), x.get("spieler2")} == {self.s1, self.s2})]
            rec = {
                "gruppe": self.group,
                "spieler1": self.s1,
                "spieler2": self.s2,
                "datum": datum,
                "uhrzeit": uhrzeit,
                "proposed_by": interaction.user.id,
                # für Persistenz:
                "channel_id": interaction.channel.id,
                "message_id": None,
            }
            unconf.append(rec)
            save_json(UNCONFIRMED_PATH, unconf)

        p1m, p2m = _mentions(interaction.guild, self.s1, self.s2)
        view = ProposedTerminPersistentView()  # persistente Buttons
        msg = await interaction.channel.send(
            embed=embed_termin_proposed(self.group, self.s1, self.s2, datum, uhrzeit,
                                        interaction.user.mention, p1m, p2m),
            view=view
        )

        # message_id in rec zurückschreiben (Persistenz für Neustart)
        unconf = load_json(UNCONFIRMED_PATH, [])
        for x in unconf:
            if (x.get("gruppe")==self.group and {x.get("spieler1"),x.get("spieler2")}=={self.s1,self.s2}
                    and x.get("datum")==datum and x.get("uhrzeit")==uhrzeit):
                x["message_id"] = msg.id
        save_json(UNCONFIRMED_PATH, unconf)

        await interaction.response.send_message(
            embed=_e("📅 Termin vorgeschlagen. / Date proposed."),
            ephemeral=True
        )

# ------------- Persistente Views -------------

class ProposedTerminPersistentView(discord.ui.View):
    """Persistente View für Terminvorschläge (Bestätigen/Ablehnen/Abbrechen) – funktioniert auch nach Neustart."""
    def __init__(self):
        super().__init__(timeout=None)

    def _find_rec_by_msg(self, message_id: int):
        arr = load_json(UNCONFIRMED_PATH, [])
        for x in arr:
            if int(x.get("message_id", 0)) == int(message_id):
                return x
        return None

    async def _clear_rec(self, rec):
        arr = load_json(UNCONFIRMED_PATH, [])
        arr = [x for x in arr if not (
            x.get("gruppe")==rec["gruppe"] and {x.get("spieler1"),x.get("spieler2")}=={rec["spieler1"],rec["spieler2"]}
            and x.get("datum")==rec["datum"] and x.get("uhrzeit")==rec["uhrzeit"]
        )]
        save_json(UNCONFIRMED_PATH, arr)

    async def _finish_and_refresh(self, guild: discord.Guild):
        try:
            from utils import load_config
            cfg = load_config()
            # Prefer new nested config, but support legacy flat key.
            tid = int((((cfg.get('channels', {}) or {}).get('termine_channel_id')) or cfg.get('termine_public_id') or 0) or 0)
            if tid:
                await update_termin_channel(guild, tid)
        except Exception:
            pass
        # Orga-Matchübersicht aktualisieren
        try:
            await update_orga_overview_channel(guild, int(config.get("orga_overview_channel_id", 0) or 0))
        except Exception:
            pass
        if update_stream_schedule_channel:
            try:
                await update_stream_schedule_channel(guild, config.get("stream_schedule_channel_id"))
            except Exception:
                pass

    @discord.ui.button(label="✅ Bestätigen / Confirm", style=discord.ButtonStyle.success, custom_id="proposal_confirm")
    async def confirm(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        rec = self._find_rec_by_msg(interaction.message.id)
        if not rec:
            await interaction.followup.send(embed=_e("Kein offener Vorschlag gefunden.", discord.Color.orange()), ephemeral=True); return

        # Nur Spieler oder Orga
        m1 = resolve_member_by_name(interaction.guild, rec["spieler1"])
        m2 = resolve_member_by_name(interaction.guild, rec["spieler2"])
        is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
        if not (is_player or interaction.user.guild_permissions.administrator):
            await interaction.followup.send(embed=_e("Nur Spieler oder Orga.", discord.Color.red()), ephemeral=True); return

        # NEU: Self-Confirm verhindern – der Ersteller darf nicht selbst bestätigen
        if int(rec.get("proposed_by", 0)) == interaction.user.id and not interaction.user.guild_permissions.administrator:
            await interaction.followup.send(embed=_e("Du kannst **deinen eigenen Vorschlag** nicht bestätigen.", discord.Color.orange()), ephemeral=True); return

        p1m, p2m = _mentions(interaction.guild, rec["spieler1"], rec["spieler2"])

        # Editiere die Vorschlags-Nachricht -> Bestätigt + persistente Cancel-View
        try:
            await interaction.message.edit(
                embed=embed_termin_confirmed(rec["gruppe"], rec["spieler1"], rec["spieler2"], rec["datum"], rec["uhrzeit"], p1m, p2m),
                view=ConfirmedTerminPersistentView()
            )
        except Exception:
            pass

        # bestätigten Termin inkl. Message/Channel-ID persistieren
        upsert_termin_record(rec["gruppe"], rec["spieler1"], rec["spieler2"], rec["datum"], rec["uhrzeit"],
                             channel_id=interaction.channel.id, message_id=interaction.message.id)

        # offenen Vorschlag löschen
        await self._clear_rec(rec)

        # Info für beide
        await interaction.channel.send(embed=discord.Embed(
            title="✅ Termin bestätigt / Date confirmed",
            description=f"{p1m} vs {p2m} • `{rec['datum']} {rec['uhrzeit']}`",
            color=discord.Color.green()
        ))

        await interaction.followup.send(embed=_e("✅ Termin bestätigt.", discord.Color.green()), ephemeral=True)
        await self._finish_and_refresh(interaction.guild)

    @discord.ui.button(label="❌ Ablehnen / Decline", style=discord.ButtonStyle.danger, custom_id="proposal_decline")
    async def decline(self, interaction: discord.Interaction, _):
        # Interaction may expire during short disconnects; avoid noisy traceback.
        try:
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=True)
        except (discord.NotFound, discord.HTTPException):
            return
        rec = self._find_rec_by_msg(interaction.message.id)
        if not rec:
            await interaction.followup.send(embed=_e("Kein offener Vorschlag gefunden.", discord.Color.orange()), ephemeral=True); return

        # Nur Spieler oder Orga
        m1 = resolve_member_by_name(interaction.guild, rec["spieler1"])
        m2 = resolve_member_by_name(interaction.guild, rec["spieler2"])
        is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
        if not (is_player or interaction.user.guild_permissions.administrator):
            await interaction.followup.send(embed=_e("Nur Spieler oder Orga.", discord.Color.red()), ephemeral=True); return

        p1m, p2m = _mentions(interaction.guild, rec["spieler1"], rec["spieler2"])
        await self._clear_rec(rec)
        try:
            await interaction.message.edit(
                embed=discord.Embed(
                    title="❌ Terminvorschlag abgelehnt / Proposal declined",
                    description=f"**{rec['gruppe']}** — {rec['spieler1']} vs {rec['spieler2']}\n{p1m} vs {p2m}",
                    color=discord.Color.red()
                ),
                view=None
            )
        except Exception:
            pass
        await interaction.channel.send(embed=discord.Embed(
            title="❌ Terminvorschlag abgelehnt",
            description=f"{p1m} vs {p2m}",
            color=discord.Color.red()
        ))
        await interaction.followup.send(embed=_e("❌ Vorschlag abgelehnt.", discord.Color.orange()), ephemeral=True)
        await self._finish_and_refresh(interaction.guild)

    @discord.ui.button(label="🗑️ Abbrechen / Cancel proposal", style=discord.ButtonStyle.secondary, custom_id="proposal_cancel")
    async def cancel(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        rec = self._find_rec_by_msg(interaction.message.id)
        if not rec:
            await interaction.followup.send(embed=_e("Kein offener Vorschlag gefunden.", discord.Color.orange()), ephemeral=True); return

        # nur Ersteller oder Orga dürfen abbrechen
        if not (interaction.user.id == int(rec.get("proposed_by")) or interaction.user.guild_permissions.administrator):
            await interaction.followup.send(embed=_e("Nur Ersteller oder Orga.", discord.Color.red()), ephemeral=True); return

        await self._clear_rec(rec)
        try:
            await interaction.message.edit(
                embed=discord.Embed(
                    title="🗑️ Vorschlag zurückgezogen / Proposal cancelled",
                    description=f"**{rec['gruppe']}** — {rec['spieler1']} vs {rec['spieler2']}",
                    color=discord.Color.dark_grey()
                ),
                view=None
            )
        except Exception:
            pass
        await interaction.followup.send(embed=_e("Vorschlag gelöscht.", discord.Color.green()), ephemeral=True)
        await self._finish_and_refresh(interaction.guild)

# -------- Bestätigte-Termin-View (persistenter Cancel-Button) --------

class ConfirmedTerminPersistentView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="🛑 Termin stornieren / Cancel date",
        style=discord.ButtonStyle.secondary,
        custom_id="termin_cancel_persistent"
    )
    async def cancel_date(self, interaction: discord.Interaction, button: discord.ui.Button):
        msg_id = interaction.message.id
        rec = None
        arr = load_json(TERMINE_PATH, [])
        for t in arr:
            if int(t.get("message_id", 0)) == int(msg_id):
                rec = t
                break
        if not rec:
            await interaction.response.send_message(
                embed=_e("Termin nicht gefunden. Bitte neu vorschlagen/bestätigen.", discord.Color.orange()),
                ephemeral=True
            ); return

        group = rec["gruppe"]; s1 = rec["spieler1"]; s2 = rec["spieler2"]
        datum = rec["datum"]; uhrzeit = rec["uhrzeit"]

        # Nur Teilnehmer oder Orga
        m1 = resolve_member_by_name(interaction.guild, s1)
        m2 = resolve_member_by_name(interaction.guild, s2)
        is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
        if not (is_player or interaction.user.guild_permissions.administrator):
            await interaction.response.send_message(
                embed=_e("Nur Teilnehmer oder Orga! / Players or staff only.", discord.Color.red()),
                ephemeral=True
            ); return

        # Keine Doppel-Anfrage
        if pending_cancel_exists(group, s1, s2):
            await interaction.response.send_message(
                embed=_e("Es besteht bereits eine Storno-Anfrage.", discord.Color.orange()),
                ephemeral=True
            ); return

        await interaction.response.send_modal(CancelTerminModal(group, s1, s2, datum, uhrzeit, interaction.channel, confirmation_msg=interaction.message))

    @discord.ui.button(
        label="➕ +1 Spiel anhängen / Append +1 game",
        style=discord.ButtonStyle.primary,
        custom_id="termin_append1_persistent"
    )
    async def append_plus_one(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _handle_append_request(interaction, extra=1)

    @discord.ui.button(
        label="➕ +2 Spiele anhängen / Append +2 games",
        style=discord.ButtonStyle.primary,
        custom_id="termin_append2_persistent"
    )
    async def append_plus_two(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _handle_append_request(interaction, extra=2)

    @discord.ui.button(
        label="➖ Zusatz entfernen / Remove extension",
        style=discord.ButtonStyle.secondary,
        custom_id="termin_unappend_persistent"
    )
    async def unappend(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _handle_unappend_request(interaction)

# ---------- Storno bestehender Termine (Orga-Flow) ----------

class CancelTerminModal(discord.ui.Modal, title="🛑 Termin stornieren / Cancel date"):
    def __init__(self, group: str, s1: str, s2: str, datum: str, uhrzeit: str, match_channel: discord.TextChannel, confirmation_msg: discord.Message | None = None):
        super().__init__()
        self.group, self.s1, self.s2 = group, s1, s2
        self.datum, self.uhrzeit = datum, uhrzeit
        self.match_channel = match_channel
        self.confirmation_msg = confirmation_msg
        self.add_item(discord.ui.TextInput(
            label="Grund / Reason",
            placeholder="Warum stornieren? / Why cancel?",
            required=True
        ))

    async def on_submit(self, interaction: discord.Interaction):
        reason = self.children[0].value.strip()

        # Absicherung: nicht doppelt
        if pending_cancel_exists(self.group, self.s1, self.s2):
            await interaction.response.send_message(embed=_e("Es ist bereits eine Storno-Anfrage offen.", discord.Color.orange()), ephemeral=True)
            return

        # Eintrag persistieren
        store = load_json(CANCEL_REQUESTS_PATH, [])
        req_id = max([r.get("id", 0) for r in store] + [0]) + 1
        entry = {
            "id": req_id,
            "gruppe": self.group,
            "spieler1": self.s1,
            "spieler2": self.s2,
            "datum": self.datum,
            "uhrzeit": self.uhrzeit,
            "reason": reason,
            "by": interaction.user.id,
            "match_channel_id": self.match_channel.id,
            # Nachricht im Orga-Cancel-Channel:
            "approve_channel_id": None,
            "approve_message_id": None,
        }
        store.append(entry)
        save_json(CANCEL_REQUESTS_PATH, store)

        p1m, p2m = _mentions(interaction.guild, self.s1, self.s2)

        # Info im Match-Channel (beide Mentions)
        try:
            await self.match_channel.send(embed=embed_cancel_request(interaction.user, reason, self.group, self.s1, self.s2, self.match_channel, self.datum, self.uhrzeit, p1m, p2m))
        except Exception:
            pass

        # Orga-Channel Nachricht mit **persistenter** View
        em = embed_cancel_request(interaction.user, reason, self.group, self.s1, self.s2, self.match_channel, self.datum, self.uhrzeit, p1m, p2m)
        view = CancelApprovePersistentView()
        ch = interaction.guild.get_channel(cancel_channel_id) if cancel_channel_id else None
        if isinstance(ch, discord.TextChannel):
            msg = await ch.send(embed=em, view=view)
            # message_id der Approval-Nachricht persistieren
            store = load_json(CANCEL_REQUESTS_PATH, [])
            for r in store:
                if r.get("id") == req_id:
                    r["approve_channel_id"] = ch.id
                    r["approve_message_id"] = msg.id
            save_json(CANCEL_REQUESTS_PATH, store)
            await interaction.response.send_message(embed=_e("🛑 Storno-Anfrage gesendet. / Cancel request sent.", discord.Color.orange()), ephemeral=True)
        else:
            await interaction.response.send_message(embed=_e("Kein Cancel-Channel konfiguriert.", discord.Color.red()), ephemeral=True)




# -------- Termin: append games (KO) --------

class AppendTerminDecisionPersistentView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="✅ Annehmen / Accept",
        style=discord.ButtonStyle.success,
        custom_id="termin_append_accept_persistent"
    )
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _handle_append_decision(interaction, accept=True)

    @discord.ui.button(
        label="❌ Ablehnen / Deny",
        style=discord.ButtonStyle.danger,
        custom_id="termin_append_deny_persistent"
    )
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _handle_append_decision(interaction, accept=False)


async def _handle_append_request(interaction: discord.Interaction, extra: int):
    # Only on confirmed termin message
    msg_id = interaction.message.id
    rec = None
    arr = load_json(TERMINE_PATH, [])
    for t in arr:
        if int(t.get("message_id", -1)) == int(msg_id):
            rec = t
            break

    # Fallback: some older records may miss message_id; try to resolve by channel topic (KO-...|p1|p2)
    if not rec:
        topic = str(getattr(interaction.channel, "topic", "") or "")
        if topic.startswith("KO-") and "|" in topic:
            try:
                group = topic.split("|", 1)[0]
                rest = topic.split("|", 1)[1]
                s1 = rest.split("|", 1)[0]
                s2 = rest.split("|", 2)[1] if rest.count("|") >= 1 else ""
            except Exception:
                group = None; s1 = None; s2 = None
            if group and s1 and s2:
                for t in arr:
                    if _same_pair(group, s1, s2, t):
                        rec = t
                        # backfill message_id so next time it's stable
                        try:
                            t["message_id"] = int(msg_id)
                            t["channel_id"] = int(interaction.channel.id)
                            save_json(TERMINE_PATH, arr)
                        except Exception:
                            pass
                        break
    if not rec:
        await interaction.response.send_message(embed=_e("Termin nicht gefunden. / Date not found.", discord.Color.red()), ephemeral=True)
        return

    group = rec["gruppe"]; s1 = rec["spieler1"]; s2 = rec["spieler2"]
    if not str(group).startswith("KO-"):
        await interaction.response.send_message(embed=_e("Nur in KO-Matches verfügbar. / KO only.", discord.Color.red()), ephemeral=True)
        return

    # Only players or admin
    m1 = resolve_member_by_name(interaction.guild, s1)
    m2 = resolve_member_by_name(interaction.guild, s2)
    is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
    if not (is_player or interaction.user.guild_permissions.administrator):
        await interaction.response.send_message(embed=_e("Nur Teilnehmer oder Orga! / Players or staff only.", discord.Color.red()), ephemeral=True)
        return

    cover = int(rec.get("cover_games", 1) or 1)
    if cover > 1:
        await interaction.response.send_message(embed=_e("Es ist bereits ein Zusatzspiel angehängt. / Session already extended.", discord.Color.orange()), ephemeral=True)
        return

    if rec.get("append_pending"):
        await interaction.response.send_message(embed=_e("Es gibt bereits eine offene Anfrage. / Pending request already exists.", discord.Color.orange()), ephemeral=True)
        return

    rec["append_pending"] = {"extra": int(extra), "requested_by": int(interaction.user.id)}
    save_json(TERMINE_PATH, arr)

    # Ask the other player to accept/deny
    other = None
    if m1 and interaction.user.id == m1.id:
        other = m2
    elif m2 and interaction.user.id == m2.id:
        other = m1

    em = discord.Embed(
        title="➕ Zusatzspiel anhängen / Append extra game(s)",
        description=f"Match: **{group}** — {s1} vs {s2}\nAnfrage: **+{extra}**",
        color=discord.Color.blurple()
    )
    em.set_footer(text=f"{group}|{s1}|{s2}")
    mention = other.mention if other else ""
    await interaction.response.send_message(embed=_e("Anfrage gesendet. / Request sent.", discord.Color.green()), ephemeral=True)
    await interaction.channel.send(content=mention, embed=em, view=AppendTerminDecisionPersistentView())


async def _handle_unappend_request(interaction: discord.Interaction):
    """Request to remove an existing (+1/+2) extension. Only possible if no games have been consumed yet."""
    msg_id = interaction.message.id
    arr = load_json(TERMINE_PATH, [])
    rec = None
    for t in arr:
        if int(t.get("message_id", -1)) == int(msg_id):
            rec = t
            break
    if not rec:
        await interaction.response.send_message(embed=_e("Termin nicht gefunden. / Date not found.", discord.Color.red()), ephemeral=True)
        return

    group = rec["gruppe"]; s1 = rec["spieler1"]; s2 = rec["spieler2"]
    cover = int(rec.get("cover_games", 1) or 1)
    used = int(rec.get("used_games", 0) or 0)
    if cover <= 1:
        await interaction.response.send_message(embed=_e("Kein Zusatz anhängt. / No extension.", discord.Color.orange()), ephemeral=True)
        return
    if used > 0:
        await interaction.response.send_message(embed=_e("Nicht mehr möglich, da bereits gespielt wurde. / Not possible after games started.", discord.Color.red()), ephemeral=True)
        return

    # Only players or admin
    m1 = resolve_member_by_name(interaction.guild, s1)
    m2 = resolve_member_by_name(interaction.guild, s2)
    is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
    if not (is_player or interaction.user.guild_permissions.administrator):
        await interaction.response.send_message(embed=_e("Nur Teilnehmer oder Orga! / Players or staff only.", discord.Color.red()), ephemeral=True)
        return

    if rec.get("unappend_pending"):
        await interaction.response.send_message(embed=_e("Es gibt bereits eine offene Anfrage. / Pending request already exists.", discord.Color.orange()), ephemeral=True)
        return

    rec["unappend_pending"] = {"requested_by": int(interaction.user.id)}
    save_json(TERMINE_PATH, arr)

    other = None
    if m1 and interaction.user.id == m1.id:
        other = m2
    elif m2 and interaction.user.id == m2.id:
        other = m1

    em = discord.Embed(
        title="➖ Zusatz entfernen / Remove extension",
        description=f"Match: **{group}** — {s1} vs {s2}\nAktuell: **+{cover-1}**",
        color=discord.Color.blurple()
    )
    em.set_footer(text=f"UNAPPEND|{group}|{s1}|{s2}")
    mention = other.mention if other else ""
    await interaction.response.send_message(embed=_e("Anfrage gesendet. / Request sent.", discord.Color.green()), ephemeral=True)
    await interaction.channel.send(content=mention, embed=em, view=AppendTerminDecisionPersistentView())


async def _handle_append_decision(interaction: discord.Interaction, accept: bool):
    # identify match from footer
    if not interaction.message.embeds:
        await interaction.response.send_message(embed=_e("Ungültige Nachricht. / Invalid message.", discord.Color.red()), ephemeral=True)
        return
    footer = (interaction.message.embeds[0].footer.text or "").strip()
    try:
        group, s1, s2 = footer.split("|", 2)
    except Exception:
        await interaction.response.send_message(embed=_e("Ungültige Nachricht. / Invalid message.", discord.Color.red()), ephemeral=True)
        return

    arr = load_json(TERMINE_PATH, [])
    rec = None
    for t in arr:
        if _same_pair(group, s1, s2, t) and t.get("append_pending"):
            rec = t
            break
    if not rec:
        await interaction.response.send_message(embed=_e("Keine offene Anfrage. / No pending request.", discord.Color.orange()), ephemeral=True)
        return

    m1 = resolve_member_by_name(interaction.guild, s1)
    m2 = resolve_member_by_name(interaction.guild, s2)
    is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
    if not (is_player or interaction.user.guild_permissions.administrator):
        await interaction.response.send_message(embed=_e("Nur Teilnehmer oder Orga! / Players or staff only.", discord.Color.red()), ephemeral=True)
        return

    req = rec.get("append_pending") or {}
    requested_by = int(req.get("requested_by", 0) or 0)
    if is_player and interaction.user.id == requested_by:
        await interaction.response.send_message(embed=_e("Der Anfragende kann nicht selbst bestätigen. / Requester cannot self-confirm.", discord.Color.red()), ephemeral=True)
        return

    if not accept:
        rec.pop("append_pending", None)
        save_json(TERMINE_PATH, arr)
        await interaction.response.send_message(embed=_e("Abgelehnt. / Denied.", discord.Color.orange()), ephemeral=True)
        try:
            await interaction.message.delete()
        except Exception:
            pass
        return

    mode = str(req.get("mode") or "append")
    extra = int(req.get("extra", 0) or 0)

    if mode == "remove" or extra == 0:
        # Remove extension
        rec["cover_games"] = 1
        rec["used_games"] = int(rec.get("used_games", 0) or 0)
        rec.pop("append_pending", None)
        save_json(TERMINE_PATH, arr)

        # Try to remove (+1/+2) tag in confirmed termin message
        try:
            ch_id = int(rec.get("channel_id", 0) or 0)
            msg_id = int(rec.get("message_id", 0) or 0)
            ch = interaction.guild.get_channel(ch_id)
            if ch and msg_id:
                msg = await ch.fetch_message(msg_id)
                if msg and msg.embeds:
                    em0 = msg.embeds[0]
                    title = (em0.title or "").replace("(+1)", "").replace("(+2)", "").strip()
                    em0.title = title
                    await msg.edit(embed=em0, view=ConfirmedTerminPersistentView())
        except Exception:
            pass

        # refresh termine overview
        try:
            from update import update_termin_channel
            from utils import load_config
            cfg = load_config()
            tid = int((((cfg.get('channels', {}) or {}).get('termine_channel_id')) or cfg.get('termine_public_id') or 0) or 0)
            if tid:
                await update_termin_channel(interaction.guild, tid)
        except Exception:
            pass

        await interaction.response.send_message(embed=_e("Entfernt. / Removed.", discord.Color.green()), ephemeral=True)
        try:
            await interaction.message.delete()
        except Exception:
            pass
        return

    # Append extension
    if extra not in (1, 2):
        await interaction.response.send_message(embed=_e("Ungültig. / Invalid.", discord.Color.red()), ephemeral=True)
        return

    rec["cover_games"] = 1 + extra
    rec["used_games"] = int(rec.get("used_games", 0) or 0)
    rec.pop("append_pending", None)
    save_json(TERMINE_PATH, arr)

    # edit original confirmed termin message to show (+1/+2)
    try:
        ch_id = int(rec.get("channel_id", 0) or 0)
        msg_id = int(rec.get("message_id", 0) or 0)
        ch = interaction.guild.get_channel(ch_id)
        if ch and msg_id:
            msg = await ch.fetch_message(msg_id)
            if msg and msg.embeds:
                em = msg.embeds[0]
                tag = f"(+{extra})"
                if tag not in (em.title or ""):
                    em.title = (em.title or "📅 Termin / Date") + f" {tag}"
                await msg.edit(embed=em, view=ConfirmedTerminPersistentView())
    except Exception:
        pass

    # refresh termine overview message
    try:
        from update import update_termin_channel
        from utils import load_config
        cfg = load_config()
        tid = int((((cfg.get("channels", {}) or {}).get("termine_channel_id")) or cfg.get("termine_public_id") or 0) or 0)
        if tid:
            await update_termin_channel(interaction.guild, tid)
    except Exception:
        pass

    await interaction.response.send_message(embed=_e("Bestätigt. / Accepted.", discord.Color.green()), ephemeral=True)
    try:
        await interaction.message.delete()
    except Exception:
        pass


async def _handle_unappend_request(interaction: discord.Interaction):
    """Remove an existing (+1/+2) extension from a confirmed termin.
    - Only possible if no game has been played yet for this termin (used_games==0)
    - Requires the other player to accept (same flow as append)
    """
    msg_id = int(interaction.message.id)
    arr = load_json(TERMINE_PATH, [])
    rec = None
    for t in arr:
        if int(t.get("message_id", -1)) == msg_id:
            rec = t
            break
    if not rec:
        await interaction.response.send_message(embed=_e("Termin nicht gefunden. / Date not found.", discord.Color.red()), ephemeral=True)
        return

    group = rec.get("gruppe")
    s1 = rec.get("spieler1")
    s2 = rec.get("spieler2")
    cover = int(rec.get("cover_games", 1) or 1)
    used = int(rec.get("used_games", 0) or 0)

    if cover <= 1:
        await interaction.response.send_message(embed=_e("Kein Zusatz vorhanden. / No extension set.", discord.Color.orange()), ephemeral=True)
        return
    if used > 0:
        await interaction.response.send_message(embed=_e("Bereits gestartet – Entfernen nicht möglich. / Already started – cannot remove.", discord.Color.red()), ephemeral=True)
        return
    if rec.get("append_pending"):
        await interaction.response.send_message(embed=_e("Es gibt bereits eine offene Anfrage. / Pending request exists.", discord.Color.orange()), ephemeral=True)
        return

    m1 = resolve_member_by_name(interaction.guild, s1)
    m2 = resolve_member_by_name(interaction.guild, s2)
    is_player = (m1 and interaction.user.id == m1.id) or (m2 and interaction.user.id == m2.id)
    if not (is_player or interaction.user.guild_permissions.administrator):
        await interaction.response.send_message(embed=_e("Nur Teilnehmer oder Orga! / Players or staff only.", discord.Color.red()), ephemeral=True)
        return

    rec["append_pending"] = {"extra": 0, "requested_by": int(interaction.user.id), "mode": "remove"}
    save_json(TERMINE_PATH, arr)

    other = None
    if m1 and interaction.user.id == m1.id:
        other = m2
    elif m2 and interaction.user.id == m2.id:
        other = m1

    em = discord.Embed(
        title="➖ Zusatz entfernen / Remove extension",
        description=f"Match: **{group}** — {s1} vs {s2}\nAktuell: **+{cover-1}**",
        color=discord.Color.blurple()
    )
    em.set_footer(text=f"{group}|{s1}|{s2}")
    mention = other.mention if other else ""
    await interaction.response.send_message(embed=_e("Anfrage gesendet. / Request sent.", discord.Color.green()), ephemeral=True)
    await interaction.channel.send(content=mention, embed=em, view=AppendTerminDecisionPersistentView())

class CancelApprovePersistentView(discord.ui.View):
    """Persistente Orga-View für Storno-Anfragen (Annehmen/Ablehnen) – identifiziert per message_id in CANCEL_REQUESTS_PATH."""
    def __init__(self):
        super().__init__(timeout=None)

    def _load_req_by_msg(self, message_id: int):
        store = load_json(CANCEL_REQUESTS_PATH, [])
        for r in store:
            if int(r.get("approve_message_id", 0)) == int(message_id):
                return r
        return None

    def _is_staff(self, user: discord.Member) -> bool:
        from utils import is_admin
        return is_admin(user, (config.get("turnierleitung_ids") or []))

    async def _finalize(self, guild: discord.Guild, req_id: int):
        # Entferne Request aus Store
        store = load_json(CANCEL_REQUESTS_PATH, [])
        store = [r for r in store if r.get("id") != req_id]
        save_json(CANCEL_REQUESTS_PATH, store)
        # Kanäle aktualisieren
        try:
            await update_termin_channel(guild, int(((load_config().get('channels', {}) or {}).get('termine_channel_id', 0)) or 0))
            if update_stream_schedule_channel:
                await update_stream_schedule_channel(guild, config.get("stream_schedule_channel_id"))
        except Exception:
            pass
        # Orga-Matchübersicht aktualisieren
        try:
            await update_orga_overview_channel(guild, int(config.get("orga_overview_channel_id", 0) or 0))
        except Exception:
            pass

    @discord.ui.button(label="Annehmen / Accept", style=discord.ButtonStyle.success, custom_id="cancelreq_accept")
    async def accept(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        if not self._is_staff(interaction.user):
            await interaction.followup.send(embed=_e("Nur Orga. / Staff only.", discord.Color.red()), ephemeral=True); return
        req = self._load_req_by_msg(interaction.message.id)
        if not req:
            await interaction.followup.send(embed=_e("Anfrage nicht gefunden.", discord.Color.orange()), ephemeral=True); return

        # Vor dem Entfernen: Bestätigungsnachricht finden
        rec = get_termin_record(req["gruppe"], req["spieler1"], req["spieler2"], req["datum"], req["uhrzeit"])

        removed = remove_confirmed_termin(req["gruppe"], req["spieler1"], req["spieler2"], req["datum"], req["uhrzeit"])
        await self._finalize(interaction.guild, req["id"])

        # Match-Channel Info (beide pingen)
        mch = interaction.guild.get_channel(req.get("match_channel_id"))
        p1m, p2m = _mentions(interaction.guild, req["spieler1"], req["spieler2"])
        if isinstance(mch, discord.TextChannel):
            try:
                await mch.send(embed=discord.Embed(
                    title="🛑 Termin storniert / Date cancelled",
                    description=f"**{req['gruppe']}** — {req['spieler1']} vs {req['spieler2']}\n{p1m} vs {p2m}\n`{req['datum']} {req['uhrzeit']}`",
                    color=discord.Color.red()
                ))
            except Exception:
                pass

        # Alte Bestätigungsnachricht entfernen
        if rec and rec.get("channel_id") and rec.get("message_id"):
            ch = interaction.guild.get_channel(int(rec["channel_id"]))
            if isinstance(ch, discord.TextChannel):
                try:
                    msg = await ch.fetch_message(int(rec["message_id"]))
                    await msg.delete()
                except Exception:
                    pass

        await interaction.followup.send(embed=_e("✅ Storno angenommen. Termin entfernt.", discord.Color.green()), ephemeral=True)
        try:
            await interaction.message.edit(view=None)
        except Exception:
            pass

    @discord.ui.button(label="Ablehnen / Deny", style=discord.ButtonStyle.danger, custom_id="cancelreq_deny")
    async def deny(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        if not self._is_staff(interaction.user):
            await interaction.followup.send(embed=_e("Nur Orga. / Staff only.", discord.Color.red()), ephemeral=True); return
        req = self._load_req_by_msg(interaction.message.id)
        if not req:
            await interaction.followup.send(embed=_e("Anfrage nicht gefunden.", discord.Color.orange()), ephemeral=True); return

        # Nur schließen
        await self._finalize(interaction.guild, req["id"])

        # Info im Match-Channel (beide pingen)
        mch = interaction.guild.get_channel(req.get("match_channel_id"))
        p1m, p2m = _mentions(interaction.guild, req["spieler1"], req["spieler2"])
        if isinstance(mch, discord.TextChannel):
            try:
                await mch.send(embed=discord.Embed(
                    title="❌ Storno abgelehnt / Cancel denied",
                    description=f"**{req['gruppe']}** — {req['spieler1']} vs {req['spieler2']}\n{p1m} vs {p2m}\n`{req['datum']} {req['uhrzeit']}`",
                    color=discord.Color.orange()
                ))
            except Exception:
                pass

        await interaction.followup.send(embed=_e("❌ Storno abgelehnt.", discord.Color.red()), ephemeral=True)
        try:
            await interaction.message.edit(view=None)
        except Exception:
            pass
