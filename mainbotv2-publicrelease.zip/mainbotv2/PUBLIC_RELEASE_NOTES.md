# Public Release Notes

Dieses Paket ist für ein öffentliches Repository bereinigt worden.

Entfernt oder neutralisiert wurden:
- reale Discord-IDs und Token
- externe Google-Sheets-Links und Webhook-URLs
- laufende Turnierdaten aus JSON-State-Dateien
- lokale Cache-Bilder und Python-Bytecode

Vor produktiver Nutzung müssen `config.json` und die Beispiel-/State-Dateien wieder mit echten Werten befüllt werden.
